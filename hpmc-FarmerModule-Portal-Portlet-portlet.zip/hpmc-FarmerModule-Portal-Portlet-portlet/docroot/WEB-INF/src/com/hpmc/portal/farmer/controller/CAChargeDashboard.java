package com.hpmc.portal.farmer.controller;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.hpmc.portal.db.service.NoSuchCABookingException;
import com.hpmc.portal.db.service.model.CABooking;
import com.hpmc.portal.db.service.service.CABookingLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CAChargeDashboard extends MVCPortlet{

	public void caSearch(ActionRequest actionRequest, ActionResponse actiResponse) throws IOException{
		
		String bookingId = actionRequest.getParameter("CABooking_id");
		
		actiResponse.setRenderParameter("booking_id", bookingId);
		
	}
	
	
	public void doView(RenderRequest renderRequest,RenderResponse renderResponse) throws IOException, PortletException{
		
		String booking_id = ParamUtil.get(renderRequest, "booking_id", "");
		//long strToInt = Long.parseLong(booking_id);
		renderRequest.setAttribute("booking_id", booking_id);
		super.doView(renderRequest, renderResponse);
		
	}
	
}
