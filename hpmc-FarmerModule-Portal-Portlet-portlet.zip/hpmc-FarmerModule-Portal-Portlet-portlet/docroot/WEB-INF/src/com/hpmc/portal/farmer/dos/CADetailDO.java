package com.hpmc.portal.farmer.dos;

import java.util.Date;

public class CADetailDO {
	
	private String CA_CHAMBER_ID;
	private String CA_CHAMBER_NAME;
	private String CA_ID;
	private String CA_NAME;
	private String remainingSpace;
	private String statusVal;
	private String location;
	private String quantity;
	private Date bookingFromDate;
	private Date bookingToDate;
	
	
	public String getCA_CHAMBER_ID() {
		return CA_CHAMBER_ID;
	}
	public void setCA_CHAMBER_ID(String cA_CHAMBER_ID) {
		CA_CHAMBER_ID = cA_CHAMBER_ID;
	}
	public String getCA_CHAMBER_NAME() {
		return CA_CHAMBER_NAME;
	}
	public void setCA_CHAMBER_NAME(String cA_CHAMBER_NAME) {
		CA_CHAMBER_NAME = cA_CHAMBER_NAME;
	}
	public String getCA_ID() {
		return CA_ID;
	}
	public void setCA_ID(String cA_ID) {
		CA_ID = cA_ID;
	}
	public String getCA_NAME() {
		return CA_NAME;
	}
	public void setCA_NAME(String cA_NAME) {
		CA_NAME = cA_NAME;
	}
	public String getRemainingSpace() {
		return remainingSpace;
	}
	public void setRemainingSpace(String remainingSpace) {
		this.remainingSpace = remainingSpace;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public Date getBookingFromDate() {
		return bookingFromDate;
	}
	public void setBookingFromDate(Date bookingFromDate) {
		this.bookingFromDate = bookingFromDate;
	}
	public Date getBookingToDate() {
		return bookingToDate;
	}
	public void setBookingToDate(Date bookingToDate) {
		this.bookingToDate = bookingToDate;
	}
	public String getStatusVal() {
		return statusVal;
	}
	public void setStatusVal(String statusVal) {
		this.statusVal = statusVal;
	}
	

}
