package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.hpmc.portal.db.service.model.HPMCLocationRegistration;
import com.hpmc.portal.db.service.service.HPMCLocationRegistrationLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CACSLocation extends MVCPortlet {

	public static void locationStore(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException, SystemException {
			
			long locationId=0;
			int longStatus;
			String locationName=actionRequest.getParameter("locationName");
			String city= actionRequest.getParameter("city");
			
			String state=actionRequest.getParameter("state");
			String country=actionRequest.getParameter("country");
			String status=actionRequest.getParameter("status") ;
			if (status.equalsIgnoreCase("Active")) {
				longStatus=1;
			}else{
				longStatus=0;
			}
			
			
			
			
			/*long zip;
			
			System.out.println(locationName);
			String locationType;
			long createdBy;
			
			locationId= 0;
			city= "Bangalore";
			state= "Karnatka";
			country= "India";
			zip=12345;
			locationName="BTM Laout";
			locationType=HPMCConstant.LOCATION_TYPE_PROFIT_CENTER;*/
			
			
			System.out.println("-----------------*****************&&&&&&&&&&&&&&&");
			
		
			HPMCLocationRegistration hpmcLocationRegistration = null;
			locationId = CounterLocalServiceUtil.increment(HPMCLocationRegistration.class.getName());
			hpmcLocationRegistration = HPMCLocationRegistrationLocalServiceUtil.createHPMCLocationRegistration(locationId);
			hpmcLocationRegistration.setLOCATION(locationName.toUpperCase());
			hpmcLocationRegistration.setCITY(city.toUpperCase());
			hpmcLocationRegistration.setCOUNTRY(country.toUpperCase());
			hpmcLocationRegistration.setSTATE(state.toUpperCase());
			hpmcLocationRegistration.setSTATUS(longStatus);
			
			
			HPMCLocationRegistrationLocalServiceUtil.addHPMCLocationRegistration(hpmcLocationRegistration);
			
			
			List<HPMCLocationRegistration> hpmcLocationRegistrationList= HPMCLocationRegistrationLocalServiceUtil.getHPMCLocationRegistrations(0, CounterLocalServiceUtil.getCountersCount());
			for (HPMCLocationRegistration hpmcLocationRegistration2 : hpmcLocationRegistrationList) {
				System.out.println(hpmcLocationRegistration2);
			}
		/*
		 * 
		 *  LOCATION_ID
			CITY
			STATE
			COUNTRY
			PINCODE
			LOCATION_NAME
			LOCATION_TYPE
			CREATED_BY
			STATUS
		*/
		
	}
	
}

 