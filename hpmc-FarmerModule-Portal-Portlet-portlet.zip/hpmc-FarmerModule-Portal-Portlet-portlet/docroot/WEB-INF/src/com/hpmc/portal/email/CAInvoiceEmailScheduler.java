package com.hpmc.portal.email;

import java.sql.SQLException;
import java.util.List;

import com.hpmc.portal.farmer.dao.CABookingDAO;
import com.hpmc.portal.farmer.dos.CADetailDO;
import com.hpmc.portal.farmer.dos.CAInvoiceDO;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;

public class CAInvoiceEmailScheduler implements MessageListener {

	@Override
	public void receive(Message message) throws MessageListenerException {
		// TODO Auto-generated method stub
		try {
			CABookingDAO caBookingDAO = new CABookingDAO();
			CADetailDO caDetailDO = new CADetailDO();
			List<CAInvoiceDO> CAInvoiceDOList = caBookingDAO.getAutoGenerateCAInvoice();
			 for(CAInvoiceDO invoice : CAInvoiceDOList) {
			        
			         String subject = "Invoice Report From HPMC";
			         String toEmail = invoice.getEmail();
			         String body = "<h1>Farmer Booking Invioce</h1>"
							+ "<table>"
							+ "<tr><td>Name			:</td><td>"+invoice.getFname()+" "+ invoice.getLname() + "</td></tr>"
							+ "<tr><td>Email			:</td><td>"+ invoice.getEmail() + "</td></tr>"
							+ "<tr><td>Phone Number	:</td><td>"+ invoice.getMobileNumber() + "</td></tr>"
							+ "<tr><td>Aadhar Number	:</td><td>"+ invoice.getAadharNumber() + "</td></tr>"
							+ "<tr><td>Booking ID 	:</td><td>"+ invoice.getBookingId() + "</td></tr>"
							+ "<tr><td>Booking Date 	: </td><td>"+ invoice.getBookingDate() + "</td></tr>"
							+ "<tr><td>Booking Weight :</td><td>"+ invoice.getWieght() + "</td></tr>"
							+ "<tr><td>Due Amount 	: </td><td>"+ invoice.getDueAmount() + "</td></tr>"
							+ "<tr><td>Due Last Date	: </td><td>"+ invoice.getDueLastDate() + "</td></tr>"
							+ "</table>";
			        
			        JavaMailSend.TLSMail(toEmail, subject, body);
			        
			    }
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
