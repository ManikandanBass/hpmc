package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.hpmc.portal.db.service.model.CSProductRegistration;
import com.hpmc.portal.db.service.service.CSProductRegistrationLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class ProductManagement extends MVCPortlet {
	
	public void productRegistration(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		try {
			
			String coldStorageId = actionRequest.getParameter("coldStorageId");
			String productName = actionRequest.getParameter("productName");
			String storageType = actionRequest.getParameter("storageType");
			String productRent = actionRequest.getParameter("productRent");
			
			long productId = 0, counter = 0;
			CSProductRegistration productRegistration = null;
			
			List<CSProductRegistration> productList = CSProductRegistrationLocalServiceUtil.getCSProductRegistrations(0,CounterLocalServiceUtil.getCountersCount());
			for(CSProductRegistration productObj : productList){
				counter = productObj.getPRODUCT_ID();
			}
			productId = counter + 1 ;
			productRegistration = CSProductRegistrationLocalServiceUtil.createCSProductRegistration(productId);
			
			productRegistration.setCS_ID(Long.parseLong(coldStorageId));
			productRegistration.setPRODUCT_NAME(productName);
			productRegistration.setSTORAGE_TYPE(storageType);
			productRegistration.setRENT(Float.parseFloat(productRent));
			CSProductRegistrationLocalServiceUtil.addCSProductRegistration(productRegistration);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void updateProductRent(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			long productId = Long.parseLong(actionRequest.getParameter("productId"));
			String productName = actionRequest.getParameter("productName");
			String storageType = actionRequest.getParameter("storageType");
			String productRent = actionRequest.getParameter("productRent");
			
			CSProductRegistration productDetail = CSProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
			
			productDetail.setPRODUCT_NAME(productName);
			productDetail.setSTORAGE_TYPE(storageType);
			productDetail.setRENT(Float.parseFloat(productRent));
			
			CSProductRegistrationLocalServiceUtil.updateCSProductRegistration(productDetail);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteProduct(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			long productId = ParamUtil.getLong(actionRequest, "product_id");
			CSProductRegistration productDetail = CSProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
			CSProductRegistrationLocalServiceUtil.deleteCSProductRegistration(productDetail);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
