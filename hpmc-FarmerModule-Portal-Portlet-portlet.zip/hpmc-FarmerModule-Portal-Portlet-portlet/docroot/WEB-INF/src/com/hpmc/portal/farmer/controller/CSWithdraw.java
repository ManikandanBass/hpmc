package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.hpmc.portal.db.service.NoSuchCSBookingException;
import com.hpmc.portal.db.service.NoSuchCSChamberFloorBookingRegistrationException;
import com.hpmc.portal.db.service.NoSuchCSProductBookingManagementException;
import com.hpmc.portal.db.service.model.CSBooking;
import com.hpmc.portal.db.service.model.CSChamberFloorBookingRegistration;
import com.hpmc.portal.db.service.model.CSProductBookingManagement;
import com.hpmc.portal.db.service.service.CSBookingAmountManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSBookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSChamberFloorBookingRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductBookingManagementLocalServiceUtil;
import com.hpmc.portal.email.CSMailCommunication;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CSWithdraw extends MVCPortlet{
	
	
	//================================================USING FUNCTIONS STARTS=================================================//
	
	public void searchBookingOrderNumber(ActionRequest actionRequest,
		ActionResponse actionResponse) throws IOException, PortletException {
		long withDrawBookingId = Long.parseLong(actionRequest.getParameter("cs_booking_no"));
		try {
			
			if(withDrawBookingId != 0){
				//List<CSBooking> bookingsList = null;
				
				CSBooking csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(withDrawBookingId);
				if(csBookings.getBOOKING_STATUS() == true){
					throw new ArithmeticException("Canceled this booking id("+withDrawBookingId+").");
				}
				actionRequest.setAttribute("status", "success");
				actionRequest.setAttribute("bookingId", withDrawBookingId);
				
			}
			
		} catch(ArithmeticException arith){
			actionRequest.setAttribute("status", "fail");
			actionRequest.setAttribute("messages", arith.getMessage());
			actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/search-booking-order.jsp");
		} catch(NoSuchCSBookingException nobookingid){
			actionRequest.setAttribute("status", "fail");
			actionRequest.setAttribute("messages", "Please enter Correct Booking Id");
			actionRequest.setAttribute("bookingId", withDrawBookingId);
			actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/search-booking-order.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	//new Action 
		public void actionFullyWithdrawal(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException {
			
			long productBookingId = Long.parseLong(actionRequest.getParameter("product_booking_id"));
			long bookingId = Long.parseLong(actionRequest.getParameter("booking_id"));
			long withDrawalBags = Long.parseLong(actionRequest.getParameter("with_drawal_bags"));
			
			try {
				
				//Update Data in hpmc_cs_product_booking_rel
				CSProductBookingManagement csProductBooking = CSProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBookingId);
				csProductBooking.setWITHDRAW_NUMBER_OF_BAGS((int) withDrawalBags);
				csProductBooking.setTO_DATE(new Date());
				CSProductBookingManagementLocalServiceUtil.updateCSProductBookingManagement(csProductBooking);
				
				//Update Data in hpmc_cs_product_booking_floor_detail
				List<CSChamberFloorBookingRegistration> floorList = CSChamberFloorBookingRegistrationLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBookingId);
				for(CSChamberFloorBookingRegistration floor: floorList){
					floor.setWITHDRAW_NUMBER_OF_BAGS(floor.getSTORED_NUMBER_OF_BAGS());
					CSChamberFloorBookingRegistrationLocalServiceUtil.updateCSChamberFloorBookingRegistration(floor);
				}
				
				actionRequest.setAttribute("status", "success");
				actionRequest.setAttribute("bookingId", bookingId);
				actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/search-booking-order.jsp");
				
			} catch ( NoSuchCSProductBookingManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (SystemException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		//new Action for partially 
		public void actionPartiallyWithdrawal(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException {
			
			long productBookingId = Long.parseLong(actionRequest.getParameter("product_booking_id"));
			long bookingId = Long.parseLong(actionRequest.getParameter("booking_id"));
			long rowCount = Long.parseLong(actionRequest.getParameter("product_row_count"));
			
			try {
				//Increasing New Product_booking_id in CS_PRODUCT_BOOKING_REL
				long productBookingRelId = 0;
				productBookingRelId = CounterLocalServiceUtil.increment(CSProductBookingManagement.class.getName());
				
				int totalWithDrawalBags = 0;
				for (int i = 0; i < rowCount; i++) {
					
					
					if (!actionRequest.getParameter("with_drawal_bags"+i).isEmpty()) {
						long chamberFloorId = Long.parseLong(actionRequest.getParameter("chamber_floor_id"+i));
						long withDrawalBags = Long.parseLong(actionRequest.getParameter("with_drawal_bags"+i));
						
						CSChamberFloorBookingRegistration floorUpdate = CSChamberFloorBookingRegistrationLocalServiceUtil
								.findByCHAMBER_FLOOR_ID(chamberFloorId);
						if (floorUpdate.getSTORED_NUMBER_OF_BAGS() < withDrawalBags) {
							throw new ArithmeticException(
									"Please Must Enter Withdrawal counts less than or equal total no bags.");
						}
						totalWithDrawalBags = (int) (totalWithDrawalBags + withDrawalBags);
						int decreaseStoredNOB = (int) floorUpdate
								.getSTORED_NUMBER_OF_BAGS()
								- (int) withDrawalBags;
						//floorUpdate.setSTORED_NUMBER_OF_BAGS(decreaseStoredNOB);
						floorUpdate
								.setWITHDRAW_NUMBER_OF_BAGS((int) withDrawalBags);
						CSChamberFloorBookingRegistrationLocalServiceUtil
								.updateCSChamberFloorBookingRegistration(floorUpdate);
						//New floor record created based on remaining bags in hpmc_cs_product_booking_floor_detail
						long CHAMBER_FLOOR_ID = 0;
						
						if (decreaseStoredNOB > 0) {
							CHAMBER_FLOOR_ID = CounterLocalServiceUtil
									.increment(CSChamberFloorBookingRegistration.class
											.getName());
							CSChamberFloorBookingRegistration chamberFloorRegistration = CSChamberFloorBookingRegistrationLocalServiceUtil
									.createCSChamberFloorBookingRegistration(CHAMBER_FLOOR_ID);
							chamberFloorRegistration
									.setPRODUCT_BOOKING_ID(productBookingRelId);
							chamberFloorRegistration
									.setCS_CHAMBER_ID(floorUpdate
											.getCS_CHAMBER_ID());
							chamberFloorRegistration
									.setFLOOR_RACK_NO(floorUpdate
											.getFLOOR_RACK_NO());
							chamberFloorRegistration
									.setSTORED_NUMBER_OF_BAGS(decreaseStoredNOB);
							chamberFloorRegistration.setLOT_NUM(floorUpdate
									.getLOT_NUM());
							CSChamberFloorBookingRegistrationLocalServiceUtil
									.addCSChamberFloorBookingRegistration(chamberFloorRegistration);
						}
					}
					
				}
				//Update Data in hpmc_cs_product_booking_rel
				CSProductBookingManagement csProductBooking = CSProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBookingId);
				csProductBooking.setWITHDRAW_NUMBER_OF_BAGS(totalWithDrawalBags);
				csProductBooking.setTO_DATE(new Date());
				CSProductBookingManagementLocalServiceUtil.updateCSProductBookingManagement(csProductBooking);
				
				long pwProductTotalNOB	= (csProductBooking.getTOTAL_NUMBER_OF_BAGS() > 0) ? 
						csProductBooking.getTOTAL_NUMBER_OF_BAGS() : csProductBooking.getBOOKING_NUMBER_OF_BAGS();
				
				long remainBags = pwProductTotalNOB - totalWithDrawalBags;
				if(remainBags > 0){
				//New product Booking Create new record in CS_PRODUCT_BOOKING_REL
				CSProductBookingManagement csProductBookingManagement = null;
				csProductBookingManagement = CSProductBookingManagementLocalServiceUtil.createCSProductBookingManagement(productBookingRelId);
				csProductBookingManagement.setBOOKING_ID(csProductBooking.getBOOKING_ID());
				csProductBookingManagement.setPRODUCT_ID(csProductBooking.getPRODUCT_ID());
				csProductBookingManagement.setBOOKING_NUMBER_OF_BAGS((int) remainBags);
				csProductBookingManagement.setRENT_AMOUNT(csProductBooking.getRENT_AMOUNT());
				csProductBookingManagement.setFROM_DATE(csProductBooking.getFROM_DATE());
				CSProductBookingManagementLocalServiceUtil.addCSProductBookingManagement(csProductBookingManagement);
				}
				actionRequest.setAttribute("status", "success");
				actionRequest.setAttribute("bookingId", bookingId);
				actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/search-booking-order.jsp");
				
			} catch ( NoSuchCSProductBookingManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch ( ArithmeticException arith) {
				actionRequest.setAttribute("messages", arith.getMessage());
				actionRequest.setAttribute("product_booking_id", bookingId);
				actionRequest.setAttribute("booking_id", bookingId);
				actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/partially-withdraw-details.jsp");

			} catch (SystemException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchCSChamberFloorBookingRegistrationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		//New action for Over All Withdrawn
		public void actionOverAllWithdrawal(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException {
			try {
				
				if (!actionRequest.getParameter("booking_id").isEmpty() && 
						!actionRequest.getParameter("payment_mode").isEmpty()) {
					
					long bookingId = Long.parseLong(actionRequest
							.getParameter("booking_id"));
					String paymentMode = actionRequest
							.getParameter("payment_mode");
					String chequeDraftDetails = actionRequest
							.getParameter("cheque_draft_details");
					/*Nirav Changes Start*/
					String cashDetails = actionRequest
							.getParameter("cashDetails");
					/*Nirav End*/
					List<CSProductBookingManagement> productBookingManagement = CSProductBookingManagementLocalServiceUtil
							.findByBOOKING_ID(bookingId);
					float totalProductsChargedAmount = 0;
					//Insert Data in hpmc_cs_booking_amount_charged
					long invoiceNumber = 0;
					com.hpmc.portal.db.service.model.CSBookingAmountManagement csBookingAmount = null;
					invoiceNumber = CounterLocalServiceUtil
							.increment(com.hpmc.portal.db.service.model.CSBookingAmountManagement.class
									.getName());
					//if (session.getAttribute("recordInsertedSuccessfully") == null )
					for (CSProductBookingManagement productBookingRow : productBookingManagement) {
						if (productBookingRow.getINVOICE_NUMBER() == 0
								&& productBookingRow
										.getWITHDRAW_NUMBER_OF_BAGS() > 0) {
							csBookingAmount = CSBookingAmountManagementLocalServiceUtil
									.createCSBookingAmountManagement(invoiceNumber);
							
							break;
						}
						
					}
					
					
					for (CSProductBookingManagement productBookingRow : productBookingManagement) {

						if (productBookingRow.getINVOICE_NUMBER() == 0
								&& productBookingRow
										.getWITHDRAW_NUMBER_OF_BAGS() > 0) {

							//Update Data in hpmc_cs_product_booking_rel
							CSProductBookingManagement csProductBooking = CSProductBookingManagementLocalServiceUtil
									.findByPRODUCT_BOOKING_ID(productBookingRow
											.getPRODUCT_BOOKING_ID());
							csProductBooking.setINVOICE_NUMBER(invoiceNumber);
							CSProductBookingManagementLocalServiceUtil
									.updateCSProductBookingManagement(csProductBooking);

							Calendar startCalendar = new GregorianCalendar();
							startCalendar.setTime(productBookingRow
									.getFROM_DATE());
							Calendar endCalendar = new GregorianCalendar();
							endCalendar.setTime(productBookingRow.getTO_DATE());

							int diffYear = endCalendar.get(Calendar.YEAR)
									- startCalendar.get(Calendar.YEAR);
							int diffMonth = (diffYear * 12
									+ endCalendar.get(Calendar.MONTH) - startCalendar
									.get(Calendar.MONTH)) + 1;

							float productChargedAmount = (productBookingRow
									.getWITHDRAW_NUMBER_OF_BAGS()
									* productBookingRow.getRENT_AMOUNT() * diffMonth);
							totalProductsChargedAmount = totalProductsChargedAmount
									+ productChargedAmount;

						}

						if (csBookingAmount != null) {
							csBookingAmount.setBOOKING_ID(bookingId);
							csBookingAmount
									.setBOOKING_AMOUNT_CHARGED(totalProductsChargedAmount);
							csBookingAmount
									.setTOTAL_PAYABLE_AMOUNT(totalProductsChargedAmount);
							csBookingAmount
									.setTOTAL_PAYABLE_PAYMENT_MODE(paymentMode);
							csBookingAmount
									.setTOTAL_PAYABLE_PAYMENT_CHECK_DRAFT_DETAIL(chequeDraftDetails);
							/*Nirav Changes*/
							csBookingAmount.setTOTAL_PAYABLE_PAYMENT_CASH_DETAIL(cashDetails);
							/*Nirav End*/
							CSBookingAmountManagementLocalServiceUtil
									.updateCSBookingAmountManagement(csBookingAmount);
							
							
							CSMailCommunication.productsWithdrawnConfirmation(bookingId);
							
							actionRequest.setAttribute("booking_id", bookingId);
							actionRequest.setAttribute("invoice_id",
									csBookingAmount.getINVOICE_NUMBER());
							actionRequest.setAttribute("messages",
									"Succesfully Withdrawn Products.");
							actionResponse
									.setRenderParameter("jspPage",
											"/html/cs/with-draw/success-withdrawn-details.jsp");
						} else {
							actionRequest.setAttribute("bookingId", bookingId);
							actionRequest
									.setAttribute("messages",
											"Nothing Withdrawn Products. Because Nothing happened Full/Partial Withdrawal.");
							actionRequest.setAttribute("status", "fail");
							actionResponse
									.setRenderParameter("jspPage",
											"/html/cs/with-draw/search-booking-order.jsp");
						}

					}
				}else{
					actionRequest.setAttribute("bookingId", Long.valueOf(actionRequest.getParameter("booking_id")));
					actionRequest
							.setAttribute("messages",
									"Please Check Inputs Values.(Payment Mode / Type.");
					actionRequest.setAttribute("status", "fail");
					actionResponse
							.setRenderParameter("jspPage",
									"/html/cs/with-draw/search-booking-order.jsp");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				
			}
			
			
		}
	
	
	
	//================================================USING FUNCTIONS END=================================================//
		
		
	public void searchBookingOrderNumber_One(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException {

			long withDrawBookingId = Long.parseLong(actionRequest.getParameter("cs_booking_no"));
			try {
				
				if(withDrawBookingId != 0){
					
					CSBooking csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(withDrawBookingId);
					
					
					long totalBookedNOB = 0;
					long totalOrBookingNOB = 0;
					java.util.List<CSProductBookingManagement> productBookingObj = CSProductBookingManagementLocalServiceUtil.findByBOOKING_ID(withDrawBookingId);
					for (Iterator iterator = productBookingObj.iterator(); iterator
							.hasNext();) {
						CSProductBookingManagement csProductBookingManagement = (CSProductBookingManagement) iterator
								.next();
						if (csProductBookingManagement.getWITHDRAW_NUMBER_OF_BAGS()==0) {
							
							long productBookingNOB = csProductBookingManagement.getTOTAL_NUMBER_OF_BAGS();//Re changed booking No of bags. 
							
							if(productBookingNOB == 0){
								productBookingNOB = csProductBookingManagement.getBOOKING_NUMBER_OF_BAGS();
							}
							
							java.util.List<CSChamberFloorBookingRegistration> productBooked = CSChamberFloorBookingRegistrationLocalServiceUtil.findByPRODUCT_BOOKING_ID(csProductBookingManagement.getPRODUCT_BOOKING_ID());
							for(CSChamberFloorBookingRegistration bookedProduct: productBooked){
								totalBookedNOB = totalBookedNOB + bookedProduct.getSTORED_NUMBER_OF_BAGS();
							}
							totalOrBookingNOB = totalOrBookingNOB + productBookingNOB;
							
						}
						
					}
					
					/*List<CSProductBookingManagement> productsBookingList = CSProductBookingManagementLocalServiceUtil.findByBOOKING_ID(bookingIdConvertedLong);
					for (Iterator<CSProductBookingManagement> iterator = productsBookingList.iterator(); iterator
							.hasNext();) {
						CSProductBookingManagement csProductBookingManagement = (CSProductBookingManagement) iterator
								.next();
						
					}*/
					
					/*for(CSProductBookingManagement productBooking: productBookingObj ){
						long productBookingNOB = productBooking.getTOTAL_NUMBER_OF_BAGS();//Re changed booking No of bags. 
						
						if(productBookingNOB == 0){
							productBookingNOB = productBooking.getBOOKING_NUMBER_OF_BAGS();
						}
						
						java.util.List<CSChamberFloorBookingRegistration> productBooked = CSChamberFloorBookingRegistrationLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBooking.getPRODUCT_BOOKING_ID());
						for(CSChamberFloorBookingRegistration bookedProduct: productBooked){
							totalBookedNOB = totalBookedNOB + bookedProduct.getNUMBER_OF_BAGS();
						}
						totalOrBookingNOB = totalOrBookingNOB + productBookingNOB;
					}*/
					
					if(totalOrBookingNOB != totalBookedNOB){
						throw new ArithmeticException ("Please Must Store All Products, then only You can Withdrawal.");
					}
					
					actionRequest.setAttribute("csBookingObj", csBookings.getBOOKING_ID());
					actionRequest.setAttribute("bookingId", csBookings.getBOOKING_ID());
					actionRequest.setAttribute("bookedBy", csBookings.getBOOKED_BY());
						
				}
				
				
			} catch(NoSuchCSBookingException ex){
				//SessionErrors.add(actionRequest, "error");
				actionRequest.setAttribute("messages", "Please enter Correct Booking Id");
				actionRequest.setAttribute("status", "fail");
				actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/search-booking-order.jsp");
			} catch (ArithmeticException aex) {
				actionRequest.setAttribute("messages", aex.getMessage());
				actionRequest.setAttribute("status", "fail");
				actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/search-booking-order.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
			
		}	
		
	public void withdrawalProducts(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		long rowCount = Long.parseLong(actionRequest.getParameter("product_row_count"));
		long bookingID = Long.parseLong(actionRequest.getParameter("booking_id"));
		for (int i = 0; i < rowCount; i++) {
			boolean isitwithdraw = Boolean.parseBoolean(actionRequest.getParameter("isitwithdraw"+i)) ;
			String withdrawalType = actionRequest.getParameter("withdrawal_type"+i);
			long withDrawalBags = Long.parseLong(actionRequest.getParameter("with_drawal_bags"+i));
			long productTotalNOB = Long.parseLong(actionRequest.getParameter("product_total_no_bags"+i));
			long productBookingId = Long.parseLong(actionRequest.getParameter("product_booking_id"+i));
			long productId = Long.parseLong(actionRequest.getParameter("product_id"+i));
			float totalRent = Float.parseFloat(actionRequest.getParameter("total_rent"+i));
			float productRent = Float.parseFloat(actionRequest.getParameter("product_rent"+i));
			String[] productStr = {withdrawalType};
			Long[] productLong = {bookingID,productBookingId,withDrawalBags,productTotalNOB,productId};
			Float[] productFloat = {productRent,totalRent};
			
			if(withdrawalType.equalsIgnoreCase(HPMCConstant.FULLY_WITHDRAWAL)){
				this.fullyWithdraw(productStr,productLong,productFloat,isitwithdraw);
			}
			
			if(withdrawalType.equalsIgnoreCase(HPMCConstant.PARTIALLY_WITHDRAWAL)){
				this.partiallyWithdraw(productStr,productLong,productFloat,isitwithdraw);
			}
			
		}
		
	}
	
	public void fullyWithdraw(String strProduct[],Long longProduct[],Float floatProduct[],Boolean checkBoxStatus){
		
		boolean fwIsItWithdraw 		= checkBoxStatus; //checkBox checked or not
		String 	fwWithdrawalType 	= strProduct[0]; //withdrawal Type
		
		long 	fwBookingID 		= longProduct[0]; //Booking Id
		long 	fwProductBookingId 	= longProduct[1]; //Product Booknig ID
		long 	fwWithDrawalBags 	= longProduct[2]; //WithDrawal No Of Bags
		long 	fwProductTotalNOB	= longProduct[3]; //Product Total No Of Bags
		
		float 	fwProductRent 		= floatProduct[0]; //product Rent
		float 	fwTotalRent 		= floatProduct[1]; //over all calculation total rent
		
		if(fwIsItWithdraw){
			
			try {
				
				//Insert Data in hpmc_cs_booking_amount_charged
				long invoiceNumber = 0;
				com.hpmc.portal.db.service.model.CSBookingAmountManagement csBookingAmount = null;
				invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CSBookingAmountManagement.class.getName());
				csBookingAmount = CSBookingAmountManagementLocalServiceUtil.createCSBookingAmountManagement(invoiceNumber);
				csBookingAmount.setBOOKING_ID(fwBookingID);
				csBookingAmount.setBOOKING_AMOUNT_CHARGED(fwTotalRent);
				csBookingAmount.setTOTAL_PAYABLE_AMOUNT(fwTotalRent);
				csBookingAmount.setTOTAL_PAYABLE_PAYMENT_MODE("paymentMode");
				csBookingAmount.setADDITIONAL_PAYMENT_CHECK_DRAFT_DETAIL("123456789");
				CSBookingAmountManagementLocalServiceUtil.addCSBookingAmountManagement(csBookingAmount);
				
				//Update Data in hpmc_cs_product_booking_rel
				CSProductBookingManagement csProductBooking = CSProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(fwProductBookingId);
				csProductBooking.setINVOICE_NUMBER(csBookingAmount.getINVOICE_NUMBER());
				csProductBooking.setTO_DATE(new Date());
				csProductBooking.setWITHDRAW_NUMBER_OF_BAGS((int) fwWithDrawalBags);
				CSProductBookingManagementLocalServiceUtil.updateCSProductBookingManagement(csProductBooking);
				
			} catch ( NoSuchCSProductBookingManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
		}else{
			System.out.println("Unchecked");
		}
		
		
		System.out.println("fwIsItWithdraw="+fwIsItWithdraw+",fwWithdrawalType="+fwWithdrawalType+",fwWithDrawalBags="+
				fwWithDrawalBags+",fwTotalRent="+fwTotalRent+",fwProductRent="+fwProductRent);
		
	}
	
	public void partiallyWithdraw(String strProduct[],Long longProduct[],Float floatProduct[],Boolean checkBoxStatus){
		
		boolean pwIsItWithdraw 		= checkBoxStatus; //checkBox checked or not
		String 	pwWithdrawalType 	= strProduct[0]; //withdrawal Type
		
		long 	pwBookingID 		= longProduct[0]; //Booking Id
		long 	pwProductBookingId 	= longProduct[1]; //Product Booknig ID
		long 	pwWithDrawalBags 	= longProduct[2]; //WithDrawal No Of Bags
		long 	pwProductTotalNOB	= longProduct[3]; //Product Total No Of Bags
		long 	pwProductID	= longProduct[4]; //Product id
		
		float 	pwProductRent 		= floatProduct[0]; //product Rent
		float 	pwTotalRent 		= floatProduct[1]; //over all calculation total rent
		
		if(pwIsItWithdraw){

			try {
				
				long remainBags = pwProductTotalNOB - pwWithDrawalBags;
				
				//Insert Data in hpmc_cs_booking_amount_charged
				long invoiceNumber = 0;
				com.hpmc.portal.db.service.model.CSBookingAmountManagement csBookingAmount = null;
				invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CSBookingAmountManagement.class.getName());
				csBookingAmount = CSBookingAmountManagementLocalServiceUtil.createCSBookingAmountManagement(invoiceNumber);
				csBookingAmount.setBOOKING_ID(pwBookingID);
				csBookingAmount.setBOOKING_AMOUNT_CHARGED(pwTotalRent);
				csBookingAmount.setTOTAL_PAYABLE_AMOUNT(pwTotalRent);
				csBookingAmount.setTOTAL_PAYABLE_PAYMENT_MODE("paymentMode");
				csBookingAmount.setADDITIONAL_PAYMENT_CHECK_DRAFT_DETAIL("987654321");
				CSBookingAmountManagementLocalServiceUtil.addCSBookingAmountManagement(csBookingAmount);
				
				//Update Data in hpmc_cs_product_booking_rel 
				CSProductBookingManagement csProductBooking = CSProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(pwProductBookingId);
				csProductBooking.setWITHDRAW_NUMBER_OF_BAGS((int) pwWithDrawalBags);
				csProductBooking.setINVOICE_NUMBER(csBookingAmount.getINVOICE_NUMBER());
				csProductBooking.setTO_DATE(new Date());
				CSProductBookingManagementLocalServiceUtil.updateCSProductBookingManagement(csProductBooking);
				
				//New product Booking Create new record in CS_PRODUCT_BOOKING_REL
				long productBookingRelId = 0;
				productBookingRelId = CounterLocalServiceUtil.increment(CSProductBookingManagement.class.getName());
				CSProductBookingManagement csProductBookingManagement = null;
				csProductBookingManagement = CSProductBookingManagementLocalServiceUtil.createCSProductBookingManagement(productBookingRelId);
				csProductBookingManagement.setBOOKING_ID(pwBookingID);
				csProductBookingManagement.setPRODUCT_ID(pwProductID);
				csProductBookingManagement.setBOOKING_NUMBER_OF_BAGS((int) remainBags);
				csProductBookingManagement.setRENT_AMOUNT(pwProductRent);
				csProductBookingManagement.setFROM_DATE(new Date());
				CSProductBookingManagementLocalServiceUtil.addCSProductBookingManagement(csProductBookingManagement);
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
		}else{
			System.out.println("PUnchecked");
		}
		
		System.out.println("pwIsItWithdraw="+pwIsItWithdraw+",pwWithdrawalType="+pwWithdrawalType+",pwWithDrawalBags="+
				pwWithDrawalBags+",pwTotalRent="+pwTotalRent+",pwProductRent="+pwProductRent);
		
	}
	
	/*public void bookingIdSearch(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
	
		try {
			String cs_booking_no = actionRequest.getParameter("cs_booking_no");
			CSBooking csBookings = null;
			
			if(cs_booking_no != ""){
				long csBooking_no = Long.parseLong(cs_booking_no);
				//System.out.println("Booking :: Id="+csBooking_no);
				csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(csBooking_no);
			}
			actionRequest.setAttribute("csBookingObj", csBookings.getBOOKING_ID());
			actionRequest.setAttribute("bookingId", csBookings.getBOOKING_ID());
			actionRequest.setAttribute("bookedBy", csBookings.getBOOKED_BY());
			
		} catch (NoSuchCSBookingException e) { 
			actionRequest.setAttribute("message", "Please enter Correct Booking Id");
			actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/Message.jsp");
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}*/

	public void paymentAction(ActionRequest actionRequest,
			ActionResponse actionResponse)	throws IOException{
		try {
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void partiallyWithdrawPaymentAction(ActionRequest actionRequest,
			ActionResponse actionResponse)	throws IOException{
		try {
			long totalNoBags = Long.parseLong(actionRequest.getParameter("total_no_bags"));
			long withDrawBags = Long.parseLong(actionRequest.getParameter("with_draw_bags"));
			long productBookingId = Long.parseLong(actionRequest.getParameter("product_booking_id"));
			long productId = Long.parseLong(actionRequest.getParameter("product_id"));
			long bookingId = Long.parseLong(actionRequest.getParameter("booking_id"));
			float totalAmount = Float.parseFloat(actionRequest.getParameter("total_amount"));
			String paymentMode = actionRequest.getParameter("payment_mode");
			String paymentDetails = actionRequest.getParameter("cheque_draft_details");
			
			long remainBags = totalNoBags - withDrawBags;
			//System.out.println(paymentMode);
			
			//Insert Data in hpmc_cs_booking_amount_charged
			long invoiceNumber = 0;
			com.hpmc.portal.db.service.model.CSBookingAmountManagement csBookingAmount = null;
			invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CSBookingAmountManagement.class.getName());
			csBookingAmount = CSBookingAmountManagementLocalServiceUtil.createCSBookingAmountManagement(invoiceNumber);
			csBookingAmount.setBOOKING_ID(bookingId);
			csBookingAmount.setBOOKING_AMOUNT_CHARGED(totalAmount);
			csBookingAmount.setTOTAL_PAYABLE_AMOUNT(totalAmount);
			csBookingAmount.setTOTAL_PAYABLE_PAYMENT_MODE(paymentMode);
			csBookingAmount.setADDITIONAL_PAYMENT_CHECK_DRAFT_DETAIL(paymentDetails);
			CSBookingAmountManagementLocalServiceUtil.addCSBookingAmountManagement(csBookingAmount);
			
			//Update Data in hpmc_cs_product_booking_rel 
			CSProductBookingManagement csProductBooking = CSProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBookingId);
			csProductBooking.setWITHDRAW_NUMBER_OF_BAGS((int) withDrawBags);
			csProductBooking.setINVOICE_NUMBER(csBookingAmount.getINVOICE_NUMBER());
			csProductBooking.setRENT_AMOUNT(totalAmount);
			csProductBooking.setTO_DATE(new Date());
			CSProductBookingManagementLocalServiceUtil.updateCSProductBookingManagement(csProductBooking);
			
			//New product Booking Create new record in CS_PRODUCT_BOOKING_REL
			long productBookingRelId = 0;
			productBookingRelId = CounterLocalServiceUtil.increment(CSProductBookingManagement.class.getName());
			CSProductBookingManagement csProductBookingManagement = null;
			csProductBookingManagement = CSProductBookingManagementLocalServiceUtil.createCSProductBookingManagement(productBookingRelId);
			csProductBookingManagement.setBOOKING_ID(bookingId);
			csProductBookingManagement.setPRODUCT_ID(productId);
			csProductBookingManagement.setBOOKING_NUMBER_OF_BAGS((int) remainBags);
			csProductBookingManagement.setFROM_DATE(new Date());
			CSProductBookingManagementLocalServiceUtil.addCSProductBookingManagement(csProductBookingManagement);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fullWithdrawPayment(ActionRequest actionRequest,
			ActionResponse actionResponse)	throws IOException{
		long productBookingId = Long.parseLong(actionRequest.getParameter("product_booking_id"));
		long bookingId = Long.parseLong(actionRequest.getParameter("booking_id"));
		float totalAmount = Float.parseFloat(actionRequest.getParameter("total_amount"));
		String paymentMode = actionRequest.getParameter("payment_mode");
		String paymentDetails = actionRequest.getParameter("cheque_draft_details");
		
		try {
			//Insert Data in hpmc_cs_booking_amount_charged
			long invoiceNumber = 0;
			com.hpmc.portal.db.service.model.CSBookingAmountManagement csBookingAmount = null;
			invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CSBookingAmountManagement.class.getName());
			csBookingAmount = CSBookingAmountManagementLocalServiceUtil.createCSBookingAmountManagement(invoiceNumber);
			csBookingAmount.setBOOKING_ID(bookingId);
			csBookingAmount.setBOOKING_AMOUNT_CHARGED(totalAmount);
			csBookingAmount.setTOTAL_PAYABLE_AMOUNT(totalAmount);
			csBookingAmount.setTOTAL_PAYABLE_PAYMENT_MODE(paymentMode);
			csBookingAmount.setADDITIONAL_PAYMENT_CHECK_DRAFT_DETAIL(paymentDetails);
			CSBookingAmountManagementLocalServiceUtil.addCSBookingAmountManagement(csBookingAmount);
			
			//Update Data in hpmc_cs_product_booking_rel
			CSProductBookingManagement csProductBooking = CSProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBookingId);
			csProductBooking.setINVOICE_NUMBER(csBookingAmount.getINVOICE_NUMBER());
			csProductBooking.setRENT_AMOUNT(totalAmount);
			csProductBooking.setTO_DATE(new Date());
			CSProductBookingManagementLocalServiceUtil.updateCSProductBookingManagement(csProductBooking);
			
		} catch ( NoSuchCSProductBookingManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	
}
