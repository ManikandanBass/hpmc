package com.hpmc.portal.farmer.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.hpmc.portal.email.JavaMailSend;
import com.hpmc.portal.farmer.dos.CADetailDO;
import com.hpmc.portal.farmer.dos.CAInvoiceDO;

public class CABookingDAO {

	private Connection connect = null;
    private Statement statement = null;

    private ResultSet resultSet = null;

	private void openDBConnection() throws ClassNotFoundException, SQLException{
	
		 // This will load the MySQL driver, each DB has its own driver
        Class.forName("com.mysql.jdbc.Driver");
        // Setup the connection with the DB
        connect = DriverManager.getConnection("jdbc:mysql://localhost/hpmc_db?user=root&password=");
        
       
	}
	private void closeDBConnection() throws ClassNotFoundException, SQLException{
		resultSet.close();
		statement.close();
		connect.close();
		
	}
	
	 public List<CADetailDO>  getAvailableCapacity(CADetailDO inputCADetailDO) throws ClassNotFoundException, SQLException  {
	     List<CADetailDO> caDetailDOList = new ArrayList<CADetailDO>();   
		 CADetailDO caDetailDO = new CADetailDO();
	        	try {
					openDBConnection();
					
					// Statements allow to issue SQL queries to the database
					statement = connect.createStatement();
         
					// Result set get the result of the SQL query
					String SQLStatement = "SELECT * FROM ("
											+ "	SELECT "
											+ "		cato.CA_ID,	"
											+ "		cato.CA_NAME, "
											+ "		SUM(b.QUANTITY) as bookedQuantity,"
											+ "		cato.CAPACITY-SUM(b.QUANTITY) as remainingSpace,"
											+ "		cato.CAPACITY,IF((cato.CAPACITY-SUM(b.QUANTITY) >= " +inputCADetailDO.getQuantity() + ") , "
											+ "		'Yes','No') as statusVal "
											+ " FROM "
											+ "		hpmc_ca_booking b, "
											+ "		hpmc_controlled_atmosphere cato "
											+ " WHERE b.CA_ID = cato.CA_ID "
											+ " AND cato.LOCATION ='" + inputCADetailDO.getLocation() +"'"
											+ " AND (( b.FROM_DATE  >= '"	+ new java.sql.Date(inputCADetailDO.getBookingFromDate().getTime())     +"'"
													+ " AND b.FROM_DATE  <= '" 	+ new java.sql.Date(inputCADetailDO.getBookingToDate().getTime())   +"'"
											+ "		 	) OR (b.TO_DATE  >= '"	+ new java.sql.Date(inputCADetailDO.getBookingFromDate().getTime()) +"'" 
											+ " 		AND b.TO_DATE    <= '" 	+ new java.sql.Date(inputCADetailDO.getBookingToDate().getTime())   +"'))"
										+ " ) as custom_table "
									+ "WHERE custom_table.statusVal = 'Yes'"  ;
				
							resultSet = statement.executeQuery(SQLStatement);
							
					
					while (resultSet.next()) {
						caDetailDO = new CADetailDO();
						caDetailDO.setCA_ID(resultSet.getString("CA_ID"));
						caDetailDO.setCA_NAME(resultSet.getString("CA_NAME"));
						caDetailDO.setRemainingSpace(resultSet.getString("remainingSpace"));
						caDetailDO.setStatusVal(resultSet.getString("statusVal"));
						
						caDetailDOList.add(caDetailDO);
			        }
					
				} catch (Exception e) {
					e.printStackTrace();
				} finally{
					closeDBConnection();
				}

	        return	caDetailDOList ;
	    }
	 public List<CAInvoiceDO>  getAutoGenerateCAInvoice() throws ClassNotFoundException, SQLException  {
	     List<CAInvoiceDO> CAInvoiceDOList = new ArrayList<CAInvoiceDO>();   
	     CAInvoiceDO caInvoiceDO = new CAInvoiceDO();
	     
	     try {
	    	 	openDBConnection();
				
				// Statements allow to issue SQL queries to the database
				statement = connect.createStatement();
  
				// Result set get the result of the SQL query
				String SQLStatement = "SELECT "
						+ "u.firstName fname,u.lastName lname,"
						+ "u.emailAddress email,cab.BOOKING_ID bookingId,DATE_FORMAT(cab.FROM_DATE, '%d-%m-%Y') bookingDate,"
						+ "cab.AMOUNT_CHARGED totalRent,"
						+ "cab.FROM_DATE fromDate,cab.QUANTITY wieght,fud.AADHAR_NUM aadharNumber,"
						+ "fud.PAN_NUM panNumber,fud.MOBILE_NUM mobileNumber,"
						+ "date_add(CURRENT_DATE(), interval 10 day) as lastDueDate,"
						+ " (cab.AMOUNT_CHARGED/ TIMESTAMPDIFF(MONTH, cab.FROM_DATE, cab.TO_DATE)) as dueAmount "
						+ "FROM "
						+ "hpmc_ca_booking cab,hpmc_farmer_user_detail fud,user_ u "
						+ "WHERE "
						+ "cab.BOOKED_BY = fud.USER_ID AND u.userId = fud.USER_ID AND "
						+ "DAY(FROM_DATE) = DAY(CURDATE()) AND "
						+ "DATE_ADD(TO_DATE, INTERVAL 1 MONTH) >= CURDATE()";
				resultSet = statement.executeQuery(SQLStatement);
				while (resultSet.next()) {
					caInvoiceDO = new CAInvoiceDO();
					caInvoiceDO.setFname(resultSet.getString("fname"));
					caInvoiceDO.setLname(resultSet.getString("lname"));
					caInvoiceDO.setEmail(resultSet.getString("email"));
					caInvoiceDO.setBookingId(resultSet.getString("bookingId"));
					caInvoiceDO.setBookingDate(resultSet.getString("bookingDate"));
					caInvoiceDO.setTotalRent(resultSet.getString("totalRent"));
					caInvoiceDO.setFromDate(resultSet.getString("fromDate"));
					caInvoiceDO.setWieght(resultSet.getString("wieght"));
					caInvoiceDO.setAadharNumber(resultSet.getString("aadharNumber"));
					caInvoiceDO.setPanNumber(resultSet.getString("panNumber"));
					caInvoiceDO.setMobileNumber(resultSet.getString("mobileNumber"));
					caInvoiceDO.setDueAmount(resultSet.getString("dueAmount"));
					caInvoiceDO.setDueLastDate(resultSet.getString("lastDueDate"));
					CAInvoiceDOList.add(caInvoiceDO);
		        }
				
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			closeDBConnection();
		}
		return CAInvoiceDOList;
		 
	 }
	 
	 public static void main(String args[]) throws Exception{
		 CABookingDAO caBookingDAO = new CABookingDAO();
		 CADetailDO caDetailDO = new CADetailDO();
		 
//		 SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");  
//		 caDetailDO.setBookingFromDate(simpleDateFormat.parse("2017-08-01"));
//		 caDetailDO.setBookingToDate(simpleDateFormat.parse("2017-01-31"));
//		 caDetailDO.setLocation("bangalore");
//		 caDetailDO.setQuantity("1500");
//		 caBookingDAO.getAvailableCapacity(caDetailDO);
		 
		 
		 List<CAInvoiceDO> CAInvoiceDOList = caBookingDAO.getAutoGenerateCAInvoice();
		 for(CAInvoiceDO invoice : CAInvoiceDOList) {
	            
	             String subject = "Invoice Report From HPMC";
	             String toEmail = invoice.getEmail();
	             String body = "<h1>Farmer Booking Invioce</h1>"
						+ "<table>"
						+ "<tr><td>Name			:</td><td>"+invoice.getFname()+" "+ invoice.getLname() + "</td></tr>"
						+ "<tr><td>Email			:</td><td>"+ invoice.getEmail() + "</td></tr>"
						+ "<tr><td>Phone Number	:</td><td>"+ invoice.getMobileNumber() + "</td></tr>"
						+ "<tr><td>Aadhar Number	:</td><td>"+ invoice.getAadharNumber() + "</td></tr>"
						+ "<tr><td>Booking ID 	:</td><td>"+ invoice.getBookingId() + "</td></tr>"
						+ "<tr><td>Booking Date 	: </td><td>"+ invoice.getBookingDate() + "</td></tr>"
						+ "<tr><td>Booking Weight :</td><td>"+ invoice.getWieght() + "</td></tr>"
						+ "<tr><td>Due Amount 	: </td><td>"+ invoice.getDueAmount() + "</td></tr>"
						+ "<tr><td>Due Last Date	: </td><td>"+ invoice.getDueLastDate() + "</td></tr>"
						+ "</table>";
	            
	            JavaMailSend.TLSMail(toEmail, subject, body);
	            
	        }
	 }
}
