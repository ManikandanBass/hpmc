package com.hpmc.portal.farmer.controller;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.hpmc.portal.db.service.model.CSBooking;
import com.hpmc.portal.db.service.service.CSBookingLocalServiceUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CSWithdraw_old extends MVCPortlet {

	public void findProductsByBookingOrderIdURL(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException{
		try {
			String cs_booking_no = actionRequest.getParameter("cs_booking_no");
			actionResponse.setRenderParameter("cs_booking_no", cs_booking_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void doView(RenderRequest renderRequest,RenderResponse renderResponse) throws IOException {
		
		try {
			java.util.List<CSBooking> csBookings = null;
			
			String cs_booking_no = ParamUtil.get(renderRequest,"cs_booking_no","");
			if(cs_booking_no != ""){
				long csBooking_no = Long.parseLong(cs_booking_no);
				csBookings = CSBookingLocalServiceUtil.findByBOOKED_BY(csBooking_no);
			}
			renderRequest.setAttribute("csBookingObj", csBookings);
			super.doView(renderRequest, renderResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
}
