package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;








import com.hpmc.portal.db.service.service.CAChamberRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CARegistrationLocalServiceUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.hpmc.portal.db.service.model.CARegistration;



public class CAChamberRegistration extends MVCPortlet {

	public void searchChambersByCALocation(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException{
		String ca_id = actionRequest.getParameter("ca_id");
		actionResponse.setRenderParameter("ca_id", ca_id);
	}
	
	public void chamberDetailsUpdate(ActionRequest actionRequest,ActionResponse actionResponse)throws IOException {
		
		
		try {
			
			String agmUser = actionRequest.getParameter("user_id");
			String ca_chmb_id = actionRequest.getParameter("ca_chamber_id");
			//float chm_rent = Float.parseFloat(actionRequest.getParameter("chamber_rent"));
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date openDate = (Date) formatter.parse(actionRequest.getParameter("openDate"));
			Date closeDate = (Date) formatter.parse(actionRequest.getParameter("closeDate"));
			String chamberStatus = actionRequest.getParameter("chamberStatus");
			long intChmbId = Long.parseLong(ca_chmb_id);
			long intAgmUser = Long.parseLong(agmUser);

			com.hpmc.portal.db.service.model.CAChamberRegistration caChamberRegistration = CAChamberRegistrationLocalServiceUtil.findByCA_CHAMBER_ID(intChmbId);
			caChamberRegistration.setCHAMBER_OPRATOR_ID(intAgmUser);
			caChamberRegistration.setCHAMBER_OPNING_DATE(openDate);
			caChamberRegistration.setCHAMBER_CLOSING_DATE(closeDate);
			caChamberRegistration.setCHAMBER_STATUS(chamberStatus);
			//caChamberRegistration.setCHAMBER_RENT(chm_rent);
			CAChamberRegistrationLocalServiceUtil.updateCAChamberRegistration(caChamberRegistration);
			
			String ca_id = actionRequest.getParameter("ca_id");
			actionResponse.setRenderParameter("ca_id", ca_id);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void doView(RenderRequest renderRequest,RenderResponse renderResponse) throws IOException{
		boolean inuptCA= false;
		try {
			
			List<com.hpmc.portal.db.service.model.CAChamberRegistration> caChamberRegistrations = Collections.<com.hpmc.portal.db.service.model.CAChamberRegistration>emptyList();
			String ca_id = ParamUtil.get(renderRequest, "ca_id","");
			CARegistration profitCenter=null;
			
			if(ca_id != ""){
				long intCAID = Long.parseLong(ca_id);
				caChamberRegistrations = CAChamberRegistrationLocalServiceUtil.findByCA_ID(intCAID);
				profitCenter = CARegistrationLocalServiceUtil.findByCA_ID(intCAID);
				inuptCA = true;
			}
			
			
			
			List<CARegistration> CALocationList = CARegistrationLocalServiceUtil.getCARegistrations(0, CARegistrationLocalServiceUtil.getCARegistrationsCount());
			renderRequest.setAttribute("caLocationList", CALocationList);
			renderRequest.setAttribute("chamberList", caChamberRegistrations);
			renderRequest.setAttribute("inputca_id", ca_id);
			renderRequest.setAttribute("profitCenter", profitCenter);
			renderRequest.setAttribute("inuptCA", inuptCA);
			super.doView(renderRequest, renderResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
}
