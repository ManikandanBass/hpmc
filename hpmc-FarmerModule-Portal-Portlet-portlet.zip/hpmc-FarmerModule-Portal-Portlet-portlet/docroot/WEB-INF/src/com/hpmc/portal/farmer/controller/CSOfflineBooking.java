package com.hpmc.portal.farmer.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.hpmc.portal.db.service.NoSuchCSBookingException;
import com.hpmc.portal.db.service.NoSuchCSProductBookingManagementException;
import com.hpmc.portal.db.service.NoSuchFarmerRegistrationException;
import com.hpmc.portal.db.service.model.AddressRegistration;
import com.hpmc.portal.db.service.model.CSBookedProductFloorManagement;
import com.hpmc.portal.db.service.model.CSChamberFloorBookingRegistration;
import com.hpmc.portal.db.service.model.CSChamberRegistration;
import com.hpmc.portal.db.service.model.CSProductBookingManagement;
import com.hpmc.portal.db.service.model.CSProductRegistration;
import com.hpmc.portal.db.service.model.CSRegistration;
import com.hpmc.portal.db.service.model.CustomerRegistration;
import com.hpmc.portal.db.service.model.FarmerRegistration;
import com.hpmc.portal.db.service.model.UserRegistration;
import com.hpmc.portal.db.service.service.AddressRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSBookedProductFloorManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSBookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSChamberFloorBookingRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSChamberRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductBookingManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CustomerRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.FarmerRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.UserRegistrationLocalServiceUtil;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Company;
import com.liferay.portal.model.User;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CSOfflineBooking extends MVCPortlet {

	//================================================USING FUNCTIONS STARTS=================================================//
	
	//Offline User Details Stored
	public void customerRegistration(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		try {
			String customerName = actionRequest.getParameter("customerName");
			String fatherHusbandName = actionRequest.getParameter("fatherHusbandName");
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date birthdate = (Date) formatter.parse(actionRequest.getParameter("birthdate"));
			String gender = actionRequest.getParameter("gender");
			String houseNo = actionRequest.getParameter("houseNo");
			String area = actionRequest.getParameter("area");
			String landmark = actionRequest.getParameter("landmark");
			String district = actionRequest.getParameter("district");
			String state = actionRequest.getParameter("state");
			int pinCode = Integer.parseInt(actionRequest.getParameter("pinCode"));
			String email = actionRequest.getParameter("email");
			long aadharNo = Long.parseLong(actionRequest.getParameter("aadharNo")) ;
			String panNo = actionRequest.getParameter("panNo");
			String electionCardNo = actionRequest.getParameter("electionNo");
			long mobileNo = Long.parseLong(actionRequest.getParameter("mobileNo"));
				Date creationDate=java.util.Calendar.getInstance().getTime();
				
					
					long customerAddressId = 0;
					AddressRegistration customerAddressRegistration = null;
					customerAddressId = CounterLocalServiceUtil.increment(AddressRegistration.class.getName());
					customerAddressRegistration = AddressRegistrationLocalServiceUtil.createAddressRegistration(customerAddressId);
					
					customerAddressRegistration.setFLAT_HOUSE_DOOR_NUM(houseNo);
					customerAddressRegistration.setVILLAGE_AREA_LOCALITY(area);
					customerAddressRegistration.setROAD_STREET_LANDMARK(landmark);
					customerAddressRegistration.setCITY_DISTRICT(district);
					customerAddressRegistration.setSTATE_UNIONTERITORY(state);
					customerAddressRegistration.setPINCODE(pinCode);
					AddressRegistrationLocalServiceUtil.addAddressRegistration(customerAddressRegistration);
					
					
					long customerUserId = 0;
					customerUserId = CounterLocalServiceUtil.increment(User.class.getName());
					UserRegistration customerUserRegistration = null;
					customerUserRegistration = UserRegistrationLocalServiceUtil.createUserRegistration(customerUserId);
					
					customerUserRegistration.setFULL_NAME(customerName);
					customerUserRegistration.setFATHER_HUSBAND_NAME(fatherHusbandName);
					customerUserRegistration.setDATE_OF_BIRTH(birthdate);
					customerUserRegistration.setGENDER(gender);
					customerUserRegistration.setUSER_NAME(email);
					customerUserRegistration.setUSER_ROLE(HPMCConstant.ROLE_CUSTOMER);
					customerUserRegistration.setCREATION_DATE(creationDate);
					UserRegistrationLocalServiceUtil.addUserRegistration(customerUserRegistration);
					
					CustomerRegistration customerRegistration = null;
					customerRegistration = CustomerRegistrationLocalServiceUtil.createCustomerRegistration(customerUserId);
					customerRegistration.setAADHAR_NUM(aadharNo);
					customerRegistration.setELECTION_CARD_NUM(electionCardNo);
					customerRegistration.setPAN_NUM(panNo);
					customerRegistration.setMOBILE_NUM(mobileNo);
					CustomerRegistrationLocalServiceUtil.addCustomerRegistration(customerRegistration);
					
					actionRequest.setAttribute("customer_user_id", customerUserId);
					
					//----------------CS Location ----------//
					List<CSRegistration> csRegistrationList = null;
					
						Set locationSet= new HashSet();
						List<CSRegistration> csRegistrationsLists = CSRegistrationLocalServiceUtil.getCSRegistrations(0, CSRegistrationLocalServiceUtil.getCSRegistrationsCount());
						for (Iterator iterator = csRegistrationsLists.iterator(); iterator
								.hasNext();) {
							CSRegistration csRegistration = (CSRegistration) iterator
									.next();
							locationSet.add(csRegistration.getLOCATION());
						}
						List locationList= new ArrayList(locationSet);
						actionRequest.setAttribute("csRegistrationsLists",locationList );
					
					actionResponse.setRenderParameter("jspPage", "/html/cs/offline-booking/offline-booking.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//New Booking Products Created Records
	public void nextOfflineBooking(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			//long customerName = actionRequest.getParameter("customer_user_name");
			//System.out.println("customerName:"+customerName);
			
			String location = actionRequest.getParameter("csLocation");
			//Insert Data in CS_Booking
			long CS_ID = Long.parseLong(actionRequest.getParameter("CSID"));
			long farmerUserid = Long.parseLong(actionRequest.getParameter("customer_user_id"));
			String farmerUserName = actionRequest.getParameter("customer_user_name");
			
			long csBookingId = 0;
			com.hpmc.portal.db.service.model.CSBooking csBooking = null;
			csBookingId = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CSBooking.class.getName());
			csBooking = CSBookingLocalServiceUtil.createCSBooking(csBookingId);
			csBooking.setBOOKED_BY(farmerUserid);
			csBooking.setCS_ID(CS_ID);
			csBooking.setBOOKING_DATE(new Date());
			CSBookingLocalServiceUtil.addCSBooking(csBooking);
			long lastBookingId = csBooking.getBOOKING_ID();
        	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date fromDate = (Date) formatter.parse(actionRequest.getParameter("fromDate").trim());

			//Insert Data in CS_PRODUCT_BOOKING_REL
			String rowIndexes = actionRequest.getParameter("rowIndexes");
	        String[] indexOfRows = rowIndexes.split(",");
	        
	        for (int i = 0; i < indexOfRows.length; i++) {
	        	long productId = Long.parseLong(actionRequest.getParameter("productType"+ indexOfRows[i]).trim());
	        	long number_of_bags = Long.parseLong(actionRequest.getParameter("number_of_bags"+ indexOfRows[i]).trim());
	        	
	        	CSProductRegistration productRegistration = CSProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
				//Insert Data in CS_PRODUCT_BOOKING_REL
				long productBookingRelId = 0;
				productBookingRelId = CounterLocalServiceUtil.increment(CSProductBookingManagement.class.getName());
				CSProductBookingManagement csProductBookingManagement = null;
				csProductBookingManagement = CSProductBookingManagementLocalServiceUtil.createCSProductBookingManagement(productBookingRelId);
				csProductBookingManagement.setBOOKING_ID(lastBookingId);
				csProductBookingManagement.setPRODUCT_ID(productId);
				csProductBookingManagement.setRENT_AMOUNT(productRegistration.getRENT());
				csProductBookingManagement.setBOOKING_NUMBER_OF_BAGS((int) number_of_bags);
				csProductBookingManagement.setFROM_DATE(fromDate);
				CSProductBookingManagementLocalServiceUtil.addCSProductBookingManagement(csProductBookingManagement);
			}
	        actionRequest.setAttribute("csBookingObj", lastBookingId);
			actionRequest.setAttribute("bookingId", lastBookingId);
			actionRequest.setAttribute("bookedBy", farmerUserid);
			actionResponse.setRenderParameter("jspPage", "/html/cs/offline-booking/assign-product-storage.jsp");
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}
	
	//Change Count of Total No of Bags.
	public void changeProductBookingBagsCount(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
			long booking_id = Long.parseLong(actionRequest.getParameter("booking_id"));
			long product_booking_id = Long.parseLong(actionRequest.getParameter("product_booking_id"));
			long storageTotalNoBags = Long.parseLong(actionRequest.getParameter("storage_total_no_bags"));
			
			try {
				
				long totalBookedNoBags= 0;
				List<CSChamberFloorBookingRegistration> chamberFloorBookingRegistrations = CSChamberFloorBookingRegistrationLocalServiceUtil.findByPRODUCT_BOOKING_ID(product_booking_id);
				for(CSChamberFloorBookingRegistration chmFloorBookingReg: chamberFloorBookingRegistrations ){
					totalBookedNoBags = totalBookedNoBags + chmFloorBookingReg.getSTORED_NUMBER_OF_BAGS();
				}
				
				com.hpmc.portal.db.service.model.CSBooking csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(booking_id);
				if(totalBookedNoBags < storageTotalNoBags){
					CSProductBookingManagement productBookingManagement = CSProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(product_booking_id);
					productBookingManagement.setTOTAL_NUMBER_OF_BAGS((int) storageTotalNoBags);
					CSProductBookingManagementLocalServiceUtil.updateCSProductBookingManagement(productBookingManagement);
				}else{
					actionRequest.setAttribute("messages", "Please Must Enter Change Storage No Bags Count greater than Booked No of Bags. ");
				}
				
				actionRequest.setAttribute("csBookingObj", csBookings.getBOOKING_ID());
				actionRequest.setAttribute("bookingId", csBookings.getBOOKING_ID());
				actionRequest.setAttribute("bookedBy", csBookings.getBOOKED_BY());
				actionResponse.setRenderParameter("jspPage", "/html/cs/offline-booking/product-storage/assign-product-storage.jsp");
				
				
			} catch (NoSuchCSProductBookingManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SystemException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchCSBookingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	//Product Details Stored when booking Time
	public void assignProductStorage(ActionRequest actionRequest,ActionResponse actionResponse) 
			throws IOException{
		try {
			String cs_booking_no = actionRequest.getParameter("cs_booking_no");
			com.hpmc.portal.db.service.model.CSBooking csBookings = null;
			
			if(cs_booking_no != ""){
				long csBooking_no = Long.parseLong(cs_booking_no);
				//System.out.println("Booking :: Id="+csBooking_no);
				csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(csBooking_no);
			}
			actionRequest.setAttribute("csBookingObj", csBookings.getBOOKING_ID());
			actionRequest.setAttribute("bookingId", csBookings.getBOOKING_ID());
			actionRequest.setAttribute("bookedBy", csBookings.getBOOKED_BY());
			actionResponse.setRenderParameter("jspPage", "/html/cs/offline-booking/assign-product-storage.jsp");
		} catch (NoSuchCSBookingException e) { 
			actionRequest.setAttribute("message", "Please enter Correct Booking Id");
			actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/Message.jsp");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//Assign Location To Product when We are trying Storing Products.
	public void assignProductSubmit(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		long csbooking_id =	Long.parseLong(actionRequest.getParameter("booking_id").trim());
		long csProductbookingId =	Long.parseLong(actionRequest.getParameter("product_booking_id").trim());
		long csChamberId 		=	Long.parseLong(actionRequest.getParameter("chamber_id").trim());
		long csFloorRackNo 		=	Long.parseLong(actionRequest.getParameter("floor_rack").trim());
		String csLotNumber 		=	actionRequest.getParameter("lot_number").trim();
		long csNumberOfBags 	=	Long.parseLong(actionRequest.getParameter("no_of_bags_to_store").trim());
		try {
			
			long chamberFloorId = 0;
			CSChamberFloorBookingRegistration floorBookingRegistration = null;
			chamberFloorId = CounterLocalServiceUtil.increment(CSChamberFloorBookingRegistration.class.getName());
			floorBookingRegistration = CSChamberFloorBookingRegistrationLocalServiceUtil.createCSChamberFloorBookingRegistration(chamberFloorId);
			floorBookingRegistration.setCS_CHAMBER_ID(csChamberId);
			floorBookingRegistration.setFLOOR_RACK_NO(csFloorRackNo);
			floorBookingRegistration.setLOT_NUM(csLotNumber);
			floorBookingRegistration.setSTORED_NUMBER_OF_BAGS((int) csNumberOfBags);
			floorBookingRegistration.setPRODUCT_BOOKING_ID(csProductbookingId);
			CSChamberFloorBookingRegistrationLocalServiceUtil.addCSChamberFloorBookingRegistration(floorBookingRegistration);
			
			long productBookingFloorRel = 0;
			CSBookedProductFloorManagement productFloorManagement = null;
			productBookingFloorRel = CounterLocalServiceUtil.increment(CSBookedProductFloorManagement.class.getName());
			productFloorManagement = CSBookedProductFloorManagementLocalServiceUtil.createCSBookedProductFloorManagement(productBookingFloorRel);
			productFloorManagement.setPRODUCT_BOOKING_ID(csProductbookingId);
			productFloorManagement.setCHAMBER_FLOOR_ID(floorBookingRegistration.getCHAMBER_FLOOR_ID());
			CSBookedProductFloorManagementLocalServiceUtil.addCSBookedProductFloorManagement(productFloorManagement);
			
			com.hpmc.portal.db.service.model.CSBooking csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(csbooking_id);
			actionRequest.setAttribute("csBookingObj", csBookings.getBOOKING_ID());
			actionRequest.setAttribute("bookingId", csBookings.getBOOKING_ID());
			actionRequest.setAttribute("bookedBy", csBookings.getBOOKED_BY());
			actionRequest.setAttribute("messages", "Products successfully stored");
			actionRequest.setAttribute("status", "success");
			actionResponse.setRenderParameter("jspPage", "/html/cs/offline-booking/product-storage/assign-product-storage.jsp");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	//serveResource Function
	public void serveResource(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) throws IOException,
			PortletException {
		String cmd = ParamUtil.getString(resourceRequest, "cmd");
		if(cmd.length() > 0){
			ArrayList<String> arrayList = new ArrayList<String>();
			JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
			try {
				
				String CSName ="", CSId ="";
				if(cmd.equalsIgnoreCase("ajaxCall")){
					//===================Find Cold Storage List Based on Location
					if (ParamUtil.getString(resourceRequest, "csLocation") != null) {
						String CSLocationName = ParamUtil.getString(
								resourceRequest, "csLocation");
						List<com.hpmc.portal.db.service.model.CSRegistration> CSlist = CSRegistrationLocalServiceUtil
								.findByLOCATION(CSLocationName);
						for (com.hpmc.portal.db.service.model.CSRegistration csRegistration : CSlist) {

							JSONObject jsonObject = JSONFactoryUtil
									.createJSONObject();
							jsonObject.put("CSId", csRegistration.getCS_ID());
							jsonObject.put("CSName",
									csRegistration.getCS_NAME());
							jsonArray.put(jsonObject);

						}
					}
					
					
					//===================Find Product List Based on Cold Storage
					if (ParamUtil.getString(resourceRequest, "find_csid_chamber") != null) {
						long ajax_csid = Long.parseLong(ParamUtil.getString(
								resourceRequest, "find_csid_chamber"));
						List<com.hpmc.portal.db.service.model.CSProductRegistration> Productlist = CSProductRegistrationLocalServiceUtil
								.findByCS_ID(ajax_csid);
						for (com.hpmc.portal.db.service.model.CSProductRegistration csProduct : Productlist) {
							
							JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
							jsonObject.put("ProductId", csProduct.getPRODUCT_ID());
							jsonObject.put("ProductName",csProduct.getPRODUCT_NAME());
							jsonObject.put("ProductRent",csProduct.getRENT());
							jsonArray.put(jsonObject);
							
						}
					}
					
					
					Iterator<String> iterator = arrayList.iterator();
					while (iterator.hasNext()) {
						String name = (String) iterator.next();
					}
				}
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			PrintWriter writer = resourceResponse.getWriter();
	        writer.write(jsonArray.toString());
	        writer.flush();
		}
		
        
        String cs_id = ParamUtil.getString(resourceRequest, "cs_id");
        String booking_id = ParamUtil.getString(resourceRequest, "booking_id");
        String farmerUserid = ParamUtil.getString(resourceRequest, "farmerUserid");
        
        if(cs_id.length() > 0 && booking_id.length() > 0 && farmerUserid.length() > 0){
		        try {
		        	CSRegistration csObj = CSRegistrationLocalServiceUtil.findByCS_ID(Long.parseLong(cs_id));
		        	UserRegistration userRegistration = UserRegistrationLocalServiceUtil.findByUSER_ID(Long.parseLong(farmerUserid));
		        	FarmerRegistration farmerRegistration = FarmerRegistrationLocalServiceUtil.findByUSER_ID(Long.parseLong(farmerUserid));
		        	
		        	
					String rType = ParamUtil.getString(resourceRequest, "reportType");
					String searchdata = resourceRequest.getParameter("searchData");
					SimpleDateFormat dateFormat=new SimpleDateFormat("dd/mm/yyyy");
					String date=dateFormat.format(new Date());
					
					Element root;
			        HttpServletRequest request = PortalUtil.getHttpServletRequest(resourceRequest);
			        HttpSession session = request.getSession();
			        
			        ThemeDisplay themeDisplay = (ThemeDisplay)resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
			        Company company = themeDisplay.getCompany();
		          
		            Document document = new Document();
		            ByteArrayOutputStream baos = new ByteArrayOutputStream();
		            PdfWriter.getInstance(document, baos);
		            
		            Font fontTitle = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL);
		            fontTitle.setColor(0, 0, 155);
		            Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
//		            --------------------------------------------------Adddress And Logo-----------------------------------------------------------
		            
		            document.addTitle("Invoice");
		            document.setPageSize(PageSize.A4);
		            
		            document.open();
		            
		            Paragraph titleParagraph=new Paragraph("HPMC- Head Office",fontTitle);
		            titleParagraph.setAlignment(Element.ALIGN_RIGHT);
		            document.add(titleParagraph);
		            Paragraph addressLine1=new Paragraph("3rd Floor, Nigam Vihar, Shimla-171002 (H.P)",boldFont);
		            addressLine1.setAlignment(Element.ALIGN_RIGHT);
		           // addressLine1.setAlignment(Element.ALIGN_JUSTIFIED_ALL);
		            document.add(addressLine1);
		            Paragraph addressLine2=new Paragraph("Tel No: +91-1772623835, 2623823, 2623832, 2623836",boldFont);
		            addressLine2.setAlignment(Element.ALIGN_RIGHT);
		            //addressLine2.setAlignment(Element.ALIGN_JUSTIFIED_ALL);
		            document.add(addressLine2);
		            Paragraph addressLine3=new Paragraph("E-mail : hpmcshimla@live.com",boldFont);
		            addressLine3.setAlignment(Element.ALIGN_RIGHT);
		           // addressLine3.setAlignment(Element.ALIGN_JUSTIFIED_ALL);
		            document.add(addressLine3);
		            
		            //--------------------------------------------------Invoice No. And Booking Date and id----------------------------------------- 

		            Paragraph headDetails=new Paragraph("CS Offline Booking Receipt  ",boldFont);
		            headDetails.setAlignment(Element.ALIGN_CENTER);
		            document.add(headDetails);
		            
		            document.add(new Paragraph("\n"));
		            document.add(new Paragraph("\n"));
		            Paragraph invoiceNo=new Paragraph("Invoice Number : "+searchdata,boldFont);
		            invoiceNo.setAlignment(Element.ALIGN_LEFT);
		            Paragraph bookingDate=new Paragraph("Booking Date : "+date,boldFont);
		            bookingDate.setAlignment(Element.ALIGN_LEFT);
		            Paragraph bookingId=new Paragraph("Booking_Id : "+booking_id,boldFont);
		            bookingId.setAlignment(Element.ALIGN_LEFT);
		            
		            document.add(invoiceNo);
		            document.add(bookingId);
		            document.add(bookingDate);
		            
		            //--------------------------------------------------------Address----------------------------------------------------- 
		            
		            document.add(new Paragraph("\n"));
		            document.add(new Paragraph("\n"));
		            Font fontDetails = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL);
		            PdfPCell titleCell,titleCell1,titleCell2,titleCell3,titleCell4,titleCell5,titleCell6;
		           
		            PdfPTable title =new PdfPTable(2);
		            //Column 1
		            titleCell = new PdfPCell(new Phrase("Cold Storage Details  ",boldFont));
		            titleCell.setVerticalAlignment(PdfPTable.ALIGN_LEFT);
		            titleCell.setBorder(Rectangle.NO_BORDER);
		            title.addCell(titleCell);
		            //Column 2
		            titleCell = new PdfPCell(new Phrase("Farmer Details  ",boldFont));
		            titleCell.setVerticalAlignment(PdfPTable.ALIGN_RIGHT);
		            titleCell.setBorder(Rectangle.NO_BORDER);
		          
		            title.addCell(titleCell);
		            document.add(title);
		            
		            PdfPTable title1 =new PdfPTable(2);
		            //Column 1
		            titleCell1 = new PdfPCell(new Phrase("Cold Storage ID :  "+ csObj.getCS_ID(),fontDetails));
		            titleCell1.setVerticalAlignment(PdfPTable.ALIGN_LEFT);
		            titleCell1.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell1);
		            //Column 2
		            titleCell1 = new PdfPCell(new Phrase("Farmer Name :  "+ userRegistration.getFULL_NAME(),fontDetails));
		            titleCell1.setVerticalAlignment(PdfPTable.ALIGN_RIGHT);
		            titleCell1.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell1);
		            
		           
		            //Column 1
		            titleCell2 = new PdfPCell(new Phrase("Cold Storage Name :  "+ csObj.getCS_NAME(),fontDetails));
		            titleCell2.setVerticalAlignment(PdfPTable.ALIGN_LEFT);
		            titleCell2.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell2);
		            //Column 2
		            titleCell2 = new PdfPCell(new Phrase("Mobile No. :  "+ farmerRegistration.getMOBILE_NUM(),fontDetails));
		            titleCell2.setVerticalAlignment(PdfPTable.ALIGN_RIGHT);
		            titleCell2.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell2);
		            
		             
		            
		            //Column 1
		            titleCell3 = new PdfPCell(new Phrase("Cold Storage Location :  "+ csObj.getLOCATION(),fontDetails));
		            titleCell3.setVerticalAlignment(PdfPTable.ALIGN_LEFT);
		            titleCell3.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell3);
		            //Column 2
		            titleCell3 = new PdfPCell(new Phrase("Email_Id :  "+"ABC",fontDetails));
		            titleCell3.setVerticalAlignment(PdfPTable.ALIGN_RIGHT);
		            titleCell3.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell3);
		           
		            
		            
		           
		            //Column 1
		            titleCell4 = new PdfPCell(new Phrase());
		            titleCell4.setVerticalAlignment(PdfPTable.ALIGN_LEFT);
		            titleCell4.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell4);
		            //Column 2
		            titleCell4 = new PdfPCell(new Phrase("Aadhar Number :  "+ farmerRegistration.getAADHAR_NUM(),fontDetails));
		            titleCell4.setVerticalAlignment(PdfPTable.ALIGN_RIGHT);
		            titleCell4.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell4);
		            
		            titleCell5 = new PdfPCell(new Phrase());
		            titleCell5.setVerticalAlignment(PdfPTable.ALIGN_LEFT);
		            titleCell5.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell5);
		            //Column 2
		            titleCell5 = new PdfPCell(new Phrase("Role Name :  "+ userRegistration.getUSER_ROLE(),fontDetails));
		            titleCell5.setVerticalAlignment(PdfPTable.ALIGN_RIGHT);
		            titleCell5.setBorder(Rectangle.NO_BORDER);
		            title1.addCell(titleCell5);
		            
		            
		            document.add(title1);
		             
		             //--------------------------------------------------------Production Detail Title-----------------------------------------------
		             
		             document.add(new Paragraph("\n"));
			         document.add(new Paragraph("\n"));
			            
		             Paragraph prodDetails=new Paragraph("Chamber Details  ",boldFont);
		             prodDetails.setAlignment(Element.ALIGN_LEFT);
		             document.add(prodDetails);
		             
		             document.add(new Paragraph("\n"));
		
		             PdfPTable prodTitle = new PdfPTable(3);
		             PdfPCell prodTitleCell;
		             // first row
		             // column 1
		             prodTitleCell = new PdfPCell(new Phrase("Chamber Details(Chamber Name,Floor Number,Number Of Bags,Lot Number)",boldFont));
		             prodTitle.addCell(prodTitleCell);
		             // column 2
		             prodTitleCell = new PdfPCell(new Phrase("CS Product Name ",boldFont));
		             prodTitleCell.setPaddingLeft(2);
		             prodTitle.addCell(prodTitleCell);
		             // column 3
		             prodTitleCell = new PdfPCell();
		             prodTitleCell = new PdfPCell(new Phrase("CS BOOKING NUMBER OF BAGS",boldFont));
		             prodTitle.addCell(prodTitleCell);
		             
		             document.add(prodTitle);
		             
		           // --------------------------------------------------------Production Detail Data-----------------------------------------------
		             List<CSProductBookingManagement> bookingManagements = CSProductBookingManagementLocalServiceUtil.findByBOOKING_ID(Long.parseLong(booking_id));
		             if(bookingManagements==null){
		            	 PdfPTable prodData = new PdfPTable(3);
			             PdfPCell prodDataCell;
			             // first row
			             // column 1
			             prodDataCell = new PdfPCell(new Phrase(" ",fontDetails));
			             prodData.addCell(prodDataCell);
			             // column 2
			             prodDataCell = new PdfPCell(new Phrase(" ",fontDetails));
			             prodDataCell.setPaddingLeft(2);
			             prodData.addCell(prodDataCell);
			             // column 3
			             prodDataCell = new PdfPCell();
			             prodDataCell = new PdfPCell(new Phrase(" ",fontDetails));
			             prodData.addCell(prodDataCell);
			             
			             document.add(prodData);
		             }
		             if(bookingManagements!=null){
		            	 for(CSProductBookingManagement bookingRegistration:bookingManagements){
			            	 
		            		 CSProductRegistration csProductObj = CSProductRegistrationLocalServiceUtil.findByPRODUCT_ID(bookingRegistration.getPRODUCT_ID());
		         			 List<CSChamberFloorBookingRegistration> floorBookingRegistrations = CSChamberFloorBookingRegistrationLocalServiceUtil.findByPRODUCT_BOOKING_ID(bookingRegistration.getPRODUCT_BOOKING_ID());
		            		 
			            	 PdfPTable prodData = new PdfPTable(3);
				             PdfPCell prodDataCell;
				             for(CSChamberFloorBookingRegistration floorBooking: floorBookingRegistrations) {
				            	 CSChamberRegistration chamberRegistration = CSChamberRegistrationLocalServiceUtil.findByCS_CHAMBER_ID(floorBooking.getCS_CHAMBER_ID());
				            	 // first row
					             // column 1
					             prodDataCell = new PdfPCell(new Paragraph(
					            		 chamberRegistration.getCS_CHAMBER_DESC()+"|"+floorBooking.getFLOOR_RACK_NO()+"|"+floorBooking.getSTORED_NUMBER_OF_BAGS()+"|"+floorBooking.getLOT_NUM()
					            		 ,fontDetails));
					             prodData.addCell(prodDataCell);
					             
				             }
				          // column 2
				             prodDataCell = new PdfPCell(new Phrase(String.valueOf(csProductObj.getPRODUCT_NAME()),fontDetails));
				             prodDataCell.setPaddingLeft(2);
				             prodData.addCell(prodDataCell);
				             // column 3
				             prodDataCell = new PdfPCell();
				             prodDataCell = new PdfPCell(new Phrase(String.valueOf(bookingRegistration.getBOOKING_NUMBER_OF_BAGS()),fontDetails));
				             prodData.addCell(prodDataCell);
				             
				             document.add(prodData); 
				             
				             
			             }
		             }
		             
		             
		            document.close();
		            
		            resourceResponse.setContentType("application/pdf");
		            resourceResponse.addProperty(HttpHeaders.CACHE_CONTROL, "max-age=3600, must-revalidate");
		            resourceResponse.setContentLength(baos.size());
		            
		            OutputStream out = resourceResponse.getPortletOutputStream();
		            baos.writeTo(out);
		            
		            out.flush();
		            out.close();
		        	
			}catch(Exception e){
				// TODO: handle exception
			}
        }
	}
	
	public void doView(RenderRequest renderRequest,RenderResponse renderResponse) throws IOException {
		List<CSRegistration> csRegistrationList = null;
		try {
			Set locationSet= new HashSet();
			List<CSRegistration> csRegistrationsLists = CSRegistrationLocalServiceUtil.getCSRegistrations(0, CSRegistrationLocalServiceUtil.getCSRegistrationsCount());
			for (Iterator iterator = csRegistrationsLists.iterator(); iterator
					.hasNext();) {
				CSRegistration csRegistration = (CSRegistration) iterator
						.next();
				locationSet.add(csRegistration.getLOCATION());
			}
			List locationList= new ArrayList(locationSet);
			renderRequest.setAttribute("csRegistrationsLists",locationList );
			super.doView(renderRequest, renderResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	
	//================================================USING FUNCTIONS END=================================================//
	
	//Search Users by Aadhar Number.
	public void bookingSearchAction(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException, NoSuchCSBookingException {
		
		try {
			long aadhar_card = Long.parseLong(actionRequest.getParameter("aadhar_card"));
			FarmerRegistration farmerRegistration = FarmerRegistrationLocalServiceUtil.findByAADHAR_NUM(aadhar_card);
			if(farmerRegistration != null ){
				actionRequest.setAttribute("user_id", farmerRegistration.getUSER_ID());
				actionResponse.setRenderParameter("jspPage", "/html/cs/offline-booking/offline-booking.jsp");
			}
			
		} catch (NoSuchFarmerRegistrationException e) { 
			actionRequest.setAttribute("message", "Please enter Correct Aadhar Card Number.");
			actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/Message.jsp");
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	//Old (New nextOfflineBooking)
	public void submitOfflineBooking(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException {
			
			String location = actionRequest.getParameter("csLocation");
			String rowIndexes = actionRequest.getParameter("rowIndexes");
			String[] indexOfRows = rowIndexes.split(",");
			
			try {

				//Insert Data in CS_Booking
				long CS_ID = Long.parseLong(actionRequest.getParameter("CSID"));
				long farmerUserid = Long.parseLong(actionRequest.getParameter("farmer_id"));
				String farmerName = actionRequest.getParameter("farmer_name");
				long csBookingId = 0;
				com.hpmc.portal.db.service.model.CSBooking csBooking = null;
				csBookingId = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CSBooking.class.getName());
				csBooking = CSBookingLocalServiceUtil.createCSBooking(csBookingId);
				csBooking.setBOOKED_BY(farmerUserid);
				csBooking.setCS_ID(CS_ID);
				csBooking.setCUSTOMER_NAME(farmerName);
				csBooking.setBOOKING_DATE(new Date());
				CSBookingLocalServiceUtil.addCSBooking(csBooking);
				long lastBookingId = csBooking.getBOOKING_ID();
				
				
				for (int i = 0; i < indexOfRows.length; i++) {
					//System.out.println("Mani ::: For Loop");
					long productId = Long.parseLong(actionRequest.getParameter("productType"+ indexOfRows[i]).trim());
					long number_of_bags = Long.parseLong(actionRequest.getParameter("number_of_bags"+ indexOfRows[i]).trim());
					String cs_chamber_name = actionRequest.getParameter("cs_chamber_desc"+ indexOfRows[i]).trim();
					long floor_rack = Long.parseLong(actionRequest.getParameter("floor_rack"+ indexOfRows[i]).trim());
					
					//Insert Data in CS_CHAMBER
					long cs_chamber_id = 0;
					cs_chamber_id = CounterLocalServiceUtil.increment(CSChamberRegistrationLocalServiceUtil.class.getName());
					CSChamberRegistration chamberRegistration = null;
					chamberRegistration = CSChamberRegistrationLocalServiceUtil.createCSChamberRegistration(cs_chamber_id);
					chamberRegistration.setCS_CHAMBER_DESC(cs_chamber_name);
					chamberRegistration.setFLOOR_RACK(floor_rack);
					chamberRegistration.setCS_ID(CS_ID);
					CSChamberRegistrationLocalServiceUtil.addCSChamberRegistration(chamberRegistration);
					long lastChamberId = chamberRegistration.getCS_CHAMBER_ID();
					
					//Insert Data in CS_PRODUCT_BOOKING_REL
					long productBookingRelId = 0;
					productBookingRelId = CounterLocalServiceUtil.increment(CSProductBookingManagement.class.getName());
					CSProductBookingManagement csProductBookingManagement = null;
					csProductBookingManagement = CSProductBookingManagementLocalServiceUtil.createCSProductBookingManagement(productBookingRelId);
					csProductBookingManagement.setBOOKING_ID(lastBookingId);
					csProductBookingManagement.setPRODUCT_ID(productId);
					csProductBookingManagement.setBOOKING_NUMBER_OF_BAGS((int) number_of_bags);
					csProductBookingManagement.setFROM_DATE(new Date());
					CSProductBookingManagementLocalServiceUtil.addCSProductBookingManagement(csProductBookingManagement);
					long LastProductBookingId = csProductBookingManagement.getPRODUCT_BOOKING_ID();

					//Insert Data in CS_CHAMBER_FLOOR_DETAILS
					
					String lotNumber = LastProductBookingId+"/"+location+"/"+lastChamberId+"/"+floor_rack+"/"+productId+"/"+number_of_bags+"/"+number_of_bags;
					long chamberFloorId = 0;
					chamberFloorId = CounterLocalServiceUtil.increment(CSChamberFloorBookingRegistration.class.getName());
					CSChamberFloorBookingRegistration chamberFloorBookingRegistration = null;
					chamberFloorBookingRegistration = CSChamberFloorBookingRegistrationLocalServiceUtil.createCSChamberFloorBookingRegistration(chamberFloorId);
					chamberFloorBookingRegistration.setPRODUCT_BOOKING_ID(LastProductBookingId);
					chamberFloorBookingRegistration.setCS_CHAMBER_ID(lastChamberId);
					chamberFloorBookingRegistration.setFLOOR_RACK_NO(floor_rack);
					chamberFloorBookingRegistration.setSTORED_NUMBER_OF_BAGS((int)number_of_bags);
					chamberFloorBookingRegistration.setLOT_NUM(lotNumber);
					CSChamberFloorBookingRegistrationLocalServiceUtil.addCSChamberFloorBookingRegistration(chamberFloorBookingRegistration);
					long lastChamberFloorId = chamberFloorBookingRegistration.getCHAMBER_FLOOR_ID();
					
					//Insert Data in CS_PRODUCT_BOOKING_FLOOR_REL
					long PRODUCT_FLOOR_ID = 0;
					PRODUCT_FLOOR_ID = CounterLocalServiceUtil.increment(CSBookedProductFloorManagement.class.getName());
					CSBookedProductFloorManagement bookedProductFloorManagement = null;
					bookedProductFloorManagement = CSBookedProductFloorManagementLocalServiceUtil.createCSBookedProductFloorManagement(PRODUCT_FLOOR_ID);
					bookedProductFloorManagement.setPRODUCT_BOOKING_ID(LastProductBookingId);
					bookedProductFloorManagement.setCHAMBER_FLOOR_ID(lastChamberFloorId);
					CSBookedProductFloorManagementLocalServiceUtil.addCSBookedProductFloorManagement(bookedProductFloorManagement);
					//System.out.println("Mani ::: End For Loop");
				}
				
				actionRequest.setAttribute("csid", CS_ID);
				actionRequest.setAttribute("bookingid", lastBookingId);
				actionRequest.setAttribute("farmerUserid", farmerUserid);
				actionResponse.setRenderParameter("jspPage", "/html/cs/offline-booking/receipt.jsp");
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			
			
		}
	
	//Dummy PDF creating
	public void downloadPDF(ActionRequest actionRequest,ActionResponse actionResponse){
		try {
            OutputStream file = new FileOutputStream(new File("G:/01_Installing-liferay-bundle.pdf"));
  
            Document document = new Document();
            PdfWriter.getInstance(document, file);
            document.open();
            document.add(new Paragraph("Hello Rajeeva Lochana.B.R"));
            document.add(new Paragraph(new Date().toString()));
  
            document.close();
            file.close();
  
        } catch (Exception e) {
  
            e.printStackTrace();
        }
	}
}
