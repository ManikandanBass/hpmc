package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;













import com.hpmc.portal.db.service.NoSuchCSRegistrationException;
import com.hpmc.portal.db.service.model.CSChamberRegistration;
import com.hpmc.portal.db.service.model.CSProductRegistration;
import com.hpmc.portal.db.service.model.HPMCLocationRegistration;
import com.hpmc.portal.db.service.service.CSChamberRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.HPMCLocationRegistrationLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CSRegistration extends MVCPortlet {

	public void csRegistrationStore(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException, SystemException {
		
		String CSName = actionRequest.getParameter("CSName");
		String location = actionRequest.getParameter("location");
		String profitCenter = actionRequest.getParameter("profit_center");
		String CSaddress = actionRequest.getParameter("address");
		long capacity = Long.parseLong(actionRequest.getParameter("cs_capacity"));
		long capacityConvertKG = capacity * 1000;
		String rowIndexes = actionRequest.getParameter("rowIndexes");
		String[] indexOfRows = rowIndexes.split(",");
		try {
			
			long totalChamberCapacity = 0;
			for (int i = 0; i < indexOfRows.length; i++) {
				long ChamberCapacity = Long.parseLong(actionRequest.getParameter("chamber_capacity"+ indexOfRows[i]).trim());
				totalChamberCapacity = totalChamberCapacity+ChamberCapacity;
			}
			
			if(capacity != totalChamberCapacity) {
				actionRequest.setAttribute("messages","Total Capacity must be equal to the sum of chambers capacity.");
				actionResponse.setRenderParameter("jspPage", "/html/cs/registration.jsp");
			}else{
				
				com.hpmc.portal.db.service.model.CSRegistration isCheckNameValidation = CSRegistrationLocalServiceUtil.findByCS_NAME(CSName);
				if(Validator.isNotNull(isCheckNameValidation)){
					actionRequest.setAttribute("messages","Please Enter Unique CS name.");
					actionResponse.setRenderParameter("jspPage", "/html/cs/registration.jsp");
				}
			}
			
			
			
		} catch (NoSuchCSRegistrationException e) {
			
			long counter = 10000000;
			long cs_id = 0;
			com.hpmc.portal.db.service.model.CSRegistration csRegistration = null;
			List<com.hpmc.portal.db.service.model.CSRegistration> csRegistrations = CSRegistrationLocalServiceUtil.getCSRegistrations(0, CounterLocalServiceUtil.getCountersCount());
			for(com.hpmc.portal.db.service.model.CSRegistration register : csRegistrations){
	        	counter = register.getCS_ID();
	        }
	        if(counter <= 1999999999){
	        	cs_id = counter + 1;
	        }
			
			csRegistration = CSRegistrationLocalServiceUtil.createCSRegistration(cs_id);
			csRegistration.setCS_NAME(CSName);
			csRegistration.setCAPACITY(capacityConvertKG);
			csRegistration.setLOCATION(location);
			csRegistration.setSTORAGE_TYPE(HPMCConstant.STORAGE_TYPE_CS);
			csRegistration.setCS_ADDRESS(CSaddress);
			csRegistration.setPROFIT_CENTER(profitCenter);
			CSRegistrationLocalServiceUtil.addCSRegistration(csRegistration);
			
			//Insert Data in hpmc_cs_chamber Table
			long chamber_id = 0;
			CSChamberRegistration csChamberRegistration = null;
			rowIndexes = actionRequest.getParameter("rowIndexes");
			indexOfRows = rowIndexes.split(",");
			for (int i = 0; i < indexOfRows.length; i++) {
				
				String csChamberDesc =actionRequest.getParameter("cs_chamber_desc"+ indexOfRows[i]).trim();
				long floorRack = Long.parseLong(actionRequest.getParameter("floor_rack"+ indexOfRows[i]).trim());
				long ChamberCapacity = Long.parseLong(actionRequest.getParameter("chamber_capacity"+ indexOfRows[i]).trim());
				long chamberCapacityConvertKG = ChamberCapacity * 1000;
				chamber_id = CounterLocalServiceUtil.increment(CSChamberRegistration.class.getName());
				csChamberRegistration = CSChamberRegistrationLocalServiceUtil.createCSChamberRegistration(chamber_id);
				csChamberRegistration.setCS_CHAMBER_DESC(csChamberDesc);
				csChamberRegistration.setCAPACITY(chamberCapacityConvertKG);
				csChamberRegistration.setCS_ID(cs_id);
				csChamberRegistration.setFLOOR_RACK(floorRack);
				CSChamberRegistrationLocalServiceUtil.addCSChamberRegistration(csChamberRegistration);
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	public void productRegistration(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		try {
			
			String coldStorageId = actionRequest.getParameter("coldStorageId");
			String rowIndexes = actionRequest.getParameter("rowIndexes");
			String[] indexOfRows = rowIndexes.split(",");
			
			for (int i = 0; i < indexOfRows.length; i++) {
				String productName = actionRequest.getParameter("productName"+ indexOfRows[i]).trim();
				String storageType = actionRequest.getParameter("storageType"+ indexOfRows[i]).trim();
				String productRent = actionRequest.getParameter("productRent"+ indexOfRows[i]).trim();
				long productId = 0, counter = 0;
				CSProductRegistration productRegistration = null;
				
				List<CSProductRegistration> productList = CSProductRegistrationLocalServiceUtil.getCSProductRegistrations(0,CounterLocalServiceUtil.getCountersCount());
				for(CSProductRegistration productObj : productList){
					counter = productObj.getPRODUCT_ID();
				}
				productId = counter + 1 ;
				productRegistration = CSProductRegistrationLocalServiceUtil.createCSProductRegistration(productId);
				
				productRegistration.setCS_ID(Long.parseLong(coldStorageId));
				productRegistration.setPRODUCT_NAME(productName);
				productRegistration.setSTORAGE_TYPE(storageType);
				productRegistration.setRENT(Float.parseFloat(productRent));
				CSProductRegistrationLocalServiceUtil.addCSProductRegistration(productRegistration);
				
			}
			
			actionRequest.setAttribute("cold_storage_id",coldStorageId);
			actionRequest.setAttribute("status", "success");
			actionRequest.setAttribute("message", "successfully Added.");
			actionResponse.setRenderParameter("jspPage", "/html/cs/ProductManagement/CSProductRentDetail.jsp");
			
			
			/*
			ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
			String pageName="/html/cs/ProductManagement/CSProductRentDetail.jsp";
			String portletName = "result_WAR_sendredirectportlet";
			
			long plid = 0L;
			try {
			 plid = LayoutLocalServiceUtil.getFriendlyURLLayout(themeDisplay.getScopeGroupId(), false, pageName).getPlid();
			} catch (Exception e) {
			e.printStackTrace();
			}
			
			PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest),portletName,plid,    PortletRequest.RENDER_PHASE);
			redirectURL.setParameter("data", "This Value Comes From Welcome Page"); // set required parameter that you need in doView of another Portlet
			actionResponse.sendRedirect(redirectURL.toString());*/ 
			
			
			
			
			
			
			/*ThemeDisplay themeDisplay  = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
			String portletName= themeDisplay.getPortletDisplay().getPortletName();
			 PortletURL portletURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest),portletName,themeDisplay.getLayout().getPlid(),
			 PortletRequest.RENDER_PHASE);
			 portletURL.setParameter("jspPage", "/html/cs/ProductManagement/CSProductRentDetail.jsp");
			 actionRequest.setAttribute(WebKeys.REDIRECT, portletURL.toString());
			 // Here you can redirect to RedirectURL or Portlet URL 
			 try {
			 actionResponse.sendRedirect(portletURL.toString());
			 } catch (IOException e) {

				 e.printStackTrace();
			 }*/
			//PortalUtil.copyRequestParameters(actionRequest, actionResponse);
			
			//System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void updateProductRent(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			long productId = Long.parseLong(actionRequest.getParameter("productId"));
			String productName = actionRequest.getParameter("productName");
			String storageType = actionRequest.getParameter("storageType");
			String productRent = actionRequest.getParameter("productRent");
			
			CSProductRegistration productDetail = CSProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
			productDetail.setPRODUCT_NAME(productName);
			productDetail.setSTORAGE_TYPE(storageType);
			productDetail.setRENT(Float.parseFloat(productRent));
			CSProductRegistrationLocalServiceUtil.updateCSProductRegistration(productDetail);
			
			actionRequest.setAttribute("cold_storage_id", productDetail.getCS_ID());
			actionRequest.setAttribute("status", "success");
			actionRequest.setAttribute("message", "successfully Updated.");
			actionResponse.setRenderParameter("jspPage", "/html/cs/ProductManagement/CSProductRentDetail.jsp");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteProduct(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			long productId = ParamUtil.getLong(actionRequest, "product_id");
			CSProductRegistration productDetail = CSProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
			CSProductRegistrationLocalServiceUtil.deleteCSProductRegistration(productDetail);
			
			actionRequest.setAttribute("cold_storage_id", productDetail.getCS_ID());
			actionRequest.setAttribute("status", "success");
			actionRequest.setAttribute("message", "successfully Deleted.");
			actionResponse.setRenderParameter("jspPage", "/html/cs/ProductManagement/CSProductRentDetail.jsp");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void doView(RenderRequest renderRequest,
			RenderResponse renderResponse) throws IOException, PortletException {
		
		Set<String> locationSets=new HashSet<String>();
		List<HPMCLocationRegistration> cacsLocations=null;
		try {
			cacsLocations = HPMCLocationRegistrationLocalServiceUtil.getHPMCLocationRegistrations(0, HPMCLocationRegistrationLocalServiceUtil.getHPMCLocationRegistrationsCount());
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Iterator iterator = cacsLocations.iterator(); iterator.hasNext();) {
			HPMCLocationRegistration hpmcLocationRegistration = (HPMCLocationRegistration) iterator
					.next();
			locationSets.add(hpmcLocationRegistration.getLOCATION());
		}
		
		List<String> cacsHpmcLocationRegistrationList= new ArrayList<String>(locationSets);
		
		renderRequest.setAttribute("locations", cacsHpmcLocationRegistrationList);
		super.doView(renderRequest, renderResponse);

		
		
	}
	
	
}
