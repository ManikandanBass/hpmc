package com.hpmc.portal.farmer.controller;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.liferay.util.bridges.mvc.MVCPortlet;

public class CAInvoice extends MVCPortlet{

	
	public void getAllCAInvoic(){
		
		
		
	}
	
}
