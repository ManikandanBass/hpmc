package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.hpmc.portal.db.service.NoSuchCABookingException;
import com.hpmc.portal.db.service.model.CABookingAmountManagement;
import com.hpmc.portal.db.service.model.CAProductBookingManagement;
import com.hpmc.portal.db.service.service.CABookingAmountManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CABookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CAProductBookingManagementLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CAProductStorage extends MVCPortlet {

	
	
	public void assignProductStorage(ActionRequest actionRequest,ActionResponse actionResponse) 
			throws IOException{
		try {
			String ca_booking_no = actionRequest.getParameter("ca_booking_no");
			com.hpmc.portal.db.service.model.CABooking caBookings = null;
			
			if(ca_booking_no != ""){
				long caBooking_no = Long.parseLong(ca_booking_no);
				//System.out.println("Booking :: Id=MK"+ca_booking_no);
				caBookings = CABookingLocalServiceUtil.findByBOOKING_ID(caBooking_no);
				
				SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
				String strCurrentDate = DATE_FORMAT.format(new Date());
	            String strStoreDate   = DATE_FORMAT.format(caBookings.getSTORAGE_DATE());
	            Date   currentDate 	  = DATE_FORMAT.parse(strCurrentDate);
	            Date   storeDate 	  = DATE_FORMAT.parse(strStoreDate);
				
				
				if(currentDate.after(storeDate)){
	                throw new ArithmeticException("Your booking id canceled.("+ca_booking_no+")"
	                		+ "Because today date greater than storage date.");
	            }
				
				if(currentDate.before(storeDate)){
	                throw new ArithmeticException("You can't do products storage("+ca_booking_no+")."
	                		+ "Because today date less than storage date.");
	            }
				
				
			}
			actionRequest.setAttribute("bookingId", caBookings.getBOOKING_ID());
			actionRequest.setAttribute("status", "success");
			actionResponse.setRenderParameter("jspPage", "/html/ca/product-storage/assign-product-storage.jsp");
		} catch(ArithmeticException ari){
			actionRequest.setAttribute("bookingId", null);
			actionRequest.setAttribute("status", "fail");
			actionRequest.setAttribute("message", ari.getMessage());
			//actionResponse.setRenderParameter("jspPage", "/html/ca/product-storage/assign-product-storage.jsp");
		}  catch (NoSuchCABookingException e) { 
			actionRequest.setAttribute("status", "fail");
			actionRequest.setAttribute("message", "Please enter Correct Booking Id");
			actionResponse.setRenderParameter("jspPage", "/html/ca/product-storage/search-booking-id.jsp");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void addMoreWeightAction(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		String type = actionRequest.getParameter("type");
		String caBookingId = actionRequest.getParameter("ca_booking_id");
		String caProductBookingId = actionRequest.getParameter("ca_product_booking_id");
		String productRent 		  = actionRequest.getParameter("product_rent");
		String requiredWeight 	  = actionRequest.getParameter("required_weight");
		String bookingInvoiceAmount = actionRequest.getParameter("booking_invoice_amount");
		String advancePaymentAmount = actionRequest.getParameter("advance_payment_amount");
		String paymentMode = actionRequest.getParameter("payment_mode");
		String paymentDetails = actionRequest.getParameter("payment_details");
		String paymentCashDetails = actionRequest.getParameter("paymentCashDetails");
		
		try {
			
			if(type.equalsIgnoreCase("add_more_weight")){
				
				long productBookingId = Long.valueOf(caProductBookingId);
				long bookingId = Long.valueOf(caBookingId);
				
				CAProductBookingManagement addMoreProducts = CAProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBookingId);
				if(addMoreProducts.getBOOKING_ID() == bookingId){
					int additionalWeight = Integer.valueOf(requiredWeight) ;
					int totalWeight = addMoreProducts.getTOTAL_WEIGHT() + additionalWeight;
					addMoreProducts.setADDITIONAL_WEIGHT(additionalWeight);
					addMoreProducts.setTOTAL_WEIGHT(totalWeight);
					CAProductBookingManagementLocalServiceUtil.updateCAProductBookingManagement(addMoreProducts);
				}
				
				CABookingAmountManagement amountManagement = CABookingAmountManagementLocalServiceUtil.findByBOOKING_ID(bookingId).get(0);
				if(amountManagement.getBOOKING_ID() == bookingId){
					float invoiceAmount = Float.valueOf(bookingInvoiceAmount);
					float advanceAmount = Float.valueOf(advancePaymentAmount);
					amountManagement.setADDITIONAL_WEIGHT_CHARGE(invoiceAmount);
					amountManagement.setADDITIONAL_PAYED_AMOUNT(advanceAmount);
					amountManagement.setADDITIONAL_PAYMENT_CASH_DETAIL(paymentCashDetails);
					amountManagement.setADDITIONAL_PAYMENT_CHECK_DRAFT_DETAIL(paymentDetails);
					amountManagement.setADDITIONAL_PAYMENT_MODE(paymentMode);
					CABookingAmountManagementLocalServiceUtil.updateCABookingAmountManagement(amountManagement);
				}
				
				actionRequest.setAttribute("bookingId", bookingId);
				actionRequest.setAttribute("status", "success");
				actionResponse.setRenderParameter("jspPage", "/html/ca/product-storage/assign-product-storage.jsp");
				
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}
	
	
	public void assignProductBoxStorage(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		
		String type = actionRequest.getParameter("type");
		String caBookingId = actionRequest.getParameter("ca_booking_id");
		String caProductBookingId = actionRequest.getParameter("ca_product_booking_id");
		String boxNo = actionRequest.getParameter("box_no");
		try {
			
			if(type.equalsIgnoreCase("assign_box")){
				
				long productBookingId = Long.valueOf(caProductBookingId);
				long bookingId = Long.valueOf(caBookingId);
				
				CAProductBookingManagement addMoreProducts = CAProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBookingId);
				if(addMoreProducts.getBOOKING_ID() == bookingId){
					int boxNumber = Integer.valueOf(boxNo) ;
					addMoreProducts.setBOX_NUM(boxNumber);
					CAProductBookingManagementLocalServiceUtil.updateCAProductBookingManagement(addMoreProducts);
				}
				
				actionRequest.setAttribute("bookingId", bookingId);
				actionRequest.setAttribute("status", "Success");
				actionRequest.setAttribute("message", "Successfully assigned Box No.");
				actionResponse.setRenderParameter("jspPage", "/html/ca/product-storage/assign-product-storage.jsp");
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	
	
	
}
