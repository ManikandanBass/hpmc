package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import com.hpmc.portal.db.service.NoSuchCABookingException;
import com.hpmc.portal.db.service.NoSuchCSBookingException;
import com.hpmc.portal.db.service.NoSuchFarmerRegistrationException;
import com.hpmc.portal.db.service.model.AddressRegistration;
import com.hpmc.portal.db.service.model.CAProductBookingManagement;
import com.hpmc.portal.db.service.model.CAProductRegistration;
import com.hpmc.portal.db.service.model.CSRegistration;
import com.hpmc.portal.db.service.model.CustomerRegistration;
import com.hpmc.portal.db.service.model.FarmerRegistration;
import com.hpmc.portal.db.service.model.UserRegistration;
import com.hpmc.portal.db.service.service.AddressRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CABookingAmountManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CABookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CAProductBookingManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CAProductRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CARegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSBookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CustomerRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.FarmerRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.UserRegistrationLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.model.User;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CAOfflineBooking extends MVCPortlet {

	
	//================================================USING FUNCTIONS STARTS=================================================//
	
		//Offline User Details Stored
		public void customerRegistration(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException {
			try {
				String customerName = actionRequest.getParameter("customerName");
				String fatherHusbandName = actionRequest.getParameter("fatherHusbandName");
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				Date birthdate = (Date) formatter.parse(actionRequest.getParameter("birthdate"));
				String gender = actionRequest.getParameter("gender");
				String houseNo = actionRequest.getParameter("houseNo");
				String area = actionRequest.getParameter("area");
				String landmark = actionRequest.getParameter("landmark");
				String district = actionRequest.getParameter("district");
				String state = actionRequest.getParameter("state");
				int pinCode = Integer.parseInt(actionRequest.getParameter("pinCode"));
				String email = actionRequest.getParameter("email");
				long aadharNo = Long.parseLong(actionRequest.getParameter("aadharNo")) ;
				String panNo = actionRequest.getParameter("panNo");
				String electionCardNo = actionRequest.getParameter("electionNo");
				long mobileNo = Long.parseLong(actionRequest.getParameter("mobileNo"));
					Date creationDate=java.util.Calendar.getInstance().getTime();
					
						
						long customerAddressId = 0;
						AddressRegistration customerAddressRegistration = null;
						customerAddressId = CounterLocalServiceUtil.increment(AddressRegistration.class.getName());
						customerAddressRegistration = AddressRegistrationLocalServiceUtil.createAddressRegistration(customerAddressId);
						
						customerAddressRegistration.setFLAT_HOUSE_DOOR_NUM(houseNo);
						customerAddressRegistration.setVILLAGE_AREA_LOCALITY(area);
						customerAddressRegistration.setROAD_STREET_LANDMARK(landmark);
						customerAddressRegistration.setCITY_DISTRICT(district);
						customerAddressRegistration.setSTATE_UNIONTERITORY(state);
						customerAddressRegistration.setPINCODE(pinCode);
						AddressRegistrationLocalServiceUtil.addAddressRegistration(customerAddressRegistration);
						
						
						long customerUserId = 0;
						customerUserId = CounterLocalServiceUtil.increment(User.class.getName());
						UserRegistration customerUserRegistration = null;
						customerUserRegistration = UserRegistrationLocalServiceUtil.createUserRegistration(customerUserId);
						
						customerUserRegistration.setFULL_NAME(customerName);
						customerUserRegistration.setFATHER_HUSBAND_NAME(fatherHusbandName);
						customerUserRegistration.setDATE_OF_BIRTH(birthdate);
						customerUserRegistration.setGENDER(gender);
						customerUserRegistration.setUSER_NAME(email);
						customerUserRegistration.setUSER_ROLE(HPMCConstant.ROLE_CUSTOMER);
						customerUserRegistration.setCREATION_DATE(creationDate);
						UserRegistrationLocalServiceUtil.addUserRegistration(customerUserRegistration);
						
						CustomerRegistration customerRegistration = null;
						customerRegistration = CustomerRegistrationLocalServiceUtil.createCustomerRegistration(customerUserId);
						customerRegistration.setAADHAR_NUM(aadharNo);
						customerRegistration.setELECTION_CARD_NUM(electionCardNo);
						customerRegistration.setPAN_NUM(panNo);
						customerRegistration.setMOBILE_NUM(mobileNo);
						CustomerRegistrationLocalServiceUtil.addCustomerRegistration(customerRegistration);
						
						actionRequest.setAttribute("customer_user_id", customerUserId);
						
						//----------------CA Location ----------//
						
							Set locationSet= new HashSet();
							List<com.hpmc.portal.db.service.model.CARegistration> caRegistrationsLists = CARegistrationLocalServiceUtil.getCARegistrations(0, CARegistrationLocalServiceUtil.getCARegistrationsCount());
							for (Iterator iterator = caRegistrationsLists
									.iterator(); iterator.hasNext();) {
								com.hpmc.portal.db.service.model.CARegistration caRegistration = (com.hpmc.portal.db.service.model.CARegistration) iterator
										.next();
								locationSet.add(caRegistration.getLOCATION().toUpperCase());
							}
							
							List locationList= new ArrayList(locationSet);
							actionRequest.setAttribute( "caRegistrationsLists" , locationList );
							actionRequest.setAttribute( "user_id" , customerUserId );
						
							actionResponse.setRenderParameter("jspPage", "/html/ca/offline-booking/offline-booking.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	
	
		//================================================USING FUNCTIONS END=================================================//
	
	
	
	
	
	public void bookingSearchAction(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException, NoSuchCABookingException {
		
		try {
			long aadhar_card = Long.parseLong(actionRequest.getParameter("aadhar_card"));
			FarmerRegistration farmerRegistration = FarmerRegistrationLocalServiceUtil.findByAADHAR_NUM(aadhar_card);
			if(farmerRegistration != null ){
				actionRequest.setAttribute("user_id", farmerRegistration.getUSER_ID());
				actionResponse.setRenderParameter("jspPage", "/html/ca/offline-booking/offline-booking.jsp");
			}
			
		} catch (NoSuchFarmerRegistrationException e) { 
			actionRequest.setAttribute("message", "Please enter Correct Aadhar Card Number.");
			actionRequest.setAttribute("redirectPage", "/html/ca/offline-booking/offline.jsp");
			actionResponse.setRenderParameter("jspPage", "/html/ca/offline-booking/Message.jsp");
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	public void assignProductSubmit(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		try {
			
			long productBookingId = 0;
			String rowIndexes = actionRequest.getParameter("rowIndexes");
			String[] indexOfRows = rowIndexes.split(",");
			long caBookingId = Long.parseLong(actionRequest.getParameter("booking_id").trim());
			long ca_chmb_id = Long.parseLong(actionRequest.getParameter("ca_chmb_id").trim());
			long intAdvancePaymentAmount = 0;
			for (int i = 0; i < indexOfRows.length; i++) {
				
				long caProductId 		=	Long.parseLong(actionRequest.getParameter("product_id"+ indexOfRows[i]).trim());
				long caWeight 			=	Long.parseLong(actionRequest.getParameter("required_weight"+ indexOfRows[i]).trim());
				String caLotNumber 		=	actionRequest.getParameter("booking_lot_number"+ indexOfRows[i]).trim();
				long caNumberOfBags 	=	Long.parseLong(actionRequest.getParameter("booking_no_of_bags"+ indexOfRows[i]).trim());
				long rentAmount		 	=	Long.parseLong(actionRequest.getParameter("rent_amount"+ indexOfRows[i]).trim());
				intAdvancePaymentAmount = intAdvancePaymentAmount+rentAmount;
				productBookingId = CounterLocalServiceUtil.increment(CAProductBookingManagement.class.getName());
				CAProductBookingManagement caProductBookingRel = null;
				caProductBookingRel = CAProductBookingManagementLocalServiceUtil.createCAProductBookingManagement(productBookingId);
				caProductBookingRel.setBOOKING_ID(caBookingId);
				caProductBookingRel.setBOOKING_WEIGHT((int) caWeight);
				caProductBookingRel.setBOX_NUM((int) caNumberOfBags);
				caProductBookingRel.setPRODUCT_ID(caProductId);
				caProductBookingRel.setLOT_NUM(caLotNumber);
				caProductBookingRel.setRENT_AMOUNT(rentAmount);
				CAProductBookingManagementLocalServiceUtil.addCAProductBookingManagement(caProductBookingRel);
			}
			
			long intBookingInvoiceAmount = intAdvancePaymentAmount*4;
			//==========================================================================
			long invoiceNumber = 0;
			com.hpmc.portal.db.service.model.CABookingAmountManagement caBookingAmount = null;
			invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABookingAmountManagement.class.getName());
			caBookingAmount = CABookingAmountManagementLocalServiceUtil.createCABookingAmountManagement(invoiceNumber);
			caBookingAmount.setBOOKING_ID(caBookingId);
			caBookingAmount.setBOOKING_AMOUNT((int) intBookingInvoiceAmount);
			caBookingAmount.setADVANCE_PAYMENT_AMOUNT((int) intAdvancePaymentAmount);
			CABookingAmountManagementLocalServiceUtil.addCABookingAmountManagement(caBookingAmount);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void serveResource(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) throws IOException,
			PortletException {
		
		String cmd = ParamUtil.getString(resourceRequest, "cmd");
		if(cmd.length() > 0){
			ArrayList<String> arrayList = new ArrayList<String>();
			JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
			try {
				
				String CAName ="", CAId ="";
				if(cmd.equalsIgnoreCase("ajaxCall")){
					String CALocationName = ParamUtil.getString(resourceRequest, "caLocation");
					java.util.List<com.hpmc.portal.db.service.model.CARegistration> CAlist	= CARegistrationLocalServiceUtil.findByLOCATION(CALocationName);
					for(com.hpmc.portal.db.service.model.CARegistration caRegistration : CAlist){
						
						JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
						jsonObject.put("CAId",caRegistration.getCA_ID());
						jsonObject.put("CAName",caRegistration.getCA_NAME());
						jsonArray.put(jsonObject);
						
					}
					
					Iterator<String> iterator = arrayList.iterator();
					while (iterator.hasNext()) {
						String name = (String) iterator.next();
					}
				}
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			PrintWriter writer = resourceResponse.getWriter();
	        writer.write(jsonArray.toString());
	        writer.flush();
		}
		
		
		// TODO Auto-generated method stub
		//super.serveResource(resourceRequest, resourceResponse);
	}
	
	
	
	public void findChamberDetails(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		String farmer_id = actionRequest.getParameter("farmer_id");
		String farmer_name = actionRequest.getParameter("farmer_name");
		String caLocation = actionRequest.getParameter("caLocation");
		String ca_id = actionRequest.getParameter("CAID");
		
		actionRequest.setAttribute("farmer_id", farmer_id);
		actionRequest.setAttribute("farmer_name", farmer_name);
		actionRequest.setAttribute("caLocation", caLocation);
		actionRequest.setAttribute("ca_id", ca_id);
		actionResponse.setRenderParameter("jspPage", "/html/ca/offline-booking/chamber-view-details.jsp");
	}
	
	
	public void chamberBooking(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException{
		try {
			
			
			
			
			String bookBy = actionRequest.getParameter("user_id");
			String ca_chmb_id = actionRequest.getParameter("ca_chamber_id");
			String paymentMode = "Online";
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date storeDate = (Date) formatter.parse(actionRequest.getParameter("fromDate").trim());
			
			String inputBookingInvoiceAmount = actionRequest.getParameter("booking_invoice_amount");
			String inputAdvancePaymentAmount = actionRequest.getParameter("advance_payment_amount");
			//System.out.println("bookingInvoiceAmount::"+bookingInvoiceAmount);
			//System.out.println("advancePaymentAmount::"+advancePaymentAmount);
			
			long intChmbId = Long.parseLong(ca_chmb_id);
			long intFrmUser = Long.parseLong(bookBy);

			// =========================================================================
			//Insert Data in CA_BOOKING
			long booking_id = 0;
			com.hpmc.portal.db.service.model.CABooking caBooking = null;
			booking_id = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABooking.class.getName());
			caBooking = CABookingLocalServiceUtil.createCABooking(booking_id);
			caBooking.setBOOKED_BY(intFrmUser);
			caBooking.setCA_CHAMBER_ID(intChmbId);
			caBooking.setBOOKING_DATE(new Date());
			caBooking.setSTORAGE_DATE(storeDate);
			CABookingLocalServiceUtil.addCABooking(caBooking);
			
			// ==========================================================================
			//Insert Data in CA_PRODUCT_BOOKING_REL
			String rowIndexes = actionRequest.getParameter("rowIndexes");
			int[] indexOfRows = StringUtil.split(rowIndexes, 0);
			for (int indexOfRow : indexOfRows){
	        	
				long productId = Long.parseLong(ParamUtil.getString(actionRequest, "product_id"+indexOfRow).trim());
				long productWeight= Long.parseLong(ParamUtil.getString(actionRequest, "required_weight"+indexOfRow).trim());
				CAProductRegistration caProductRegistration=CAProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
				
				CAProductBookingManagement caProductbookingManagement = null;
				long productBookingId = 0;
				productBookingId = CounterLocalServiceUtil.increment(CAProductBookingManagement.class.getName());
				caProductbookingManagement = CAProductBookingManagementLocalServiceUtil.createCAProductBookingManagement(productBookingId);
				caProductbookingManagement.setBOOKING_ID(caBooking.getBOOKING_ID());
				caProductbookingManagement.setPRODUCT_ID(productId);
				caProductbookingManagement.setBOOKING_WEIGHT((int)productWeight);
				caProductbookingManagement.setTOTAL_WEIGHT((int)productWeight);
				caProductbookingManagement.setRENT_AMOUNT(caProductRegistration.getRENT());
				CAProductBookingManagementLocalServiceUtil.addCAProductBookingManagement(caProductbookingManagement);
	        	
			}
	        float bookingInvoiceAmount = Float.parseFloat(inputBookingInvoiceAmount);
	        float advancePaymentAmount = Float.parseFloat(inputAdvancePaymentAmount);
			// ==========================================================================
			long invoiceNumber = 0;
			com.hpmc.portal.db.service.model.CABookingAmountManagement caBookingAmount = null;
			invoiceNumber = CounterLocalServiceUtil
					.increment(com.hpmc.portal.db.service.model.CABookingAmountManagement.class
							.getName());
			caBookingAmount = CABookingAmountManagementLocalServiceUtil.createCABookingAmountManagement(invoiceNumber);
			caBookingAmount.setBOOKING_ID(caBooking.getBOOKING_ID());
			caBookingAmount.setADVANCE_PAYMENT_AMOUNT(advancePaymentAmount);
			caBookingAmount.setBOOKING_AMOUNT(bookingInvoiceAmount);
			caBookingAmount.setADVANCE_PAYMENT_MODE(paymentMode);
			CABookingAmountManagementLocalServiceUtil.addCABookingAmountManagement(caBookingAmount);
			
			actionRequest.setAttribute("booking_id", caBooking.getBOOKING_ID());
			actionResponse.setRenderParameter("jspPage","/html/ca/after-booking.jsp");
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			/*String bookBy = actionRequest.getParameter("farmer_id");
			String userName = actionRequest.getParameter("full_name");
			String ca_chmb_id = actionRequest.getParameter("ca_chamber_id");
			String productType = actionRequest.getParameter("product_id");
			String paymentMode = actionRequest.getParameter("payment_mode");
			//System.out.println(paymentMode);
			String bookingInvoiceAmount = actionRequest.getParameter("booking_invoice_amount");
			String advancePaymentAmount = actionRequest.getParameter("advance_payment_amount");
			
			String requiredWeight = actionRequest.getParameter("required_weight");
			//System.out.println(1);
			long intproductType = Long.parseLong(productType);
			long intChmbId = Long.parseLong(ca_chmb_id);
			long intRequiredWeight = Long.parseLong(requiredWeight);
			long intFrmUser = Long.parseLong(bookBy);
			long booking_id = 0;
			//System.out.println(2);
			com.hpmc.portal.db.service.model.CABooking caBooking = null;
			booking_id = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABooking.class.getName());
			caBooking = CABookingLocalServiceUtil.createCABooking(booking_id);
			caBooking.setBOOKED_BY(intFrmUser);
			caBooking.setCA_CHAMBER_ID(intChmbId);
			caBooking.setCUSTOMER_NAME(userName);
			caBooking.setBOOKING_DATE(new Date());
			CABookingLocalServiceUtil.addCABooking(caBooking);
			//System.out.println(3);
			//==========================================================================
			
			long productBookingId = 0;
			CAProductBookingManagement caProductbookingManagement = null;
			productBookingId = CounterLocalServiceUtil.increment(CAProductBookingManagement.class.getName());
			//System.out.println(intproductType);
			caProductbookingManagement = CAProductBookingManagementLocalServiceUtil.createCAProductBookingManagement(productBookingId);
			caProductbookingManagement.setBOOKING_ID(caBooking.getBOOKING_ID());
			caProductbookingManagement.setPRODUCT_ID(intproductType);
			caProductbookingManagement.setBOOKING_WEIGHT((int) intRequiredWeight);
			CAProductBookingManagementLocalServiceUtil.addCAProductBookingManagement(caProductbookingManagement);
			//System.out.println(4);
			long intBookingInvoiceAmount = Long.parseLong(bookingInvoiceAmount);
			long intAdvancePaymentAmount = Long.parseLong(advancePaymentAmount);
			//==========================================================================
			long invoiceNumber = 0;
			com.hpmc.portal.db.service.model.CABookingAmountManagement caBookingAmount = null;
			invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABookingAmountManagement.class.getName());
			caBookingAmount = CABookingAmountManagementLocalServiceUtil.createCABookingAmountManagement(invoiceNumber);
			caBookingAmount.setBOOKING_ID(caBooking.getBOOKING_ID());
			caBookingAmount.setBOOKING_AMOUNT((int) intBookingInvoiceAmount);
			caBookingAmount.setADVANCE_PAYMENT_AMOUNT((int) intAdvancePaymentAmount);
			CABookingAmountManagementLocalServiceUtil.addCABookingAmountManagement(caBookingAmount);*/
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void bookingAssignProductSubmit(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		try {
			
			String farmer_id = actionRequest.getParameter("farmer_id");
			String userName = actionRequest.getParameter("full_name");
			String ca_chmb_id = actionRequest.getParameter("ca_chamber_id");
			long intChmbId = Long.parseLong(ca_chmb_id);
			long intFrmUser = Long.parseLong(farmer_id);
			
			long booking_id = 0;
			//System.out.println(2);
			com.hpmc.portal.db.service.model.CABooking caBooking = null;
			booking_id = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABooking.class.getName());
			caBooking = CABookingLocalServiceUtil.createCABooking(booking_id);
			caBooking.setBOOKED_BY(intFrmUser);
			caBooking.setCA_CHAMBER_ID(intChmbId);
			caBooking.setCUSTOMER_NAME(userName);
			caBooking.setBOOKING_DATE(new Date());
			CABookingLocalServiceUtil.addCABooking(caBooking);
			
			long productBookingId = 0;
			String rowIndexes = actionRequest.getParameter("rowIndexes");
			String[] indexOfRows = rowIndexes.split(",");
			long caBookingId = caBooking.getBOOKING_ID();
			long intAdvancePaymentAmount = 0;
			for (int i = 0; i < indexOfRows.length; i++) {
				
				long caProductId 		=	Long.parseLong(actionRequest.getParameter("product_id"+ indexOfRows[i]).trim());
				long caWeight 			=	Long.parseLong(actionRequest.getParameter("required_weight"+ indexOfRows[i]).trim());
				String caLotNumber 		=	caBookingId+"/"+intChmbId+"/"+userName;
				long caNumberOfBags 	=	Long.parseLong(actionRequest.getParameter("booking_no_of_bags"+ indexOfRows[i]).trim());
				long rentAmount		 	=	Long.parseLong(actionRequest.getParameter("rent_amount"+ indexOfRows[i]).trim());
				intAdvancePaymentAmount = intAdvancePaymentAmount+rentAmount;
				productBookingId = CounterLocalServiceUtil.increment(CAProductBookingManagement.class.getName());
				CAProductBookingManagement caProductBookingRel = null;
				caProductBookingRel = CAProductBookingManagementLocalServiceUtil.createCAProductBookingManagement(productBookingId);
				caProductBookingRel.setBOOKING_ID(caBookingId);
				caProductBookingRel.setBOOKING_WEIGHT((int) caWeight);
				caProductBookingRel.setBOX_NUM((int) caNumberOfBags);
				caProductBookingRel.setPRODUCT_ID(caProductId);
				caProductBookingRel.setLOT_NUM(caLotNumber);
				caProductBookingRel.setRENT_AMOUNT(rentAmount);
				CAProductBookingManagementLocalServiceUtil.addCAProductBookingManagement(caProductBookingRel);
			}
			
			long intBookingInvoiceAmount = intAdvancePaymentAmount*4;
			//==========================================================================
			long invoiceNumber = 0;
			com.hpmc.portal.db.service.model.CABookingAmountManagement caBookingAmount = null;
			invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABookingAmountManagement.class.getName());
			caBookingAmount = CABookingAmountManagementLocalServiceUtil.createCABookingAmountManagement(invoiceNumber);
			caBookingAmount.setBOOKING_ID(caBooking.getBOOKING_ID());
			caBookingAmount.setBOOKING_AMOUNT((int) intBookingInvoiceAmount);
			caBookingAmount.setADVANCE_PAYMENT_AMOUNT((int) intAdvancePaymentAmount);
			CABookingAmountManagementLocalServiceUtil.addCABookingAmountManagement(caBookingAmount);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
