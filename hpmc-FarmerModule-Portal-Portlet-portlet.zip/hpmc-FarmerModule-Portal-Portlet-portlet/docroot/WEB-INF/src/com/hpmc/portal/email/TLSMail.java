package com.hpmc.portal.email;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

public class TLSMail {

		public static void main(String[] args) {
			
		    final String fromEmail = "manikandancovai0@gmail.com"; //requires valid gmail id
			final String password = "9952439585"; // correct password for gmail id
			final String toEmail = "manikandancovai0@gmail.com"; // can be any email id 
			
	    	  
			final  String subject = "Invoice Report From HPMC";  
			final String body = "<h1>Farmer Booking Invioce</h1>"
					+ "<table>"
					+ "<tr><td>Name			:</td><td>Manikandan</td></tr>"
					+ "<tr><td>Email			:</td><td>manikandan@prakat.com</td></tr>"
					+ "<tr><td>Phone Number	:</td><td>9952143089</td></tr>"
					+ "<tr><td>Aadhar Number	:</td><td>ADLIOEW92323</td></tr>"
					+ "<tr><td>Booking ID 	:</td><td> 1001</td></tr>"
					+ "<tr><td>Booking Date 	: </td><td>10-10-2017</td></tr>"
					+ "<tr><td>Booking Weight :</td><td> 40</td></tr>"
					+ "<tr><td>Due Amount 	: </td><td>500</td></tr>"
					+ "<tr><td>Due Last Date	: </td><td>20-10-2017</td></tr>"
					+ "</table>";
			
			System.out.println("TLSEmail Start");
			
			Properties props = new Properties();
			props.put("mail.smtp.host", "smtp.gmail.com"); //SMTP Host
			props.put("mail.smtp.port", "587"); //TLS Port
			props.put("mail.smtp.auth", "true"); //enable authentication
			props.put("mail.smtp.starttls.enable", "true"); //enable STARTTLS
			
	        //create Authenticator object to pass in Session.getInstance argument
			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			    protected PasswordAuthentication getPasswordAuthentication() {
			        return new PasswordAuthentication(fromEmail, password);
			    }
			});
			//Session session = Session.getInstance(props, auth);
			JavaMailSend.sendEmail(session, toEmail, subject, body);
			System.out.println("Mail Send Successfully");

		}

}
