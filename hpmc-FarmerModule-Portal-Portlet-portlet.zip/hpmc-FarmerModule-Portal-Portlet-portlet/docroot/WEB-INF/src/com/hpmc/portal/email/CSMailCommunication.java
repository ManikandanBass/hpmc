package com.hpmc.portal.email;

import java.text.SimpleDateFormat;

import com.hpmc.portal.db.service.NoSuchCSBookingException;
import com.hpmc.portal.db.service.NoSuchUserRegistrationException;
import com.hpmc.portal.db.service.model.CSBooking;
import com.hpmc.portal.db.service.model.CSProductBookingManagement;
import com.hpmc.portal.db.service.model.UserRegistration;
import com.hpmc.portal.db.service.service.CSBookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductBookingManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.UserRegistrationLocalServiceUtil;


public class CSMailCommunication extends HPMCMailSend {
	
	
	public static void bookingConfirmation(long Booking_id){
		
		if(Booking_id != 0){
			
			try {
				
				CSBooking booking = CSBookingLocalServiceUtil.findByBOOKING_ID(Booking_id);
				CSProductBookingManagement productBookingManagement = CSProductBookingManagementLocalServiceUtil.findByBOOKING_ID(Booking_id).get(0);
				SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");
				String storeDate = DATE_FORMAT.format(productBookingManagement.getFROM_DATE());
				
				UserRegistration userDetails = UserRegistrationLocalServiceUtil.findByUSER_ID(booking.getBOOKED_BY());
				//CustomerRegistration customerDetails = CustomerRegistrationLocalServiceUtil.findByUSER_ID(booking.getBOOKED_BY());
				
				String userName = userDetails.getFULL_NAME();
				String emailAddress = userDetails.getUSER_NAME();
				
				String mailSubject = "Booking Confirmation Mail.";
				String mailBody = "Hi "+userName+", Your Booking order has been confirmed, booking order id is "+
				String.valueOf(Booking_id)+".\n\n Please Submit Products on "+storeDate+".\n\n\nThank You For Visiting HPMC.";
				feedbackMailSend(mailSubject, mailBody, emailAddress);
				System.out.println("Mail Has been Sent. Uname:"+userName+",Eadd:"+emailAddress);
				
				
			} catch(NoSuchUserRegistrationException nsu){
				nsu.printStackTrace();
			} catch(NoSuchCSBookingException nsb){
				nsb.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			System.out.println("bookingConfirmation...");
			//feedbackMailSend(mailSubject, mailBody, sendMailTo);
			
		}
	}
	
	
	public static void productsStorageConfirmation(long Booking_id){
		
			if(Booking_id != 0){
			
				try {
					
					CSBooking booking = CSBookingLocalServiceUtil.findByBOOKING_ID(Booking_id);
					
					UserRegistration userDetails = UserRegistrationLocalServiceUtil.findByUSER_ID(booking.getBOOKED_BY());
					//CustomerRegistration customerDetails = CustomerRegistrationLocalServiceUtil.findByUSER_ID(booking.getBOOKED_BY());
					
					String userName = userDetails.getFULL_NAME();
					String emailAddress = userDetails.getUSER_NAME();
					
					String mailSubject = "Products Stored Confirmation Mail.";
					String mailBody = "Hi "+userName+", Your booking products are has been stored, booking order id is "+
					String.valueOf(Booking_id)+". \n\n\nThank You For Visiting HPMC.";
					feedbackMailSend(mailSubject, mailBody, emailAddress);
					System.out.println("Mail Has been Sent. Uname:"+userName+",Eadd:"+emailAddress);
					
					
				} catch(NoSuchUserRegistrationException nsu){
					nsu.printStackTrace();
				} catch(NoSuchCSBookingException nsb){
					nsb.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}		
			}
		
		System.out.println("productsStorageConfirmation...");
	}
	
	
	public static void productsWithdrawnConfirmation(long Booking_id){
		
		if(Booking_id != 0){
		
			try {
				
				CSBooking booking = CSBookingLocalServiceUtil.findByBOOKING_ID(Booking_id);
				
				UserRegistration userDetails = UserRegistrationLocalServiceUtil.findByUSER_ID(booking.getBOOKED_BY());
				//CustomerRegistration customerDetails = CustomerRegistrationLocalServiceUtil.findByUSER_ID(booking.getBOOKED_BY());
				
				String userName = userDetails.getFULL_NAME();
				String emailAddress = userDetails.getUSER_NAME();
				
				String mailSubject = "Products Withdrawn Confirmation Mail.";
				String mailBody = "Hi "+userName+", Your booking products are successfully withdrawn, booking order id is "+
				String.valueOf(Booking_id)+". \n\n\nThank You For Visiting HPMC.";
				feedbackMailSend(mailSubject, mailBody, emailAddress);
				System.out.println("Mail Has been Sent. Uname:"+userName+",Eadd:"+emailAddress);
				
				
			} catch(NoSuchUserRegistrationException nsu){
				nsu.printStackTrace();
			} catch(NoSuchCSBookingException nsb){
				nsb.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}
	
		//System.out.println("productsWithdrawnConfirmation...");
	}
	
	
	public static void cancelBookingConfirmation(long Booking_id){
		
		if(Booking_id != 0){
			
			try {
				
				CSBooking booking = CSBookingLocalServiceUtil.findByBOOKING_ID(Booking_id);
				
				UserRegistration userDetails = UserRegistrationLocalServiceUtil.findByUSER_ID(booking.getBOOKED_BY());
				//CustomerRegistration customerDetails = CustomerRegistrationLocalServiceUtil.findByUSER_ID(booking.getBOOKED_BY());
				
				String userName = userDetails.getFULL_NAME();
				String emailAddress = userDetails.getUSER_NAME();
				
				String mailSubject = "Cancel Booking Confirmation Mail.";
				String mailBody = "Hi "+userName+", Your booking order canceled, booking order id is "+
				String.valueOf(Booking_id)+". \n\n\nThank You For Visiting HPMC.";
				feedbackMailSend(mailSubject, mailBody, emailAddress);
				//System.out.println("Mail Has been Sent. Uname:"+userName+",Eadd:"+emailAddress);
				
				
			} catch(NoSuchUserRegistrationException nsu){
				nsu.printStackTrace();
			} catch(NoSuchCSBookingException nsb){
				nsb.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}
	
		//System.out.println("cancelBookingConfirmation...");
	}
	
	
}
