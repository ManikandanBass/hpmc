package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.hpmc.portal.db.service.NoSuchCSBookingException;
import com.hpmc.portal.db.service.NoSuchCSProductBookingManagementException;
import com.hpmc.portal.db.service.model.CSBookedProductFloorManagement;
import com.hpmc.portal.db.service.model.CSChamberFloorBookingRegistration;
import com.hpmc.portal.db.service.model.CSProductBookingManagement;
import com.hpmc.portal.db.service.service.CSBookedProductFloorManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSBookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSChamberFloorBookingRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductBookingManagementLocalServiceUtil;
import com.hpmc.portal.email.CSMailCommunication;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CSAssignProductStorage extends MVCPortlet {

	public void bookingIdSearch(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
	
		try {
			String cs_booking_no = actionRequest.getParameter("cs_booking_no");
			com.hpmc.portal.db.service.model.CSBooking csBookings = null;
			if(cs_booking_no != ""){
				long csBooking_no = Long.parseLong(cs_booking_no);
				//System.out.println("Booking :: Id="+csBooking_no);
				csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(csBooking_no);
				CSProductBookingManagement productBookingManagement = CSProductBookingManagementLocalServiceUtil.findByBOOKING_ID(csBooking_no).get(0);
				
				SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
				String strCurrentDate = DATE_FORMAT.format(new Date());
	            String strStoreDate   = DATE_FORMAT.format(productBookingManagement.getFROM_DATE());
	            Date   currentDate 	  = DATE_FORMAT.parse(strCurrentDate);
	            Date   storeDate 	  = DATE_FORMAT.parse(strStoreDate);
	            
				
				if(csBookings.getBOOKING_STATUS() == true){
					throw new ArithmeticException("Already Canceled this booking id("+csBooking_no+").");
				}
				
				if(currentDate.after(storeDate)){
	                throw new ArithmeticException("Your booking id canceled.("+csBooking_no+")"
	                		+ "Because today date greater than storage date.");
	            }
				
				if(currentDate.before(storeDate)){
	                throw new ArithmeticException("You can't do products storage."
	                		+ "Because today date less than storage date.");
	            }
				
			}
				
			actionRequest.setAttribute("csBookingObj", csBookings.getBOOKING_ID());
			actionRequest.setAttribute("status", "success");
			actionRequest.setAttribute("bookingId", csBookings.getBOOKING_ID());
			actionRequest.setAttribute("bookedBy", csBookings.getBOOKED_BY());
			
		} catch(ArithmeticException ari){
			actionRequest.setAttribute("status", "fail");
			actionRequest.setAttribute("messages", ari.getMessage());
			actionResponse.setRenderParameter("jspPage", "/html/cs/product-storage/assign-product-storage.jsp");
		} catch (NoSuchCSBookingException e) { 
			actionRequest.setAttribute("status", "fail");
			actionRequest.setAttribute("messages", "Please enter Correct Booking Id");
			actionResponse.setRenderParameter("jspPage", "/html/cs/product-storage/assign-product-storage.jsp");
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void assignProductSubmit(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		long csbooking_id =	Long.parseLong(actionRequest.getParameter("booking_id").trim());
		long csProductbookingId =	Long.parseLong(actionRequest.getParameter("product_booking_id").trim());
		long csChamberId 		=	Long.parseLong(actionRequest.getParameter("chamber_id").trim());
		long csFloorRackNo 		=	Long.parseLong(actionRequest.getParameter("floor_rack").trim());
		String csLotNumber 		=	actionRequest.getParameter("lot_number").trim();
		long csNumberOfBags 	=	Long.parseLong(actionRequest.getParameter("no_of_bags_to_store").trim());
		try {
			com.hpmc.portal.db.service.model.CSBooking csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(csbooking_id);
			
			if (csBookings.getBOOKING_STATUS() == false) {
				long chamberFloorId = 0;
				CSChamberFloorBookingRegistration floorBookingRegistration = null;
				chamberFloorId = CounterLocalServiceUtil
						.increment(CSChamberFloorBookingRegistration.class
								.getName());
				floorBookingRegistration = CSChamberFloorBookingRegistrationLocalServiceUtil
						.createCSChamberFloorBookingRegistration(chamberFloorId);
				floorBookingRegistration.setCS_CHAMBER_ID(csChamberId);
				floorBookingRegistration.setFLOOR_RACK_NO(csFloorRackNo);
				floorBookingRegistration.setLOT_NUM(csLotNumber);
				floorBookingRegistration
						.setSTORED_NUMBER_OF_BAGS((int) csNumberOfBags);
				floorBookingRegistration
						.setPRODUCT_BOOKING_ID(csProductbookingId);
				CSChamberFloorBookingRegistrationLocalServiceUtil
						.addCSChamberFloorBookingRegistration(floorBookingRegistration);
				long productBookingFloorRel = 0;
				CSBookedProductFloorManagement productFloorManagement = null;
				productBookingFloorRel = CounterLocalServiceUtil
						.increment(CSBookedProductFloorManagement.class
								.getName());
				productFloorManagement = CSBookedProductFloorManagementLocalServiceUtil
						.createCSBookedProductFloorManagement(productBookingFloorRel);
				productFloorManagement
						.setPRODUCT_BOOKING_ID(csProductbookingId);
				productFloorManagement
						.setCHAMBER_FLOOR_ID(floorBookingRegistration
								.getCHAMBER_FLOOR_ID());
				CSBookedProductFloorManagementLocalServiceUtil
						.addCSBookedProductFloorManagement(productFloorManagement);
				
				this.isItCompleteStorage(csbooking_id);
				
				actionRequest.setAttribute("csBookingObj",
						csBookings.getBOOKING_ID());
				actionRequest.setAttribute("bookingId",
						csBookings.getBOOKING_ID());
				actionRequest.setAttribute("bookedBy",
						csBookings.getBOOKED_BY());
				actionRequest.setAttribute("status", "success");
				actionRequest.setAttribute("messages",
						"Products successfully stored");
				
			}else{
				actionRequest.setAttribute("status", "fail");
				actionRequest.setAttribute("messages", "Already Canceled this booking id("+csbooking_id+").");
			}
			
			actionResponse.setRenderParameter("jspPage",
					"/html/cs/product-storage/assign-product-storage.jsp");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
	

	public void changeProductBookingBagsCount(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
			long booking_id = Long.parseLong(actionRequest.getParameter("booking_id"));
			long product_booking_id = Long.parseLong(actionRequest.getParameter("product_booking_id"));
			long storageTotalNoBags = Long.parseLong(actionRequest.getParameter("storage_total_no_bags"));
			
			try {
				
				long totalBookedNoBags= 0;
				List<CSChamberFloorBookingRegistration> chamberFloorBookingRegistrations = CSChamberFloorBookingRegistrationLocalServiceUtil.findByPRODUCT_BOOKING_ID(product_booking_id);
				for(CSChamberFloorBookingRegistration chmFloorBookingReg: chamberFloorBookingRegistrations ){
					totalBookedNoBags = totalBookedNoBags + chmFloorBookingReg.getSTORED_NUMBER_OF_BAGS();
				}
				
				com.hpmc.portal.db.service.model.CSBooking csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(booking_id);
				if(totalBookedNoBags < storageTotalNoBags){
					CSProductBookingManagement productBookingManagement = CSProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(product_booking_id);
					productBookingManagement.setTOTAL_NUMBER_OF_BAGS((int) storageTotalNoBags);
					CSProductBookingManagementLocalServiceUtil.updateCSProductBookingManagement(productBookingManagement);
				}else{
					actionRequest.setAttribute("messages", "Please Must Enter Change Storage No Bags Count greater than Booked No of Bags. ");
				}
				
				actionRequest.setAttribute("status", "success");
				actionRequest.setAttribute("messages","successfully Changed Bags Count.");
				actionRequest.setAttribute("bookingId", csBookings.getBOOKING_ID());
				actionRequest.setAttribute("bookedBy", csBookings.getBOOKED_BY());
				actionResponse.setRenderParameter("jspPage", "/html/cs/product-storage/assign-product-storage.jsp");
				
				
			} catch (NoSuchCSProductBookingManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SystemException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchCSBookingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	public static void isItCompleteStorage(long booking_id){
		
		
		try {
			
			List<CSProductBookingManagement> productBooking = CSProductBookingManagementLocalServiceUtil.findByBOOKING_ID(booking_id);
			long totalProductsCount = 0;
			long totalChamberFloorCount = 0;
			for (CSProductBookingManagement csProductBookingManagement : productBooking) {
				
				if(csProductBookingManagement.getTOTAL_NUMBER_OF_BAGS() != 0){
					totalProductsCount = csProductBookingManagement.getTOTAL_NUMBER_OF_BAGS();
				}else{
					totalProductsCount = csProductBookingManagement.getBOOKING_NUMBER_OF_BAGS();
				}
				
				List<CSChamberFloorBookingRegistration> chamberFloorBooking = CSChamberFloorBookingRegistrationLocalServiceUtil.
						findByPRODUCT_BOOKING_ID(csProductBookingManagement.getPRODUCT_BOOKING_ID());
				for (CSChamberFloorBookingRegistration csChamberFloorBookingRegistration : chamberFloorBooking) {
					if(csChamberFloorBookingRegistration.getWITHDRAW_NUMBER_OF_BAGS() != 0){
						totalChamberFloorCount = csChamberFloorBookingRegistration.getWITHDRAW_NUMBER_OF_BAGS();
					}else{
						totalChamberFloorCount = csChamberFloorBookingRegistration.getSTORED_NUMBER_OF_BAGS();
					}
				}
				
				
			}
			
			if(totalProductsCount == totalChamberFloorCount){
				CSMailCommunication.productsStorageConfirmation(booking_id);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
