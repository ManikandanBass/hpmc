package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hpmc.portal.db.service.model.CAChamberRegistration;
import com.hpmc.portal.db.service.model.CAProductBookingManagement;
import com.hpmc.portal.db.service.model.CAProductRegistration;
import com.hpmc.portal.db.service.model.CARegistration;
import com.hpmc.portal.db.service.model.UserRegistration;
import com.hpmc.portal.db.service.service.CABookingAmountManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CABookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CAChamberRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CAProductBookingManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CAProductRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CARegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.UserRegistrationLocalService;
import com.hpmc.portal.db.service.service.UserRegistrationLocalServiceUtil;
import com.hpmc.portal.email.HPMCMailSend;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.servlet.PortletServlet;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.User;
import com.liferay.portal.service.RoleServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CABooking extends MVCPortlet {

	public void searchCAByLocation(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException {

		try {
			String ca_location = actionRequest.getParameter("ca_location");

			actionResponse.setRenderParameter("ca_location", ca_location);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void doView(RenderRequest renderRequest,
			RenderResponse renderResponse) throws IOException {

		
		HttpServletRequest request = (HttpServletRequest) renderRequest.getAttribute(PortletServlet.PORTLET_SERVLET_REQUEST);
		List<CARegistration> caRegistrationsList = null;
		try {
		List<CARegistration> caRegistrations = null;
			String locationName = ParamUtil.get(renderRequest, "ca_location","");

			if (locationName != "") {
				caRegistrations = CARegistrationLocalServiceUtil
						.findByLOCATION(locationName);
				Set<CARegistration> caRegistrationsSet= new HashSet<CARegistration>(
						caRegistrations);
				caRegistrationsList= new ArrayList<CARegistration>(caRegistrationsSet);

			}
			
			
			Set locationSet= new HashSet();
			List<CARegistration> caRegistrationsLists = CARegistrationLocalServiceUtil.getCARegistrations(0, CARegistrationLocalServiceUtil.getCARegistrationsCount());
			for (Iterator iterator = caRegistrationsLists.iterator(); iterator
					.hasNext();) {
				CARegistration caRegistration = (CARegistration) iterator
						.next();
				locationSet.add(caRegistration.getLOCATION());
			}
			List locationList= new ArrayList(locationSet);
			for (Iterator iterator = locationList.iterator(); iterator
					.hasNext();) {
				Object string = iterator.next();
			}
			
			renderRequest.setAttribute("caRegistrationsLists",locationList );
			renderRequest.setAttribute("caList", caRegistrationsList);
			renderRequest.setAttribute("inputLocation", locationName);
			super.doView(renderRequest, renderResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void chamberBooking(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException {
		try {
			String bookBy = actionRequest.getParameter("user_id");
			String ca_chmb_id = actionRequest.getParameter("ca_chamber_id");
			String paymentMode = "Online";
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date storeDate = (Date) formatter.parse(actionRequest.getParameter("fromDate").trim());
			
			String inputBookingInvoiceAmount = actionRequest.getParameter("booking_invoice_amount");
			String inputAdvancePaymentAmount = actionRequest.getParameter("advance_payment_amount");
			//System.out.println("bookingInvoiceAmount::"+bookingInvoiceAmount);
			//System.out.println("advancePaymentAmount::"+advancePaymentAmount);
			
			long intChmbId = Long.parseLong(ca_chmb_id);
			long intFrmUser = Long.parseLong(bookBy);
			CAChamberRegistration chamberRegistration = CAChamberRegistrationLocalServiceUtil.findByCA_CHAMBER_ID(intChmbId);
			Date openingDate = chamberRegistration.getCHAMBER_OPNING_DATE();
			
			Calendar cal  = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			String strYesterDate = formatter.format(cal.getTime());
			Date yesterDate = formatter.parse(strYesterDate);
			
			if((storeDate.after(yesterDate)) && storeDate.before(openingDate)){
				
				// =========================================================================
				//Insert Data in CA_BOOKING
				long booking_id = 0;
				com.hpmc.portal.db.service.model.CABooking caBooking = null;
				booking_id = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABooking.class.getName());
				caBooking = CABookingLocalServiceUtil.createCABooking(booking_id);
				caBooking.setBOOKED_BY(intFrmUser);
				caBooking.setCA_CHAMBER_ID(intChmbId);
				caBooking.setBOOKING_DATE(new Date());
				caBooking.setSTORAGE_DATE(storeDate);
				CABookingLocalServiceUtil.addCABooking(caBooking);
				
				// ==========================================================================
				//Insert Data in CA_PRODUCT_BOOKING_REL
				String rowIndexes = actionRequest.getParameter("rowIndexes");
				int[] indexOfRows = StringUtil.split(rowIndexes, 0);
				for (int indexOfRow : indexOfRows){
		        	
					long productId = Long.parseLong(ParamUtil.getString(actionRequest, "product_id"+indexOfRow).trim());
					long productWeight= Long.parseLong(ParamUtil.getString(actionRequest, "required_weight"+indexOfRow).trim());
					CAProductRegistration caProductRegistration=CAProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
					
					CAProductBookingManagement caProductbookingManagement = null;
					long productBookingId = 0;
					productBookingId = CounterLocalServiceUtil.increment(CAProductBookingManagement.class.getName());
					caProductbookingManagement = CAProductBookingManagementLocalServiceUtil.createCAProductBookingManagement(productBookingId);
					caProductbookingManagement.setBOOKING_ID(caBooking.getBOOKING_ID());
					caProductbookingManagement.setPRODUCT_ID(productId);
					caProductbookingManagement.setBOOKING_WEIGHT((int)productWeight);
					caProductbookingManagement.setTOTAL_WEIGHT((int)productWeight);
					caProductbookingManagement.setRENT_AMOUNT(caProductRegistration.getRENT());
					CAProductBookingManagementLocalServiceUtil.addCAProductBookingManagement(caProductbookingManagement);
		        	
				}
		        float bookingInvoiceAmount = Float.parseFloat(inputBookingInvoiceAmount);
		        float advancePaymentAmount = Float.parseFloat(inputAdvancePaymentAmount);
				// ==========================================================================
				long invoiceNumber = 0;
				com.hpmc.portal.db.service.model.CABookingAmountManagement caBookingAmount = null;
				invoiceNumber = CounterLocalServiceUtil
						.increment(com.hpmc.portal.db.service.model.CABookingAmountManagement.class
								.getName());
				caBookingAmount = CABookingAmountManagementLocalServiceUtil.createCABookingAmountManagement(invoiceNumber);
				caBookingAmount.setBOOKING_ID(caBooking.getBOOKING_ID());
				caBookingAmount.setADVANCE_PAYMENT_AMOUNT(advancePaymentAmount);
				caBookingAmount.setBOOKING_AMOUNT(bookingInvoiceAmount);
				caBookingAmount.setADVANCE_PAYMENT_MODE(paymentMode);
				CABookingAmountManagementLocalServiceUtil.addCABookingAmountManagement(caBookingAmount);
				
				actionRequest.setAttribute("booking_id", caBooking.getBOOKING_ID());
				
				//Getting user details by userId for sending mail
				UserRegistration userDetails= UserRegistrationLocalServiceUtil.findByUSER_ID(intFrmUser);
				// mail sending 
				
				String mailSubject = "Booking Confirmation Mail.";
				String mailBody = "Hi "+userDetails.getFULL_NAME()+", Your Booking order has been confirmed, booking order id is "+
				String.valueOf(caBooking.getBOOKING_ID())+".\n\n Please Submit Products on "+storeDate+".\n\n\nThank You For Visiting HPMC.";
				HPMCMailSend.feedbackMailSend(mailSubject, mailBody, userDetails.getUSER_NAME());
				
				actionResponse.setRenderParameter("jspPage","/html/ca/after-booking.jsp");
				//System.out.println("Yes");
			}else{
				actionRequest.setAttribute("status", "fail");
				actionRequest.setAttribute("message", "Please enter Correct Storage Date");
				//System.out.println("No");
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
