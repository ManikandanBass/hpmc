package com.hpmc.portal.farmer.controller;

public interface HPMCConstant {

	String CHAMBER_STATUS_LOCKED 	=  "Locked";
	String CHAMBER_STATUS_UNLOCKED  =  "Unlocked";
	
	String ROLE_ADMIN 				= "hpmc_ADMIN";
	String ROLE_COLD_STORAGE 		= "hpmc_COLD_STORAGE";
	String ROLE_CONTROLLED_ATMOSPHIER = "hpmc_CONTROLLED_ATMOSPHIER";
	String ROLE_FARMER 				= "hpmc_FARMER";
	String ROLE_CUSTOMER 			= "hpmc_CUSTOMER";
	String ROLE_AGM 				= "hpmc_AGM";
	String ROLE_STORE_MANAGER 		= "hpmc_STORE_MANAGER";
	
	//Mode of Payment
	String PAYMENT_ONLINE 	= "Online";
	String PAYMENT_CASH 	= "Cash";
	String PAYMENT_CHEQUE 	= "Cheque";
	String PAYMENT_DRAFT 	= "Draft";
	
	String STORAGE_TYPE_CS 	= "CS";
	
	//Withdrawal Type
	String FULLY_WITHDRAWAL = "Fully";
	String PARTIALLY_WITHDRAWAL = "Partially";
	
	Integer CA_MINMUM_WITHDRAWAL_MONTHS = 5;
	
}
