package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import com.hpmc.portal.db.service.NoSuchCARegistrationException;
import com.hpmc.portal.db.service.model.CAChamberRegistration;
import com.hpmc.portal.db.service.model.CAProductRegistration;
import com.hpmc.portal.db.service.model.HPMCLocationRegistration;
import com.hpmc.portal.db.service.service.CAChamberRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CAProductRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CARegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.HPMCLocationRegistrationLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.User;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class AtmosPhereSpaceAvailability
 */
public class CARegistration extends MVCPortlet {

	public void caRegistrationStore(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException,
			PortletException, SystemException {

		String CAName = actionRequest.getParameter("CAName");
		String location = actionRequest.getParameter("location");
		String storageType = "CA Storage";
		long capacity = Long.parseLong(actionRequest
				.getParameter("ca_capacity"));
		String profitCenter = actionRequest.getParameter("profit_center");
		String CAaddress = actionRequest.getParameter("address");

		Set<String> locationSets = new HashSet<String>();
		List<HPMCLocationRegistration> cacsLocations = HPMCLocationRegistrationLocalServiceUtil
				.getHPMCLocationRegistrations(0,
						HPMCLocationRegistrationLocalServiceUtil
								.getHPMCLocationRegistrationsCount());
		for (Iterator iterator = cacsLocations.iterator(); iterator.hasNext();) {
			HPMCLocationRegistration hpmcLocationRegistration = (HPMCLocationRegistration) iterator
					.next();
			locationSets.add(hpmcLocationRegistration.getLOCATION());
		}

		List<String> cacsHpmcLocationRegistrationList = new ArrayList<String>(
				locationSets);
		for (Iterator iterator = cacsHpmcLocationRegistrationList.iterator(); iterator
				.hasNext();) {
			String string = (String) iterator.next();

		}

		actionRequest.setAttribute("locations",
				cacsHpmcLocationRegistrationList);

		long capacityConvertKG = capacity * 1000;
		/*
		 * long ca_id = 0; com.hpmc.portal.db.service.model.CARegistration
		 * caRegistration = null; ca_id =
		 * CounterLocalServiceUtil.increment(CARegistration.class.getName());
		 * caRegistration =
		 * CARegistrationLocalServiceUtil.createCARegistration(ca_id);
		 * caRegistration.setCA_NAME(CAName);
		 * caRegistration.setLOCATION(location);
		 * caRegistration.setCAPACITY(capacityConvertKG);
		 * caRegistration.setCA_ADDRESS(CAaddress);
		 * caRegistration.setPROFIT_CENTER(profitCenter);
		 * CARegistrationLocalServiceUtil.addCARegistration(caRegistration);
		 * long lastInsertCAID = caRegistration.getCA_ID();
		 */
		String rowIndexes = actionRequest.getParameter("rowIndexes");
		String[] indexOfRows = rowIndexes.split(",");

		try {
			long totalChamberCapacity = 0;
			for (int i = 0; i < indexOfRows.length; i++) {
				long ChamberCapacity = Long.parseLong(actionRequest
						.getParameter("chamber_capacity" + indexOfRows[i])
						.trim());
				totalChamberCapacity = totalChamberCapacity + ChamberCapacity;
			}

			if (capacity != totalChamberCapacity) {
				actionRequest
						.setAttribute("messages",
								"Total Capacity must be equal to the sum of chambers capacity.");
				actionResponse.setRenderParameter("jspPage",
						"/html/ca/registration.jsp");
			} else {

				com.hpmc.portal.db.service.model.CARegistration isCheckNameValidation = CARegistrationLocalServiceUtil
						.findByCA_NAME(CAName);
				if (Validator.isNotNull(isCheckNameValidation)) {
					actionRequest.setAttribute("messages",
							"Please Enter Unique CA name.");
					actionResponse.setRenderParameter("jspPage",
							"/html/ca/registration.jsp");
				}/*
				 * else { long chamberId = 0 ; CAChamberRegistration
				 * caChamberRegistration = null; for (int i = 0; i <
				 * indexOfRows.length; i++) { String caChamberName
				 * =actionRequest.getParameter("chamber_name"+
				 * indexOfRows[i]).trim(); long ChamberCapacity =
				 * Long.parseLong(actionRequest.getParameter("chamber_capacity"+
				 * indexOfRows[i]).trim());
				 * 
				 * long chamberCapacityConvertKG = ChamberCapacity * 1000;
				 * chamberId =
				 * CounterLocalServiceUtil.increment(CAChamberRegistration
				 * .class.getName()); caChamberRegistration =
				 * CAChamberRegistrationLocalServiceUtil
				 * .createCAChamberRegistration(chamberId);
				 * 
				 * caChamberRegistration.setCHAMBER_NAME(caChamberName);
				 * caChamberRegistration.setCA_ID(lastInsertCAID);
				 * caChamberRegistration
				 * .setCHAMBER_CAPACITY(chamberCapacityConvertKG);
				 * caChamberRegistration
				 * .setCHAMBER_STATUS(HPMCConstant.CHAMBER_STATUS_LOCKED);
				 * CAChamberRegistrationLocalServiceUtil
				 * .addCAChamberRegistration(caChamberRegistration); }
				 * 
				 * 
				 * }
				 */
			}
		} catch (NoSuchCARegistrationException e) {
			long ca_id = 0;
			com.hpmc.portal.db.service.model.CARegistration caRegistration = null;
			ca_id = CounterLocalServiceUtil.increment(CARegistration.class
					.getName());
			caRegistration = CARegistrationLocalServiceUtil
					.createCARegistration(ca_id);
			caRegistration.setCA_NAME(CAName);
			caRegistration.setLOCATION(location);
			caRegistration.setCAPACITY(capacityConvertKG);
			caRegistration.setCA_ADDRESS(CAaddress);
			caRegistration.setPROFIT_CENTER(profitCenter);
			CARegistrationLocalServiceUtil.addCARegistration(caRegistration);
			long lastInsertCAID = caRegistration.getCA_ID();

			long chamberId = 0;
			CAChamberRegistration caChamberRegistration = null;
			for (int i = 0; i < indexOfRows.length; i++) {
				String caChamberName = actionRequest.getParameter(
						"chamber_name" + indexOfRows[i]).trim();
				long ChamberCapacity = Long.parseLong(actionRequest
						.getParameter("chamber_capacity" + indexOfRows[i])
						.trim());

				long chamberCapacityConvertKG = ChamberCapacity * 1000;
				chamberId = CounterLocalServiceUtil
						.increment(CAChamberRegistration.class.getName());
				caChamberRegistration = CAChamberRegistrationLocalServiceUtil
						.createCAChamberRegistration(chamberId);

				caChamberRegistration.setCHAMBER_NAME(caChamberName);
				caChamberRegistration.setCA_ID(lastInsertCAID);
				caChamberRegistration
						.setCHAMBER_CAPACITY(chamberCapacityConvertKG);
				caChamberRegistration
						.setCHAMBER_STATUS(HPMCConstant.CHAMBER_STATUS_LOCKED);
				CAChamberRegistrationLocalServiceUtil
						.addCAChamberRegistration(caChamberRegistration);
			}

		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void doView(RenderRequest renderRequest,
			RenderResponse renderResponse) throws IOException, PortletException {

		HttpServletRequest request = PortalUtil
				.getOriginalServletRequest(PortalUtil
						.getHttpServletRequest(renderRequest));

		Set<String> locationSets = new HashSet<String>();
		List<HPMCLocationRegistration> cacsLocations = null;
		try {
			cacsLocations = HPMCLocationRegistrationLocalServiceUtil
					.getHPMCLocationRegistrations(0,
							HPMCLocationRegistrationLocalServiceUtil
									.getHPMCLocationRegistrationsCount());
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Iterator iterator = cacsLocations.iterator(); iterator.hasNext();) {
			HPMCLocationRegistration hpmcLocationRegistration = (HPMCLocationRegistration) iterator
					.next();
			locationSets.add(hpmcLocationRegistration.getLOCATION());
		}

		List<String> cacsHpmcLocationRegistrationList = new ArrayList<String>(
				locationSets);
		for (Iterator iterator = cacsHpmcLocationRegistrationList.iterator(); iterator
				.hasNext();) {
			String string = (String) iterator.next();

		}

		renderRequest.setAttribute("locations",
				cacsHpmcLocationRegistrationList);

		ThemeDisplay display = (ThemeDisplay) request
				.getAttribute(WebKeys.THEME_DISPLAY);
		User userDetail = display.getUser();
		try {
			List<Role> roles = RoleLocalServiceUtil.getUserRoles(userDetail
					.getUserId());
		} catch (SystemException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		List<com.hpmc.portal.db.service.model.CARegistration> caRegistrationList = null;

		try {
			caRegistrationList = CARegistrationLocalServiceUtil
					.getCARegistrations(0,
							CounterLocalServiceUtil.getCountersCount());
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (Iterator iterator = caRegistrationList.iterator(); iterator
				.hasNext();) {
			com.hpmc.portal.db.service.model.CARegistration caRegistration = (com.hpmc.portal.db.service.model.CARegistration) iterator
					.next();

			caRegistration.getCA_NAME();
			caRegistration.getCAPACITY();
			caRegistration.getCA_ADDRESS();
			caRegistration.getLOCATION();
			caRegistration.getPROFIT_CENTER();
			caRegistration.getSTORAGE_TYPE();
			caRegistration.getSAP_STATUS();

		}

		renderRequest.setAttribute("caRegistrationList", caRegistrationList);
		
		
		SearchContainer<com.hpmc.portal.db.service.model.CARegistration> searchContainer = 
	            new SearchContainer<com.hpmc.portal.db.service.model.CARegistration>(renderRequest, renderResponse.createRenderURL(), null, "there-are-no-courses");

	    searchContainer.setDelta(5);
	    List<com.hpmc.portal.db.service.model.CARegistration> tempResults = caRegistrationList;/*ActionUtil.getCourses(renderRequest);*/

	    List<com.hpmc.portal.db.service.model.CARegistration> results = ListUtil.subList(tempResults, 
	                                    searchContainer.getStart(), 
	                                    searchContainer.getEnd());

	    searchContainer.setTotal(tempResults.size());
	    searchContainer.setResults(results);
	   
	    

	    renderRequest.setAttribute("searchContainertotal", tempResults.size());
	    renderRequest.setAttribute("searchContainerResults", results);

		super.doView(renderRequest, renderResponse);

	}
	
	public void caProductRegistration(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException,
			PortletException, SystemException {
		
		try {
			
			String controlAtmId = actionRequest.getParameter("controlAtmId");
			String rowIndexes = actionRequest.getParameter("rowIndexes");
			String[] indexOfRows = rowIndexes.split(",");
			long productId = 0, counter = 0;
			for (int i = 0; i < indexOfRows.length; i++) {
				
				String productName = actionRequest.getParameter("productName"+ indexOfRows[i]).trim();
				//String storageType = actionRequest.getParameter("storageType"+ indexOfRows[i]).trim();
				String productRent = actionRequest.getParameter("productRent"+ indexOfRows[i]).trim();
				CAProductRegistration productRegistration = null;
				productId = CounterLocalServiceUtil.increment(CAProductRegistration.class.getName());
				productRegistration = CAProductRegistrationLocalServiceUtil.createCAProductRegistration(productId);
				productRegistration.setCA_ID(Long.parseLong(controlAtmId));
				productRegistration.setPRODUCT_NAME(productName);
				productRegistration.setRENT(Float.parseFloat(productRent));
				CAProductRegistrationLocalServiceUtil.addCAProductRegistration(productRegistration);
				
			}
			
			/*String controlAtmId = actionRequest.getParameter("controlAtmId");
			String productName = actionRequest.getParameter("productName");
			String productRent = actionRequest.getParameter("productRent");
			
			long productId = 0, counter = 0;
			CAProductRegistration productRegistration = null;
			
			List<CAProductRegistration> productList = CAProductRegistrationLocalServiceUtil.getCAProductRegistrations(0,CounterLocalServiceUtil.getCountersCount());
			for(CAProductRegistration productObj : productList){
				counter = productObj.getPRODUCT_ID();
			}
			productId = counter + 1 ;
			productRegistration = CAProductRegistrationLocalServiceUtil.createCAProductRegistration(productId);
			
			productRegistration.setCA_ID(Long.parseLong(controlAtmId));
			productRegistration.setPRODUCT_NAME(productName);
			
			productRegistration.setRENT(Float.parseFloat(productRent));
			CAProductRegistrationLocalServiceUtil.addCAProductRegistration(productRegistration);*/
			
			
			actionRequest.setAttribute("control_atmo_id", controlAtmId);
			actionResponse.setRenderParameter("jspPage", "/html/ca/ProductManagement/CAProductRentDetail.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		
	}
	
	public void caUpdateProductRent(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			long productId = Long.parseLong(actionRequest.getParameter("productId"));
			String productName = actionRequest.getParameter("productName");
			
			String productRent = actionRequest.getParameter("productRent");
			
			CAProductRegistration productDetail = CAProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
			
			productDetail.setPRODUCT_NAME(productName);
			
			productDetail.setRENT(Float.parseFloat(productRent));
			
			CAProductRegistrationLocalServiceUtil.updateCAProductRegistration(productDetail);
			actionRequest.setAttribute("control_atmo_id", productDetail.getCA_ID());
			actionResponse.setRenderParameter("jspPage", "/html/ca/ProductManagement/CAProductRentDetail.jsp");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteProduct(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			long productId = ParamUtil.getLong(actionRequest, "product_id");
			CAProductRegistration productDetail = CAProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
			CAProductRegistrationLocalServiceUtil.deleteCAProductRegistration(productDetail);
			actionRequest.setAttribute("control_atmo_id", productDetail.getCA_ID());
			actionResponse.setRenderParameter("jspPage", "/html/ca/ProductManagement/CAProductRentDetail.jsp");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	

}
