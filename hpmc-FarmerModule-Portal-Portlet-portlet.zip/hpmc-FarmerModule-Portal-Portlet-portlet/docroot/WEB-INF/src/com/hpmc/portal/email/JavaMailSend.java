package com.hpmc.portal.email;

import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class JavaMailSend {

	public static void sendEmail(Session session, String toEmail,String subject,String body){
	   try {

		   MimeMessage message = new MimeMessage(session);
		  
		  message.addHeader("Content-type", "text/HTML; charset=UTF-8");
		  message.addHeader("format", "flowed");
		  message.addHeader("Content-Transfer-Encoding", "8bit");
	      message.setFrom(new InternetAddress("manikandancovai0@gmail.com", "NoReply-JD"));
	      message.setReplyTo(InternetAddress.parse("manikandancovai0@gmail.com", false));
	      message.setSubject(subject, "UTF-8");
	      message.setContent(body, "text/html; charset=utf-8");
	      //message.setText(body, "UTF-8");
	      message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail, false));
	      Transport.send(message);
		  System.out.println("Mail Sending");
		  
	   } catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void TLSMail(String toEmail,String subject,String body){
		
		
		final String fromEmail = "manikandancovai0@gmail.com"; //requires valid gmail id
		final String password = "9952439585"; // correct password for gmail id
		System.out.println("TLSEmail Start");
		
		try {
			Properties props = new Properties();
			props.put("mail.smtp.host", "smtp.gmail.com"); //SMTP Host
			props.put("mail.smtp.port", "587"); //TLS Port
			props.put("mail.smtp.auth", "true"); //enable authentication
			props.put("mail.smtp.starttls.enable", "true"); //enable STARTTLS
			
			//create Authenticator object to pass in Session.getInstance argument
			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			    protected PasswordAuthentication getPasswordAuthentication() {
			        return new PasswordAuthentication(fromEmail, password);
			    }
			});

			MimeMessage message = new MimeMessage(session);
			  
			message.addHeader("Content-type", "text/HTML; charset=UTF-8");
			message.addHeader("format", "flowed");
			message.addHeader("Content-Transfer-Encoding", "8bit");
			message.setFrom(new InternetAddress("manikandancovai0@gmail.com", "NoReply-JD"));
			message.setReplyTo(InternetAddress.parse("manikandancovai0@gmail.com", false));
			message.setSubject(subject, "UTF-8");
			message.setContent(body, "text/html; charset=utf-8");
			//message.setText(body, "UTF-8");
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail, false));
			Transport.send(message);
			System.out.println("Mail Sending");
			
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			System.out.println("Mail Send Successfully");
		}
		
		
	}

}

