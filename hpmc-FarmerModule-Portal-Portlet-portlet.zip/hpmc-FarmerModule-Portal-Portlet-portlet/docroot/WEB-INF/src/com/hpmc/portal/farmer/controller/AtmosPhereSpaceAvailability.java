package com.hpmc.portal.farmer.controller;

import com.liferay.util.bridges.mvc.MVCPortlet;

public class AtmosPhereSpaceAvailability extends MVCPortlet {

}
