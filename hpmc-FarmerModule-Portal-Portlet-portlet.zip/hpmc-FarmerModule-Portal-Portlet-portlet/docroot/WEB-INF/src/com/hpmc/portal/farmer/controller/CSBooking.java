package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;






import com.hpmc.portal.db.service.NoSuchCSBookingException;
import com.hpmc.portal.db.service.model.CAProductBookingManagement;
import com.hpmc.portal.db.service.model.CSChamberFloorBookingRegistration;
import com.hpmc.portal.db.service.model.CSProductBookingManagement;
import com.hpmc.portal.db.service.model.CSProductRegistration;
import com.hpmc.portal.db.service.model.CSRegistration;
import com.hpmc.portal.db.service.service.CABookingAmountManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CABookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CAProductBookingManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSBookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSChamberFloorBookingRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductBookingManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSRegistrationLocalServiceUtil;
import com.hpmc.portal.email.CSMailCommunication;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CSBooking extends MVCPortlet {

	public void searchCSByLocation(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException {
		
		try {
			String cs_location = actionRequest.getParameter("cs_location");
			actionResponse.setRenderParameter("cs_location", cs_location);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void doView(RenderRequest renderRequest,RenderResponse renderResponse) throws IOException {
		List<CSRegistration> csRegistrationList = null;
		try {
			List<CSRegistration> csRegistrations = null;
			String locationName = ParamUtil.get(renderRequest,"cs_location","");
			
			if(locationName != ""){
				csRegistrations = CSRegistrationLocalServiceUtil.findByLOCATION(locationName);
				Set<CSRegistration> csRegistrationsSet=new HashSet<CSRegistration>(csRegistrations);
				csRegistrationList= new ArrayList<CSRegistration>(csRegistrationsSet);
				
			}
			renderRequest.setAttribute("csList", csRegistrationList);
			renderRequest.setAttribute("inputLocation", locationName);
			
			
			Set locationSet= new HashSet();
			
			List<CSRegistration> csRegistrationsLists = CSRegistrationLocalServiceUtil.getCSRegistrations(0, CSRegistrationLocalServiceUtil.getCSRegistrationsCount());
			for (Iterator iterator = csRegistrationsLists.iterator(); iterator
					.hasNext();) {
				CSRegistration csRegistration = (CSRegistration) iterator
						.next();
				locationSet.add(csRegistration.getLOCATION());
			}
			List locationList= new ArrayList(locationSet);
			renderRequest.setAttribute("csRegistrationsLists",locationList );
			
			
			super.doView(renderRequest, renderResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	
	public void csBookingDetailsStored(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException{
		
		try {
			
			/*boolean isAgree = Boolean.parseBoolean(actionRequest.getParameter("agree_trems"));
			if(isAgree == false){
				throw new ArithmeticException ("Please agree the trems and contditions.");
			}*/
			//Insert Data in CS_Booking
			long CS_ID = Long.parseLong(actionRequest.getParameter("CSID"));
			long farmerUserid = Long.parseLong(actionRequest.getParameter("userid"));
			long csBookingId = 0;
			com.hpmc.portal.db.service.model.CSBooking csBooking = null;
			csBookingId = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CSBooking.class.getName());
			csBooking = CSBookingLocalServiceUtil.createCSBooking(csBookingId);
			csBooking.setBOOKED_BY(farmerUserid);
			csBooking.setCS_ID(CS_ID);
			csBooking.setBOOKING_DATE(new Date());
			CSBookingLocalServiceUtil.addCSBooking(csBooking);
			long lastBookingId = csBooking.getBOOKING_ID();
			
        	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date fromDate = (Date) formatter.parse(actionRequest.getParameter("fromDate").trim());

			//Insert Data in CS_PRODUCT_BOOKING_REL
			String rowIndexes = actionRequest.getParameter("rowIndexes");
	        String[] indexOfRows = rowIndexes.split(",");
	        
	        for (int i = 0; i < indexOfRows.length; i++) {
	        	long productId = Long.parseLong(actionRequest.getParameter("productType"+ indexOfRows[i]).trim());
	        	long number_of_bags = Long.parseLong(actionRequest.getParameter("number_of_bags"+ indexOfRows[i]).trim());
	        	
	        	CSProductRegistration productRegistration = CSProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
	        	
				//Insert Data in CS_PRODUCT_BOOKING_REL
				long productBookingRelId = 0;
				productBookingRelId = CounterLocalServiceUtil.increment(CSProductBookingManagement.class.getName());
				CSProductBookingManagement csProductBookingManagement = null;
				csProductBookingManagement = CSProductBookingManagementLocalServiceUtil.createCSProductBookingManagement(productBookingRelId);
				csProductBookingManagement.setBOOKING_ID(lastBookingId);
				csProductBookingManagement.setPRODUCT_ID(productId);
				csProductBookingManagement.setRENT_AMOUNT(productRegistration.getRENT());
				csProductBookingManagement.setBOOKING_NUMBER_OF_BAGS((int) number_of_bags);
				csProductBookingManagement.setFROM_DATE(fromDate);
				CSProductBookingManagementLocalServiceUtil.addCSProductBookingManagement(csProductBookingManagement);
				
			}
	        
	        CSMailCommunication.bookingConfirmation(lastBookingId);
	        
	        actionRequest.setAttribute("cold_storage_id",CS_ID);
	        actionRequest.setAttribute("booking_id",lastBookingId);
	        actionRequest.setAttribute("farmerUserid",farmerUserid);
			actionResponse.setRenderParameter("jspPage", "/html/cs/view-details/after-booking-details.jsp");
			
		} /*catch(ArithmeticException aex){
			actionRequest.setAttribute("messages", aex.getMessage());
			actionResponse.setRenderParameter("jspPage", "/html/cs/booking-form-details.jsp");
		} */catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void chamberBooking(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException{
		try {
			String bookBy = actionRequest.getParameter("user_id");
			String ca_chmb_id = actionRequest.getParameter("ca_chamber_id");
			String productType = actionRequest.getParameter("product_id");
			String paymentMode = actionRequest.getParameter("payment_mode");
			//System.out.println(paymentMode);
			String bookingInvoiceAmount = actionRequest.getParameter("booking_invoice_amount");
			String advancePaymentAmount = actionRequest.getParameter("advance_payment_amount");
			
			String requiredWeight = actionRequest.getParameter("required_weight");
			//System.out.println(1);
			long intproductType = Long.parseLong(productType);
			long intChmbId = Long.parseLong(ca_chmb_id);
			long intRequiredWeight = Long.parseLong(requiredWeight);
			long intFrmUser = Long.parseLong(bookBy);
			long booking_id = 0;
			//System.out.println(2);
			com.hpmc.portal.db.service.model.CABooking caBooking = null;
			booking_id = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABooking.class.getName());
			caBooking = CABookingLocalServiceUtil.createCABooking(booking_id);
			caBooking.setBOOKED_BY(intFrmUser);
			caBooking.setCA_CHAMBER_ID(intChmbId);
			caBooking.setBOOKING_DATE(new Date());
			CABookingLocalServiceUtil.addCABooking(caBooking);
			//System.out.println(3);
			//==========================================================================
			
			long productBookingId = 0;
			CAProductBookingManagement caProductbookingManagement = null;
			productBookingId = CounterLocalServiceUtil.increment(CAProductBookingManagement.class.getName());
			
			caProductbookingManagement = CAProductBookingManagementLocalServiceUtil.createCAProductBookingManagement(productBookingId);
			caProductbookingManagement.setBOOKING_ID(caBooking.getBOOKING_ID());
			caProductbookingManagement.setPRODUCT_ID(intproductType);
			caProductbookingManagement.setBOOKING_WEIGHT((int) intRequiredWeight);
			CAProductBookingManagementLocalServiceUtil.addCAProductBookingManagement(caProductbookingManagement);
			//System.out.println(4);
			long intBookingInvoiceAmount = Long.parseLong(bookingInvoiceAmount);
			long intAdvancePaymentAmount = Long.parseLong(advancePaymentAmount);
			//==========================================================================
			long invoiceNumber = 0;
			com.hpmc.portal.db.service.model.CABookingAmountManagement caBookingAmount = null;
			invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABookingAmountManagement.class.getName());
			caBookingAmount = CABookingAmountManagementLocalServiceUtil.createCABookingAmountManagement(invoiceNumber);
			caBookingAmount.setBOOKING_ID(caBooking.getBOOKING_ID());
			caBookingAmount.setBOOKING_AMOUNT((int) intBookingInvoiceAmount);
			caBookingAmount.setADVANCE_PAYMENT_AMOUNT((int) intAdvancePaymentAmount);
			CABookingAmountManagementLocalServiceUtil.addCABookingAmountManagement(caBookingAmount);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void cancelBookingOrderNumber(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
			long cancelBookingId = Long.parseLong(actionRequest.getParameter("cs_cancel_booking_no"));
			try {
				
				if(cancelBookingId != 0){
					//List<CSBooking> bookingsList = null;
					com.hpmc.portal.db.service.model.CSBooking csBookings = CSBookingLocalServiceUtil.findByBOOKING_ID(cancelBookingId);
					actionRequest.setAttribute("bookingId", cancelBookingId);
					
					if(csBookings.getBOOKING_STATUS() == true){
						throw new ArithmeticException("Already Canceled this booking id("+cancelBookingId+").");
					}else{
						
						List<CSProductBookingManagement> productBooking = CSProductBookingManagementLocalServiceUtil.findByBOOKING_ID(cancelBookingId);
						
						for (CSProductBookingManagement csProductBookingManagement : productBooking) {
							List<CSChamberFloorBookingRegistration> chamberFloorBooking = CSChamberFloorBookingRegistrationLocalServiceUtil.findByPRODUCT_BOOKING_ID(csProductBookingManagement.getPRODUCT_BOOKING_ID());
							if(chamberFloorBooking.size() > 0){
								throw new ArithmeticException("You can't cancel the booking id ("+cancelBookingId+")."
										+ " Because already stored some products.");
							}
						}
						
						
						if(actionRequest.getParameter("type") != null && 
								actionRequest.getParameter("type").equalsIgnoreCase("cancel_booking")){
							csBookings.setBOOKING_STATUS(true);
							CSBookingLocalServiceUtil.updateCSBooking(csBookings);
							CSMailCommunication.cancelBookingConfirmation(cancelBookingId);
							
							actionRequest.setAttribute("messages", "Successfully Canceled Your Booking("+cancelBookingId+").");
							actionRequest.setAttribute("action", "canceled");
							actionRequest.setAttribute("bookingId", null);
						}
						
					}
					actionRequest.setAttribute("status", "success");
					actionResponse.setRenderParameter("jspPage", "/html/cs/cancelBooking.jsp");
				}
				
			} catch(ArithmeticException ari){
				actionRequest.setAttribute("status", "fail");
				actionRequest.setAttribute("messages", ari.getMessage());
				actionResponse.setRenderParameter("jspPage", "/html/cs/cancelBooking.jsp");
			} catch(NoSuchCSBookingException nobookingid){
				actionRequest.setAttribute("status", "fail");
				actionRequest.setAttribute("messages", "Please enter Correct Booking Id");
				actionRequest.setAttribute("bookingId", cancelBookingId);
				actionResponse.setRenderParameter("jspPage", "/html/cs/cancelBooking.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	
	
	
}
