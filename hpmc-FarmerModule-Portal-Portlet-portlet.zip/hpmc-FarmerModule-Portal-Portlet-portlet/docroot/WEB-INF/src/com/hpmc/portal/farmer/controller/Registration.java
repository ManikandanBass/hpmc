package com.hpmc.portal.farmer.controller;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.hpmc.portal.db.service.model.AddressRegistration;
import com.hpmc.portal.db.service.model.CustomerRegistration;
import com.hpmc.portal.db.service.model.UserRegistration;
import com.hpmc.portal.db.service.service.AddressRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CustomerRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.UserRegistrationLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.model.User;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class Registration extends MVCPortlet {
	
	public void customerRegistration(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		try {
			String bookingType = actionRequest.getParameter("booking_type");
			String customerName = actionRequest.getParameter("customerName");
			String fatherHusbandName = actionRequest.getParameter("fatherHusbandName");
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date birthdate = (Date) formatter.parse(actionRequest.getParameter("birthdate"));
			String gender = actionRequest.getParameter("gender");
			String houseNo = actionRequest.getParameter("houseNo");
			String area = actionRequest.getParameter("area");
			String landmark = actionRequest.getParameter("landmark");
			String district = actionRequest.getParameter("district");
			String state = actionRequest.getParameter("state");
			int pinCode = Integer.parseInt(actionRequest.getParameter("pinCode"));
			String email = actionRequest.getParameter("email");
			long aadharNo = Long.parseLong(actionRequest.getParameter("aadharNo")) ;
			String panNo = actionRequest.getParameter("panNo");
			String electionCardNo = actionRequest.getParameter("electionNo");
			long mobileNo = Long.parseLong(actionRequest.getParameter("mobileNo"));
				Date creationDate=java.util.Calendar.getInstance().getTime();
				
					
					long customerAddressId = 0;
					AddressRegistration customerAddressRegistration = null;
					customerAddressId = CounterLocalServiceUtil.increment(AddressRegistration.class.getName());
					customerAddressRegistration = AddressRegistrationLocalServiceUtil.createAddressRegistration(customerAddressId);
					
					customerAddressRegistration.setFLAT_HOUSE_DOOR_NUM(houseNo);
					customerAddressRegistration.setVILLAGE_AREA_LOCALITY(area);
					customerAddressRegistration.setROAD_STREET_LANDMARK(landmark);
					customerAddressRegistration.setCITY_DISTRICT(district);
					customerAddressRegistration.setSTATE_UNIONTERITORY(state);
					customerAddressRegistration.setPINCODE(pinCode);
					AddressRegistrationLocalServiceUtil.addAddressRegistration(customerAddressRegistration);
					
					
					long customerUserId = 0;
					customerUserId = CounterLocalServiceUtil.increment(User.class.getName());
					UserRegistration customerUserRegistration = null;
					customerUserRegistration = UserRegistrationLocalServiceUtil.createUserRegistration(customerUserId);
					
					customerUserRegistration.setFULL_NAME(customerName);
					customerUserRegistration.setFATHER_HUSBAND_NAME(fatherHusbandName);
					customerUserRegistration.setDATE_OF_BIRTH(birthdate);
					customerUserRegistration.setGENDER(gender);
					customerUserRegistration.setUSER_NAME(email);
					customerUserRegistration.setUSER_ROLE(HPMCConstant.ROLE_CUSTOMER);
					customerUserRegistration.setCREATION_DATE(creationDate);
					UserRegistrationLocalServiceUtil.addUserRegistration(customerUserRegistration);
					
					CustomerRegistration customerRegistration = null;
					customerRegistration = CustomerRegistrationLocalServiceUtil.createCustomerRegistration(customerUserId);
					customerRegistration.setAADHAR_NUM(aadharNo);
					customerRegistration.setELECTION_CARD_NUM(electionCardNo);
					customerRegistration.setPAN_NUM(panNo);
					customerRegistration.setMOBILE_NUM(mobileNo);
					CustomerRegistrationLocalServiceUtil.addCustomerRegistration(customerRegistration);
			
					if(bookingType.equalsIgnoreCase("CS")){
						System.out.println("CS Offline Booking");
						actionRequest.setAttribute("customer_user_id", customerUserId);
						actionResponse.setRenderParameter("jspPage", "/html/cs/offline-booking/offline-booking.jsp");
					}
					if(bookingType.equalsIgnoreCase("CA")){
						System.out.println("CA Offline Booking");
						actionRequest.setAttribute("customer_user_id", customerUserId);
						actionResponse.setRenderParameter("jspPage", "/html/ca/offline-booking/offline-booking.jsp");
					}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}