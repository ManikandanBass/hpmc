package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.hpmc.portal.db.service.NoSuchCABookingException;
import com.hpmc.portal.db.service.NoSuchCAProductBookingManagementException;
import com.hpmc.portal.db.service.model.CABooking;
import com.hpmc.portal.db.service.model.CABookingAmountManagement;
import com.hpmc.portal.db.service.model.CAProductBookingManagement;
import com.hpmc.portal.db.service.service.CABookingAmountManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CABookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CAProductBookingManagementLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CAWithdraw extends MVCPortlet {

	
	
	//================================================USING FUNCTIONS STARTS=================================================//
	
		public void searchBookingOrderNumber(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
			long withDrawBookingId = Long.parseLong(actionRequest.getParameter("ca_booking_no"));
			try {
				
				if(withDrawBookingId != 0){
					//List<CSBooking> bookingsList = null;
					
					com.hpmc.portal.db.service.model.CABooking caBookings = CABookingLocalServiceUtil.findByBOOKING_ID(withDrawBookingId);
					if(caBookings.getBOOKING_STATUS() == true){
						throw new ArithmeticException("Canceled this booking id("+withDrawBookingId+").");
					}
					actionRequest.setAttribute("status", "success");
					actionRequest.setAttribute("bookingId", withDrawBookingId);
					
				}
				
			} catch(ArithmeticException arith){
				actionRequest.setAttribute("status", "fail");
				actionRequest.setAttribute("messages", arith.getMessage());
				actionResponse.setRenderParameter("jspPage", "/html/cs/with-draw/search-booking-order.jsp");
			} catch(NoSuchCABookingException nobookingid){
				actionRequest.setAttribute("status", "fail");
				actionRequest.setAttribute("messages", "Please enter Correct Booking Id");
				actionRequest.setAttribute("bookingId", withDrawBookingId);
				actionResponse.setRenderParameter("jspPage", "/html/ca/with-draw/search-booking-order.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		public void actionFullyWithdrawal(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException {
			
			long productBookingId = Long.parseLong(actionRequest.getParameter("product_booking_id"));
			long bookingId = Long.parseLong(actionRequest.getParameter("booking_id"));
			long withDrawalWeight = Long.parseLong(actionRequest.getParameter("with_drawal_weight"));
			
			try {
				
				//Update Data in hpmc_ca_product_booking_rel
				CAProductBookingManagement caProductBooking = CAProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBookingId);
				caProductBooking.setWITHDRAW_WEIGHT((int) withDrawalWeight);
				//caProductBooking.setWITHDRAW_DATE(new Date());
				CAProductBookingManagementLocalServiceUtil.updateCAProductBookingManagement(caProductBooking);
				
				actionRequest.setAttribute("status", "success");
				actionRequest.setAttribute("bookingId", bookingId);
				actionResponse.setRenderParameter("jspPage", "/html/ca/with-draw/search-booking-order.jsp");
				
			} catch ( NoSuchCAProductBookingManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (SystemException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		public void actionPartiallyWithdrawal(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException {
			long withDrawBookingId = Long.parseLong(actionRequest.getParameter("booking_id"));
			long productBookingId = Long.parseLong(actionRequest.getParameter("product_booking_id"));
			long partialWeight = Long.parseLong(actionRequest.getParameter("partial_weight"));
			
			try {
				
				//Update Data in hpmc_ca_product_booking_rel
				CAProductBookingManagement caProductBooking = CAProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(productBookingId);
				caProductBooking.setWITHDRAW_WEIGHT((int) partialWeight);
				//caProductBooking.setWITHDRAW_DATE(new Date());
				CAProductBookingManagementLocalServiceUtil.updateCAProductBookingManagement(caProductBooking);
				
				//New CA Product Booking Record Created
				long remainingTotalWeight =  (int) (caProductBooking.getTOTAL_WEIGHT() - partialWeight);
				
				if(remainingTotalWeight > 0){
					//ReBooked All Products
					long newProductBookingId = 0;
					CAProductBookingManagement caProductbookingManagement = null;
					newProductBookingId = CounterLocalServiceUtil.increment(CAProductBookingManagement.class.getName());
					caProductbookingManagement = CAProductBookingManagementLocalServiceUtil.createCAProductBookingManagement(newProductBookingId);
					caProductbookingManagement.setBOOKING_ID(caProductBooking.getBOOKING_ID());
					caProductbookingManagement.setPRODUCT_ID(caProductBooking.getPRODUCT_ID());
					caProductbookingManagement.setBOOKING_WEIGHT((int) remainingTotalWeight);
					caProductbookingManagement.setTOTAL_WEIGHT((int) remainingTotalWeight);
					caProductbookingManagement.setRENT_AMOUNT(caProductBooking.getRENT_AMOUNT());
					caProductbookingManagement.setBOX_NUM(caProductBooking.getBOX_NUM());
					CAProductBookingManagementLocalServiceUtil.addCAProductBookingManagement(caProductbookingManagement);
				}
				actionRequest.setAttribute("status", "success");
				actionRequest.setAttribute("bookingId", withDrawBookingId);
				actionResponse.setRenderParameter("jspPage", "/html/ca/with-draw/search-booking-order.jsp");
				
				
			} catch ( NoSuchCAProductBookingManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		
		//New action for Over All Withdrawn
		public void actionOverAllWithdrawal(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException {
			long bookingId = 0;
			try {
				
				if (!actionRequest.getParameter("booking_id").isEmpty() && 
						!actionRequest.getParameter("payment_mode").isEmpty() 
						) {
					
					float totalProductsChargedAmount = 0;
					float decreaseAdvanceAmount = 0;
					long lastInvoiceNumber = 0;
					
					bookingId = Long.parseLong(actionRequest
							.getParameter("booking_id"));
					String paymentMode = actionRequest
							.getParameter("payment_mode");
					String chequeDraftDetails = actionRequest
							.getParameter("cheque_draft_details");
					
					/*Nirav Changes Start*/
					String cashDetails = actionRequest
							.getParameter("cashDetails");
					/*Nirav End*/					//=========================================================
					
					
					CABooking caBooking = CABookingLocalServiceUtil.findByBOOKING_ID(bookingId);
					List<CAProductBookingManagement> productsBookingList = CAProductBookingManagementLocalServiceUtil.findByBOOKING_ID(bookingId);
					List<CAProductBookingManagement> productsWithdrawalList =new ArrayList<CAProductBookingManagement>();
					List<CAProductBookingManagement> productsWithdrawnList =new ArrayList<CAProductBookingManagement>();
					
					
					Calendar startCalendar = new GregorianCalendar();
					startCalendar.setTime(caBooking.getBOOKING_DATE());
					Calendar endCalendar = new GregorianCalendar();
					endCalendar.setTime(new Date());

					int diffYear  = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
					int diffMonth = (diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH)) + 1;
					
					for (Iterator iterator = productsBookingList.iterator(); iterator
							.hasNext();) {
						CAProductBookingManagement caProductBookingManagement = (CAProductBookingManagement) iterator
								.next();
						if(caProductBookingManagement.getINVOICE_NUMBER()==0 && 
								caProductBookingManagement.getBOX_NUM()!=0){
							productsWithdrawalList.add(caProductBookingManagement);
							
						}
						if((caProductBookingManagement.getWITHDRAW_WEIGHT()!=0 &&
								caProductBookingManagement.getINVOICE_NUMBER() == 0) && 
								caProductBookingManagement.getBOX_NUM() != 0){
							productsWithdrawnList.add(caProductBookingManagement);
							totalProductsChargedAmount = (caProductBookingManagement.getWITHDRAW_WEIGHT() * 
									caProductBookingManagement.getRENT_AMOUNT() * diffMonth);
							
						}
						
					}
					
					
					if(productsWithdrawnList.size() < 1){
						throw new ArithmeticException("Nothing Withdrawn Products. Because Nothing happened Full/Partial Withdrawal."); 
					}
					
					//System.out.println("productsWithdrawalList = "+productsWithdrawalList.size());
					//System.out.println("productsWithdrawnList = "+productsWithdrawnList.size());
					
					//Find Booking Amount management Record From hpmc_ca_booking_amount_charged Table.
					List<CABookingAmountManagement> amountManagement = CABookingAmountManagementLocalServiceUtil.findByBOOKING_ID(bookingId);
					CABookingAmountManagement amountManagement2 = amountManagement.get(0);
					String issetTotalAmountColumn = String.valueOf(amountManagement2.getTOTAL_PAYABLE_AMOUNT()) ;
					if(amountManagement.size() == 1 && issetTotalAmountColumn.isEmpty()){
						
						if(productsWithdrawalList.size() > 0){
							amountManagement2.setTOTAL_PAYABLE_AMOUNT(totalProductsChargedAmount);
						}else{
							decreaseAdvanceAmount = totalProductsChargedAmount - amountManagement2.getADVANCE_PAYMENT_AMOUNT();
							amountManagement2.setTOTAL_PAYABLE_AMOUNT(decreaseAdvanceAmount);
						}
						amountManagement2.setTOTAL_PAYABLE_PAYMENT_CHECK_DRAFT_DETAIL(chequeDraftDetails);
						amountManagement2.setTOTAL_PAYABLE_PAYMENT_MODE(paymentMode);
						/* Nirav Changes*/
						amountManagement2.setTOTAL_PAYABLE_PAYMENT_CASH_DETAIL(cashDetails);
						/* Nirav End*/
						CABookingAmountManagementLocalServiceUtil.updateCABookingAmountManagement(amountManagement2);
						lastInvoiceNumber = amountManagement2.getINVOICE_NUMBER();
						
					}else if((amountManagement.size() > 0) || (amountManagement.size() == 1 && !issetTotalAmountColumn.isEmpty()) ){
						
						long invoiceNumber = 0;
						com.hpmc.portal.db.service.model.CABookingAmountManagement caBookingAmount = null;
						invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABookingAmountManagement.class.getName());
						caBookingAmount = CABookingAmountManagementLocalServiceUtil.createCABookingAmountManagement(invoiceNumber);
						caBookingAmount.setBOOKING_ID(bookingId);
						caBookingAmount.setTOTAL_PAYABLE_PAYMENT_CHECK_DRAFT_DETAIL(chequeDraftDetails);
						caBookingAmount.setTOTAL_PAYABLE_PAYMENT_MODE(paymentMode);
						
						
						if(productsWithdrawalList.size() > 0){
							caBookingAmount.setTOTAL_PAYABLE_AMOUNT(totalProductsChargedAmount);
						}else{
							decreaseAdvanceAmount = totalProductsChargedAmount - amountManagement2.getADVANCE_PAYMENT_AMOUNT();
							caBookingAmount.setTOTAL_PAYABLE_AMOUNT(decreaseAdvanceAmount);
						}
						
						CABookingAmountManagementLocalServiceUtil.addCABookingAmountManagement(caBookingAmount);
						lastInvoiceNumber = caBookingAmount.getINVOICE_NUMBER();
						
						
					}else{
						actionRequest.setAttribute("message","Invoice Record Problem.");
						actionRequest.setAttribute("status", "fail");
						actionResponse.setRenderParameter("jspPage","/html/cs/with-draw/search-booking-order.jsp");
					}
					
					
					//productsWithdrawnList
					for (CAProductBookingManagement productsWithdrawn : productsWithdrawnList) {
						productsWithdrawn.setINVOICE_NUMBER(lastInvoiceNumber);
						productsWithdrawn.setWITHDRAW_DATE(new Date());
						CAProductBookingManagementLocalServiceUtil.updateCAProductBookingManagement(productsWithdrawn);
					}
					
					
					actionRequest.setAttribute("booking_id", bookingId);
					actionRequest.setAttribute("invoice_id",lastInvoiceNumber);
					actionRequest.setAttribute("status", "success");
					actionRequest.setAttribute("message","Succesfully Withdrawn Products.");
					actionResponse.setRenderParameter("jspPage","/html/ca/with-draw/success-withdrawn-details.jsp");
					
					//System.out.println("Manikandan :: ==");
				}else{
					actionRequest.setAttribute("bookingId", Long.valueOf(actionRequest.getParameter("booking_id")));
					actionRequest
							.setAttribute("message",
									"Please Check Inputs Values.(Payment Mode / Type).");
					actionRequest.setAttribute("status", "fail");
					actionResponse
							.setRenderParameter("jspPage",
									"/html/ca/with-draw/search-booking-order.jsp");
				}
				
			} catch ( ArithmeticException arith) {
				actionRequest.setAttribute("status", "fail");
				actionRequest.setAttribute("bookingId", bookingId);
				actionRequest.setAttribute("message", arith.getMessage());
				actionResponse.setRenderParameter("jspPage", "/html/ca/with-draw/search-booking-order.jsp");

			} catch (Exception e) {
				e.printStackTrace();
				
			}
			
			
		}
		
		
		
		//================================================USING FUNCTIONS END=================================================//
	
	
	
	/*public void fullWithdrawPayment(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		long withDrawBookingId = Long.parseLong(actionRequest.getParameter("booking_id"));
		float withDrawPayable_amount = Float.parseFloat(actionRequest.getParameter("payable_amount"));
		try {
			
			CABookingAmountManagement amountManagements =  CABookingAmountManagementLocalServiceUtil.findByBOOKING_ID(withDrawBookingId);
			amountManagements.setTOTAL_PAYABLE_AMOUNT(withDrawPayable_amount);
			CABookingAmountManagementLocalServiceUtil.updateCABookingAmountManagement(amountManagements);
			
		} catch(ArithmeticException e){ 
			e.printStackTrace();
		} catch (NoSuchCABookingAmountManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/
	
	/*public void partialWithdrawPayment(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException, NoSuchCABookingAmountManagementException, SystemException, NoSuchCAProductBookingManagementException {
		
		long withDrawBookingId = Long.parseLong(actionRequest.getParameter("booking_id"));
		float CAChamber_rent = Float.parseFloat(actionRequest.getParameter("ca_chamber_rent"));
		float withDrawPayable_amount = Float.parseFloat(actionRequest.getParameter("payable_amount"));
		System.out.println(withDrawBookingId);
		System.out.println(withDrawPayable_amount);
		try {
			
			CABookingAmountManagement amountManagements =  CABookingAmountManagementLocalServiceUtil.findByBOOKING_ID(withDrawBookingId);
			amountManagements.setTOTAL_PAYABLE_AMOUNT(withDrawPayable_amount);
			CABookingAmountManagementLocalServiceUtil.updateCABookingAmountManagement(amountManagements);
			
			
			//Insert Data in CS_Booking
			long ca_chamber_id = Long.parseLong(actionRequest.getParameter("ca_chamber_id"));
			long farmerUserid = Long.parseLong(actionRequest.getParameter("userid"));
			String farmerUserName = actionRequest.getParameter("username");
			
			
			long booking_id = 0;
			com.hpmc.portal.db.service.model.CABooking caBooking = null;
			booking_id = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABooking.class.getName());
			caBooking = CABookingLocalServiceUtil.createCABooking(booking_id);
			caBooking.setBOOKED_BY(farmerUserid);
			caBooking.setCA_CHAMBER_ID(ca_chamber_id);
			caBooking.setCUSTOMER_NAME(farmerUserName);
			caBooking.setPARENT_BOOKING_ID(withDrawBookingId);
			caBooking.setBOOKED_BY(farmerUserid);
			caBooking.setBOOKING_DATE(new Date());
			CABookingLocalServiceUtil.addCABooking(caBooking);
			long lastBookingId = caBooking.getBOOKING_ID();
			
			
			long reBookingTotalWeight = 0;
			
			long rowOfCount = Long.parseLong(actionRequest.getParameter("rowCount"));
			for (int i = 1; i <= rowOfCount; i++) {
				long CAProduct_booking_id = Long.parseLong(actionRequest.getParameter("product_booking_id"+ i));
				long CAWithdraw_weight = Long.parseLong(actionRequest.getParameter("withdraw_weight"+ i));
				long CAproduct_id = Long.parseLong(actionRequest.getParameter("product_id"+ i));
				
				//Update Withdraw Weight
				CAProductBookingManagement productBooking = CAProductBookingManagementLocalServiceUtil.findByPRODUCT_BOOKING_ID(CAProduct_booking_id);
				long beforeWeight = productBooking.getBOOKING_WEIGHT();
				long remainingWeight = (int) (beforeWeight - CAWithdraw_weight);
				float rentAmount = remainingWeight * CAChamber_rent;
				
				productBooking.setWITHDRAW_WEIGHT((int) CAWithdraw_weight);
				productBooking.setWITHDRAW_DATE(new Date());
				CAProductBookingManagementLocalServiceUtil.updateCAProductBookingManagement(productBooking);
				
				//ReBooked All Products
				long productBookingId = 0;
				CAProductBookingManagement caProductbookingManagement = null;
				productBookingId = CounterLocalServiceUtil.increment(CAProductBookingManagement.class.getName());
				caProductbookingManagement = CAProductBookingManagementLocalServiceUtil.createCAProductBookingManagement(productBookingId);
				caProductbookingManagement.setBOOKING_ID(lastBookingId);
				caProductbookingManagement.setPRODUCT_ID(CAproduct_id);
				caProductbookingManagement.setBOOKING_WEIGHT((int) remainingWeight);
				caProductbookingManagement.setRENT_AMOUNT(rentAmount);
				CAProductBookingManagementLocalServiceUtil.addCAProductBookingManagement(caProductbookingManagement);
				
				reBookingTotalWeight = reBookingTotalWeight+remainingWeight;
				//Remaining Weight Create new record
				
				System.out.println("CAProduct_booking_id::"+ CAProduct_booking_id + " /CAWithdraw_weight::"+CAWithdraw_weight);
			}
			
			float perMonthRent = CAChamber_rent * reBookingTotalWeight;
			
			float intBookingInvoiceAmount = perMonthRent*4;
			//==========================================================================
			long invoiceNumber = 0;
			com.hpmc.portal.db.service.model.CABookingAmountManagement caBookingAmount = null;
			invoiceNumber = CounterLocalServiceUtil.increment(com.hpmc.portal.db.service.model.CABookingAmountManagement.class.getName());
			caBookingAmount = CABookingAmountManagementLocalServiceUtil.createCABookingAmountManagement(invoiceNumber);
			caBookingAmount.setBOOKING_ID(lastBookingId);
			caBookingAmount.setBOOKING_AMOUNT((int) intBookingInvoiceAmount);
			caBookingAmount.setADVANCE_PAYMENT_AMOUNT((int) amountManagements.getADVANCE_PAYMENT_AMOUNT());
			CABookingAmountManagementLocalServiceUtil.addCABookingAmountManagement(caBookingAmount);
			
			
		} catch(ArithmeticException e){ 
			e.printStackTrace();
		}
		
		//CAProductBookingManagement bookingManagement = CAProductBookingManagementLocalServiceUtil.findByBOOKING_ID(withDrawBookingId);
		
	}*/
	
}
