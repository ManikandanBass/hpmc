package com.hpmc.portal.farmer.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.hpmc.portal.db.service.model.CSBooking;
import com.hpmc.portal.db.service.model.CSProductBookingManagement;
import com.hpmc.portal.db.service.model.CSProductRegistration;
import com.hpmc.portal.db.service.model.CSRegistration;
import com.hpmc.portal.db.service.service.CSBookingLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductBookingManagementLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSProductRegistrationLocalServiceUtil;
import com.hpmc.portal.db.service.service.CSRegistrationLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class CSBookingSpace extends MVCPortlet {
 
	
	public void searchCAByLocation(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException {
		
		try {
			String ca_location = actionRequest.getParameter("cs_location");
			actionResponse.setRenderParameter("cs_location", ca_location);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	private void csBookingDetailsStored(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException {

		
		try {
			long CS_ID = Long.parseLong(actionRequest.getParameter("CSId"));
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void csBookingDetailsStored_Old(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			long CS_ID = Long.parseLong(actionRequest.getParameter("CAId"));
			CSRegistration csRegistration = CSRegistrationLocalServiceUtil.findByCS_ID(CS_ID);
			long CSBookedBy = Long.parseLong(actionRequest.getParameter("user_id"));
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			long productId = Long.parseLong(actionRequest.getParameter("productType"));
			long quantity = Long.parseLong(actionRequest.getParameter("weight"));
			
			CSProductRegistration CSProduct = CSProductRegistrationLocalServiceUtil.findByPRODUCT_ID(productId);
			float rentPerDay = CSProduct.getRENT();
			//float strToIntRentPerDay = Float.parseFloat(rentPerDay);
		    //double totalRentAmount = Math.floor((quantity * rentPerDay) * daysCount);
		    //CS Booking Progress
		    
		    long csBookingId = 0;
		    CSBooking csBooking = null;
		    csBookingId = CounterLocalServiceUtil.increment(CSBooking.class.getName());
		    csBooking = CSBookingLocalServiceUtil.createCSBooking(csBookingId);
		    csBooking.setBOOKED_BY(CSBookedBy);
		    csBooking.setBOOKING_DATE(new Date());
		    CSBookingLocalServiceUtil.addCSBooking(csBooking);
		    //csBooking.setCS_CHAMBER_ID(arg0);
		    
			/*long bookingId = 0;
			CSBooking booking = null;
			bookingId = CounterLocalServiceUtil.increment(CSBooking.class.getName());
			booking = CSBookingLocalServiceUtil.createCSBooking(bookingId);
			
			booking.setCS_CHAMBER_ID(1);
			booking.setBOOKED_BY(CSBookedBy);
			booking.setBOOKING_DATE(new Date());
			System.out.println(6);
			CSBookingLocalServiceUtil.addCSBooking(booking);*/
			
			
			
			long lastBookingId = csBooking.getBOOKING_ID();
			/*booking.setPRODUCT_ID(productId);
			booking.setLOT_NUM(9);
			booking.setAMOUNT_CHARGED((float) totalRentAmount);
			booking.setQUANTITY(quantity);*/
			
			long productBookingId = 0;
			CSProductBookingManagement csProductBookingManagement = null;
			productBookingId = CounterLocalServiceUtil.increment(CSProductBookingManagementLocalServiceUtil.class.getName());
			csProductBookingManagement.setBOOKING_ID(lastBookingId);
			csProductBookingManagement.setPRODUCT_ID(productId);
			//csProductBookingManagement.setRENT_AMOUNT((float) totalRentAmount);
			
			actionRequest.setAttribute("CSBookingId",lastBookingId);
			actionResponse.setRenderParameter("jspPage", "/html/cs/cs-booking-details.jsp");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
